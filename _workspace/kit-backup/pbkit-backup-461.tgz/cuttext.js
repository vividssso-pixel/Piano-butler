const { start } = require('/home/claude/pbtest/kit/contentharness'); const fs = require('fs');
(async () => {
  const H = await start('drills.t450.html');
  const p0 = await H.open({ path: '', w: 1024, h: 900 }); await p0.waitForTimeout(1000);
  const list = await p0.evaluate(() => CUTOUT_LIST.map(c => c.id)); await p0.context().close();
  let out = '';
  for (const id of list) {
    const p = await H.open({ path: '?book=cutouts&ch=' + id + '&lang=en', w: 1000, h: 1400 }); await p.waitForTimeout(2400);
    const t = await p.$$eval('.bk-page', els => els.map((e, i) => '--- page ' + (i + 1) + '\n' + e.innerText.replace(/\n{2,}/g, '\n')));
    out += '\n===== ' + id + '\n' + t.join('\n');
    await p.context().close();
  }
  fs.writeFileSync('/tmp/claude-0/cut-text.txt', out); console.log(out.length);
  await H.close();
})();
