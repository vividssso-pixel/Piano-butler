const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => {
  const H = await start(process.env.BUILD);
  const p = await H.open({ path: '?book=work&ch=' + process.env.CH + '&lang=en', w: 1000, h: 1400 }); await p.waitForTimeout(2600);
  const r = await p.evaluate(() => [...document.querySelectorAll('.bk-page')].map((pg, i) => {
    const tag = [...pg.querySelectorAll('span')].find(s => /PLAY/.test(s.textContent) && s.textContent.length < 12); if (!tag) return (i + 2) + ':-';
    let panel = tag; while (panel && !(panel.style && panel.style.flex && panel.style.flex.startsWith('1 0'))) panel = panel.parentElement;
    if (!panel) return (i + 2) + ':?';
    const box = panel.lastElementChild, kids = [...box.children]; if (!kids.length) return (i + 2) + ':0';
    const used = kids[kids.length - 1].getBoundingClientRect().bottom - kids[0].getBoundingClientRect().top;
    return (i + 2) + ':' + Math.round(box.getBoundingClientRect().height - used);
  }));
  console.log('PLAY slack (px, top + bottom):', r.join(' '));
  await H.close();
})();
