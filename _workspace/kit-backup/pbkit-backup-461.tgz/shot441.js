const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => {
  const H = await start('drills.t444.html');
  for (const lang of ['en', 'ko']) {
    const b = await H.open({ path: '?book=lesson&ch=tones&lang=' + lang, w: 900, h: 1200 }); await b.waitForTimeout(2500);
    const pg = await b.$$('.bk-page');
    await pg[0].screenshot({ path: '/tmp/claude-0/p441-open-' + lang + '.png' });
    await pg[4].screenshot({ path: '/tmp/claude-0/p441-p5-' + lang + '.png' });
    await b.context().close();
    const p = await H.open({ path: '?drill=tones&lang=' + lang, w: 430, h: 900, lang });
    await p.waitForTimeout(1200);
    const box = await p.evaluateHandle(() => [...document.querySelectorAll('.try-box')].find(b => /Sharp up|샤프는 위로/.test(b.textContent)));
    await p.evaluate((bx) => { bx.querySelector('[data-key="16"]').dispatchEvent(new MouseEvent('click', { bubbles: true })); }, box);
    await p.waitForTimeout(100);
    await p.evaluate((bx) => { bx.querySelectorAll('button')[0].click(); }, box);
    await p.waitForTimeout(500);
    await box.asElement().screenshot({ path: '/tmp/claude-0/w441-' + lang + '.png' });
    await p.context().close();
  }
  await H.close();
})();
