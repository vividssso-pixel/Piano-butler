const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => {
  const H = await start('drills.t449.html');
  const p = await H.open({ path: '?lang=en', w: 1000, h: 800 }); await p.waitForTimeout(1500);
  await p.evaluate(() => {
    const d = document.createElement('div'); d.id = 'ref'; d.style.cssText = 'position:fixed;left:0;top:0;width:900px;background:#fff;z-index:99999;display:flex;gap:20px;padding:10px';
    document.body.appendChild(d);
    ReactDOM.createRoot(d).render(React.createElement(React.Fragment, null,
      React.createElement('div', { style: { width: 260 } }, React.createElement(PbArt, { name: 'q-fingers-R', h: 260 })),
      React.createElement('div', { style: { width: 300 } }, React.createElement(PbArt, { name: 'hand-thumb', h: 220 })),
      React.createElement('div', { style: { width: 300 } }, React.createElement(PenArt, { shapes: wuGlideTop(0.3, 'boy'), vb: [0, 0, 220, 160], style: { height: 220 } }))));
  });
  await p.waitForTimeout(800);
  await (await p.$('#ref')).screenshot({ path: '/tmp/claude-0/shots/artref.png' });
  console.log(p._errs.join('|')); await H.close();
})();
