const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => {
  const H = await start(process.env.BUILD || 'drills.t450.html');
  const p0 = await H.open({ path: '', w: 1024, h: 900 }); await p0.waitForTimeout(1000);
  const list = await p0.evaluate(() => CUTOUT_LIST.map(c => c.id)); await p0.context().close();
  const lang = process.env.LANGX || 'en';
  for (const id of list) {
    const p = await H.open({ path: '?book=cutouts&ch=' + id + '&lang=' + lang, w: 1000, h: 1400, dsf: 1.5 }); await p.waitForTimeout(2600);
    const els = await p.$$('.bk-page'); let i = 0;
    for (const el of els) { i++; await el.screenshot({ path: '/tmp/claude-0/shots/cut-' + lang + '-' + id + '-' + i + '.png' }); }
    await p.context().close();
  }
  await H.close();
})();
