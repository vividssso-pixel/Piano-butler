// the guide-page worksheet pictures (Workbook pages): render with a build, 2x
const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => {
  const H = await start(process.env.BUILD);
  for (const [ch, pg] of [['staff', 1], ['ledger-lines', 1], ['tones', 3], ['whole-staff', 1]]) {
    const p = await H.open({ path: '?book=work&ch=' + ch + '&lang=en&pages=' + pg, w: 1800, h: 2600 });
    await p.waitForTimeout(1500); await p.evaluate(() => { document.documentElement.style.zoom = 2; }); await p.waitForTimeout(800);
    for (const el of await p.$$('section.bk-page')) if (await el.isVisible()) { await el.screenshot({ path: '/tmp/claude-0/shots/ws-' + process.env.TAG + '-' + ch + '.png' }); break; }
    await p.context().close();
  }
  await H.close(); process.exit(0);
})();
