const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => { for (const b of ['drills.t444.html', 'drills.t447.html']) { const H = await start(b);
  const p = await H.open({ path: '?drill=whole-staff&lang=ko', w: 700, h: 1000, dsf: 3 }); await p.waitForTimeout(3800);
  const svg = await p.evaluateHandle(() => { const ts = [...document.querySelectorAll('svg text')]; const t = ts.find(x => x.textContent.trim() === '𝄢' && [...x.ownerSVGElement.querySelectorAll('text')].some(y => y.textContent.trim() === '𝄞')); return t.ownerSVGElement; });
  await svg.asElement().screenshot({ path: '/tmp/claude-0/cg-' + b.slice(7, 11) + '.png' });
  await H.close(); } })();
