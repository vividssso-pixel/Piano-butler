const { start } = require('/home/claude/pbtest/kit/contentharness'); const fs = require('fs');
const OUT = '/home/claude/pbtest/fix442/site/svg/';
(async () => {
  const H = await start('drills.t443.html');
  const p = await H.open({ path: '?book=lesson&ch=first-steps&lang=en', w: 900, h: 1200 }); await p.waitForTimeout(2000);
  const r = await p.evaluate(() => ({ cover: [...document.querySelectorAll('.lb-page')][0].querySelector('[role=img]'), puppet: PB_ART.puppet }) && ({ cover: (() => { const d = [...document.querySelectorAll('.lb-page')][0].querySelector('[role=img]'); return { label: d.getAttribute('aria-label'), svg: (d.tagName === 'svg' ? d : d.querySelector('svg')).outerHTML }; })(), puppet: PB_ART.puppet }));
  const fix = (svg) => { const m = /viewBox="([\d.\- ]+)"/.exec(svg), [, , w, h] = m[1].split(' ').map(Number);
    return svg.replace(/<svg[^>]*?viewBox="[^"]+"[^>]*>/, () => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="' + m[1] + '" width="' + Math.round(w * 2) + '" height="' + Math.round(h * 2) + '">'); };
  fs.writeFileSync(OUT + 'first-steps/hero.svg', fix(r.cover.svg)); console.log('cover', r.cover.label);
  fs.writeFileSync(OUT + 'posture-hands/hero.svg', fix(r.puppet)); console.log('puppet ok', p._errs.join('|'));
  await H.close(); process.exit(0);
})();
