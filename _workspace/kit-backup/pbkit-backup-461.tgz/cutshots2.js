const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => {
  const H = await start('drills.t451.html');
  for (const [id, pg] of [['chord-loop', 1], ['practice-dice', 3], ['composer-cards', 5], ['cards-elements', 1]]) {
    const p = await H.open({ path: '?book=cutouts&ch=' + id + '&lang=en', w: 1000, h: 1400, dsf: 1.5 }); await p.waitForTimeout(2600);
    const els = await p.$$('.bk-page'); await els[pg - 1].screenshot({ path: '/tmp/claude-0/shots/c451-' + id + '.png' }); await p.context().close();
  }
  await H.close();
})();
