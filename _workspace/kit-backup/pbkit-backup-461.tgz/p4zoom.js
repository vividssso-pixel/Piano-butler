const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => {
  const H = await start('drills.t450.html');
  for (const lang of ['en', 'ko']) {
    const p = await H.open({ path: '?book=lesson&ch=posture-hands&lang=' + lang, w: 1000, h: 1400, dsf: 2 }); await p.waitForTimeout(3500);
    const pg = (await p.$$('.bk-page'))[3];
    const pic = await pg.$('.lb-pic, [class*=pic]');
    await pg.screenshot({ path: '/tmp/claude-0/shots/p4z-' + lang + '.png' });
    await p.context().close();
  }
  await H.close();
})();
