const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => {
  const H = await start(process.env.BUILD);
  for (const path of ['?drill=time-signatures', '?drill=rhythm', '?drill=pulse', '?tool=nv-walk', '?tool=count-aloud', '?tool=dot-lab', '?tool=fill-bar', '?drill=note-values&tab=drill&level=9', '?book=spread&ch=note-values', '?book=work&ch=front', '?print=1&drill=note-values&level=4', '?print=1&drill=note-values&level=9', '?print=1&drill=note-values&level=5']) {
    for (const lang of ['en', 'ko']) {
      const p = await H.open({ path, w: 430, h: 900, lang }); await p.waitForTimeout(1500);
      const info = await p.evaluate(() => ({ steps: document.querySelectorAll('[id*="-step-"]').length, txt: document.body.innerText.slice(0, 0), noPrint: /No printable worksheet/.test(document.body.innerText), count: (document.body.innerText.match(/1 \+ 2 \+/g) || []).length, and: /1 and 2 and|1 앤 2 앤/.test(document.body.innerText) }));
      console.log(path, lang, JSON.stringify(info), p._errs.join('|').slice(0, 200));
      await p.context().close();
    }
  }
  await H.close();
})();
