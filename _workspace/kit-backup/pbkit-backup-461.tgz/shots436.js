const { start } = require('/home/claude/pbtest/kit/contentharness');
const OUT = '/home/claude/pbtest/fix436/shots/';
(async () => {
  const H = await start(process.env.BUILD || 'drills.t436d.html');
  const store = { pb_lesson_steps_v1: JSON.stringify({ 'posture-hands': { 0: 1, 1: 1, 2: 1, 3: 1, 4: 1, 5: 1 }, 'first-steps': { 0: 1 } }), pb_steps_total_v1: JSON.stringify({ 'posture-hands': 6, 'first-steps': 9 }) };
  // 1. the map (computer, en) and the phone (ko)
  for (const [w, lang] of [[1024, 'en'], [390, 'ko']]) {
    const p = await H.open({ path: '', w, h: 900, store, lang, dsf: 2 }); await p.waitForTimeout(900);
    if (await p.$('[data-door]')) { await p.click('[data-door]'); await p.waitForTimeout(1600); }
    const el = await p.$('[data-house-view]'); await el.screenshot({ path: OUT + 'map-' + w + '-' + lang + '.png' });
    await p.context().close();
  }
  // 2. a chapter opened early (student): the after line at the top, the next line at the end
  for (const [id, lang] of [['reading-steps', 'en'], ['staff', 'ko']]) {
    const p = await H.open({ path: '?drill=' + id, w: 430, h: 900, store, lang, dsf: 2 }); await p.waitForTimeout(1200);
    await p.screenshot({ path: OUT + 'ch-' + id + '-' + lang + '-top.png' });
    const pn = await p.$('text=Next on your path') || await p.$('text=나의 경로에서 다음');
    if (pn) { await pn.scrollIntoViewIfNeeded(); await p.waitForTimeout(300); await p.screenshot({ path: OUT + 'ch-' + id + '-' + lang + '-end.png' }); }
    await p.context().close();
  }
  // 3. the Workbook's front pages
  const b = await H.open({ path: '?book=work&ch=front&lang=en', w: 900, h: 1200, dsf: 1.5 }); await b.waitForTimeout(2800);
  const pages = await b.$$('.bk-page');
  for (let i = 0; i < Math.min(2, pages.length); i++) await pages[i].screenshot({ path: OUT + 'wb-front-' + (i + 1) + '.png' });
  await b.context().close();
  await H.close(); console.log('ok');
})();
