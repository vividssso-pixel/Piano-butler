const { start } = require('/home/claude/pbtest/kit/contentharness'); const fs = require('fs');
(async () => {
  const L = JSON.parse(fs.readFileSync('/home/claude/pbtest/plan435/levels.json'));
  const H = await start('drills.t433.html');
  const OLD = "const name=(o.print?st.s.en[0]:t(st.s.en[0],st.s.ko[0])).toUpperCase(),mw=rdWidth(name,700,11.5,TH_CAPS),pw=(thFontsIn()?mw:Math.max(mw,name.length*9.4))+name.length*1.04+36;body+=stR(RX0+6,yy+4,pw,20,0.9)+stR(RX0+8,yy+6,pw-4,16,0.4,'none')+stSquare(RX0+11,yy+7.5,13,k+1,st.st.every(v=>v==='done')?ST.G:null,9)+stT(RX0+30,yy+18.4,name,{size:11.5,weight:700,font:TH_CAPS,ls:'0.09em',fill:here?ST.C:ST.N});";
  for (const V of ['A', 'B', 'C']) for (const lang of ['en', 'ko']) {
    const p = await H.open({ path: '?book=work&ch=front&lang=' + lang, w: 1000, h: 1400, dsf: 2 });
    await p.evaluate(() => Promise.all([document.fonts.load('700 12px Cinzel'), document.fonts.load("700 15px 'Cormorant Garamond'")]));
    const svg = await p.evaluate(({ L, OLD, V }) => {
      rdCtx = null;
      if (!DRILLS.find(d => d.id === 'accidentals')) { const tn = DRILLS.find(d => d.id === 'tones'); DRILLS.push({ ...tn, id: 'accidentals', label: 'Accidentals' }); }
      CH_SHORT['accidentals'] = ['Accidentals', '임시표']; CH_SHORT['tones'] = ['Tones & semitones', '온음과 반음']; CH_SHORT['reading-steps'] = [CH_SHORT['reading-steps'][0], '걸음·건너뛰기'];
      HOUSE_ICONS['accidentals'] = '<path d="M17 7 V26 M27 13 V32"/><path d="M17 16 L27 12.5 M17 24 L27 20.5" stroke-width="2.6"/><path d="M36 5 V31"/>';
      const nums = {}; let n = 0; L.forEach(l => l.ids.forEach(id => { nums[id] = ++n; }));
      const stages = L.map((l, i) => ({ s: { en: l.en, ko: l.ko }, i, ids: l.ids, st: l.ids.map(id => ['posture-hands', 'first-steps', 'note-names', 'staff', 'whole-staff', 'ledger-lines'].includes(id) ? 'done' : id === 'tones' ? 'started' : 'new') }));
      const LAB = { A: (k) => LANG === 'ko' ? (k + 1) + '단계' : 'LEVEL ' + (k + 1), B: (k) => LANG === 'ko' ? (k + 1) + '층' : ['FIRST', 'SECOND', 'THIRD', 'FOURTH', 'FIFTH'][k] + ' FLOOR', C: (k) => ['I', 'II', 'III', 'IV', 'V'][k] }[V];
      window.__LAB = LAB;
      const NEW = "const name=window.__LAB(k),mw=rdWidth(name,700,11.5,TH_CAPS),pw=(thFontsIn()?mw:Math.max(mw,name.length*9.4))+name.length*1.04+30,px=(X0+X1)/2-pw/2;body+=stR(px,yy+4,pw,20,0.9)+stR(px+2,yy+6,pw-4,16,0.4,'none')+stT((X0+X1)/2,yy+18.4,name,{size:11.5,weight:700,font:TH_CAPS,ls:'0.09em',fill:here?ST.C:ST.N,anchor:'middle'});";
      let src = townhouseSvg.toString(); if (!src.includes(OLD)) return 'NOOLD';
      src = src.replace(OLD, NEW).replace('for(let k=6;k>=0;k--)', 'for(let k=view.stages.length-1;k>=0;k--)').replace("'Start · climb up, one room at a time','출발 · 한 방씩 위로 올라가요'", "'Start · floor by floor, any room first','출발 · 한 층씩, 방은 마음대로'");
      const f = new Function('return ' + src)();
      const h = f({ stages, here: 'tones', nums }, { wide: true }); return penSvg([{ k: 'raw', svg: h.svg }], { vb: h.vb, id: 'hv' });
    }, { L, OLD, V });
    if (svg === 'NOOLD') { console.log('plaque code not found'); process.exit(1); }
    await p.evaluate((svg) => { document.body.innerHTML = '<div id="mock" style="width:900px;background:#fff">' + svg.replace('<svg ', '<svg style="width:100%;display:block" ') + '</div>'; }, svg);
    await p.waitForTimeout(300); await (await p.$('#mock')).screenshot({ path: '/home/claude/pbtest/plan435/var' + V + '-' + lang + '.png' });
    fs.writeFileSync('/home/claude/pbtest/plan435/var' + V + '-' + lang + '.svg', svg);
    await p.context().close();
  }
  await H.close(); console.log('ok');
})();
