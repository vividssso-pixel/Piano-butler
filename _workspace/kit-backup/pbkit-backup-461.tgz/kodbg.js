const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => {
  const H = await start('drills.t436d.html');
  const p = await H.open({ path: '', w: 390, h: 900, store: { pb_house_in_v1: '1' }, lang: 'ko' }); await p.waitForTimeout(1500);
  console.log(await p.evaluate(() => ({ LANG, url: location.href, t: [...document.querySelectorAll('[data-house-view] svg text')].slice(0, 12).map(x => x.textContent) })));
  await H.close();
})();
