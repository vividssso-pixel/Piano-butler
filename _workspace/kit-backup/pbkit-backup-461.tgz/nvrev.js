const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => { const H = await start('' + (process.env.BUILD || 'drills.t458.html') + '');
  for (const lang of ['en', 'ko']) { const p = await H.open({ path: '?book=lesson&ch=note-values&lang=' + lang + '&draft=1', w: 1000, h: 1400 }); await p.waitForTimeout(2800);
    const els = await p.$$('.bk-page'); for (let i = 0; i < els.length; i++) await els[i].screenshot({ path: '/home/claude/pbtest/ch5/review/' + (process.env.TAG || '') + 'lesson-' + lang + '-' + (i + 1) + '.png' });
    console.log(lang, els.length, p._errs.join('|')); await p.context().close(); }
  await H.close(); })();
