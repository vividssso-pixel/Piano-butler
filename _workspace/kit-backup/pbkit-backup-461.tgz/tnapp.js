const { start } = require('/home/claude/pbtest/kit/contentharness');
const OUT = '/home/claude/pbtest/ch7/a437/shots/';
(async () => {
  const H = await start(process.env.BUILD || 'drills.t437.html');
  for (const lang of ['en', 'ko']) {
    const p = await H.open({ path: '?drill=tones', w: 430, h: 900, lang, dsf: 1.5 }); await p.waitForTimeout(1500);
    await p.screenshot({ path: OUT + 'learn-top-' + lang + '.png', fullPage: false });
    // open every step and shoot the try boxes
    const boxes = await p.$$('.try-box');
    console.log(lang, 'try boxes', boxes.length, 'errs', p._errs.join('|').slice(0, 300));
    for (let i = 0; i < boxes.length; i++) { await boxes[i].scrollIntoViewIfNeeded(); await boxes[i].screenshot({ path: OUT + 'try-' + lang + '-' + i + '.png' }); }
    await p.context().close();
  }
  for (let lv = 1; lv <= 7; lv++) {
    const p = await H.open({ path: '?drill=tones&tab=drill&level=' + lv, w: 430, h: 900, lang: 'en', dsf: 1.5 }); await p.waitForTimeout(1500);
    const start = await p.$('button:has-text("Start")'); if (start) { await start.click(); await p.waitForTimeout(800); }
    await p.screenshot({ path: OUT + 'drill-' + lv + '.png' });
    console.log('level', lv, 'errs', p._errs.join('|').slice(0, 300));
    await p.context().close();
  }
  await H.close();
})();
