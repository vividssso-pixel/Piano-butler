const { start } = require('/home/claude/pbtest/kit/contentharness');
const OUT = '/home/claude/pbtest/ch5a/shots/app/';
(async () => {
  const H = await start(process.env.BUILD || 'drills.t460.html');
  for (const lang of ['en', 'ko']) {
    const p = await H.open({ path: '?drill=note-values', w: 390, h: 860, lang, dsf: 1.5 }); await p.waitForTimeout(1800);
    await p.screenshot({ path: OUT + 'learn-top-' + lang + '.png', fullPage: false });
    const hor = await p.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
    const steps = await p.evaluate(() => [...document.querySelectorAll('[id^="note-values-step-"]')].map(e => e.id));
    const boxes = await p.$$('.try-box');
    console.log(lang, 'steps', steps.join(','), 'try boxes', boxes.length, 'hscroll', hor, 'errs', p._errs.join('|').slice(0, 300));
    for (let i = 0; i < boxes.length; i++) { await boxes[i].scrollIntoViewIfNeeded(); await boxes[i].screenshot({ path: OUT + 'try-' + lang + '-' + i + '.png' }); }
    // overflow inside the try boxes
    const wide = await p.evaluate(() => [...document.querySelectorAll('.try-box')].map((b, i) => { const R = b.getBoundingClientRect(); return i + ':' + Math.max(0, ...[...b.querySelectorAll('*')].map(x => Math.round(x.getBoundingClientRect().right - R.right))); }));
    console.log(lang, 'overhang', wide.join(' '));
    await p.context().close();
  }
  for (let lv = 1; lv <= 9; lv++) for (const lang of ['en', 'ko']) {
    const p = await H.open({ path: '?drill=note-values&tab=drill&level=' + lv, w: 390, h: 860, lang, dsf: 1.5 }); await p.waitForTimeout(1500);
    await p.screenshot({ path: OUT + 'drill-' + lv + '-' + lang + '.png' });
    console.log('level', lv, lang, 'errs', p._errs.join('|').slice(0, 300));
    await p.context().close();
  }
  await H.close();
})();
