const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => { const H = await start('drills.t448.html'); const p = await H.open({ path: '?lang=en', w: 900, h: 700, dsf: 2 }); await p.waitForTimeout(1200);
  await p.evaluate(() => { const d = document.createElement('div'); d.id = 'ks'; d.style.cssText = 'position:absolute;left:0;top:0;width:880px;background:#fff;display:grid;grid-template-columns:repeat(2,1fr);gap:8px;padding:8px;z-index:99'; document.body.appendChild(d);
    ReactDOM.createRoot(d).render(React.createElement(React.Fragment, null, ...[['sharp', 'treble'], ['flat', 'treble'], ['sharp', 'bass'], ['flat', 'bass']].map(([ty, cl]) => React.createElement('div', { key: ty + cl, style: { border: '1px solid #ccc' } }, React.createElement(KSStaff, { count: 7, type: ty, clef: cl, width: 170 }))))); });
  await p.waitForTimeout(1500); await (await p.$('#ks')).screenshot({ path: '/tmp/claude-0/ks448.png' }); await H.close(); })();
