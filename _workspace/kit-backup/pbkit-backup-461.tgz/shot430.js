const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => { const H = await start('drills.t430.html');
  const p = await H.open({ path: '?drill=note-names', w: 1280, h: 1100 }); const b = await p.$('.lb-pic'); await b.scrollIntoViewIfNeeded();
  const bb = await b.boundingBox(); await p.screenshot({ path: '/tmp/online430.png', clip: { x: 0, y: Math.max(0, bb.y - 260), width: 1280, height: bb.height + 360 } });
  await H.close(); })();
