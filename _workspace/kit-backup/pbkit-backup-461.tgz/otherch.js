const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => {
  const H = await start(process.env.BUILD || 'drills.t455.html');
  for (const path of ['?drill=time-signatures', '?drill=note-values', '?book=lesson&ch=time-signatures', '?book=lesson&ch=note-values', '?drill=pulse&tab=drill&level=1&print=1', '?print=1&drill=pulse&level=2&n=12', '?toolbox=1']) {
    const p = await H.open({ path, w: 430, h: 900, lang: 'en' }); await p.waitForTimeout(2200);
    const r = await p.evaluate(() => ({ steps: [...document.querySelectorAll('[id$="-step-7"],[id$="-step-8"],[id$="-step-11"]')].map(e => e.id + ':' + (e.textContent || '').slice(0, 40)), text: document.body.innerText.slice(0, 120).replace(/\n/g, ' ') }));
    console.log(path, JSON.stringify(r).slice(0, 400), p._errs.join('|').slice(0, 200));
    await p.context().close();
  }
  await H.close();
})();
