const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => {
  const H = await start('drills.p393.html');
  const p = await H.open({ path: '?drill=posture-hands', w: 390, h: 1400 });
  await p.waitForTimeout(1200);
  const st = await p.$$('section[id^="posture-hands-step-"]');
  await st[0].screenshot({ path: '/home/claude/pbtest/kit/p393/app-ph1.png' });
  await st[1].screenshot({ path: '/home/claude/pbtest/kit/p393/app-ph2.png' });
  console.log('errs', p._errs.join('|'));
  await H.close(); process.exit(0);
})();
