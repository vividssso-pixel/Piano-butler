const { start } = require('/home/claude/pbtest/kit/contentharness');
const OUT = '/home/claude/pbtest/ch5/now/';
(async () => {
  require('fs').mkdirSync(OUT, { recursive: true });
  const H = await start('drills.t455.html');
  const p = await H.open({ path: '?drill=note-values', w: 430, h: 900, lang: 'en', dsf: 1.5 }); await p.waitForTimeout(1800);
  const steps = await p.evaluate(() => [...document.querySelectorAll('[id^="note-values-step-"]')].map(e => (e.textContent || '').replace(/\s+/g, ' ').slice(0, 60)));
  console.log(steps.join('\n')); await p.screenshot({ path: OUT + 'app-now.png' }); await p.context().close();
  const w = await H.open({ path: '?book=work&ch=note-values&lang=en', w: 1000, h: 1400 }); await w.waitForTimeout(2600);
  const pages = await w.$$('.bk-page'); console.log('wb pages', pages.length);
  const heads = await w.evaluate(() => [...document.querySelectorAll('.bk-page')].map((pg, i) => (i + 1) + ': ' + [...pg.querySelectorAll('span')].filter(s => /Playfair/.test(s.style.fontFamily || '')).map(s => s.textContent).join(' · ').slice(0, 160)));
  console.log(heads.join('\n'));
  for (const i of [2, 3]) await pages[i].screenshot({ path: OUT + 'wb-old-' + (i + 1) + '.png' });
  await H.close();
})();
