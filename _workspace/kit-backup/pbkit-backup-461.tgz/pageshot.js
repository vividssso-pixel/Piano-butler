// screenshot given workbook pages: PAGES="path#idx,path#idx"
const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => {
  const H = await start(process.env.BUILD);
  for (const spec of process.env.PAGES.split(',')) {
    const [path, idx] = spec.split('#');
    const p = await H.open({ path, w: 1000, h: 1400 }); await p.waitForTimeout(3000);
    const els = await p.$$('.bk-page');
    const el = els[+idx - 1];
    const info = await el.evaluate(e => { const b = e.querySelector('.bk-body'); return [b.scrollHeight, b.clientHeight]; });
    const name = (process.env.TAG || '') + path.replace(/[?&=]/g, '_') + '-p' + idx + '.png';
    await el.screenshot({ path: '/tmp/claude-0/shots/' + name });
    console.log(name, info);
    await p.context().close();
  }
  await H.close();
})();
