const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => { const H = await start('drills.t433.html');
  const p = await H.open({ path: '?book=lesson&ch=ledger-lines&lang=en', w: 1100, h: 1400, dsf: 2 }); await p.waitForTimeout(800);
  const pg = (await p.$$('.bk-page'))[1]; await pg.scrollIntoViewIfNeeded(); await pg.screenshot({ path: '/tmp/rb-page.png' });

  const q = await H.open({ path: '?book=work&ch=front&lang=en', w: 1100, h: 1600, dsf: 1.5 }); await q.waitForTimeout(1500);
  const f = (await q.$$('.bk-page'))[0]; if (f) await f.screenshot({ path: '/tmp/rb-front.png' });
  console.log(p._errs, q._errs); await H.close(); })();
