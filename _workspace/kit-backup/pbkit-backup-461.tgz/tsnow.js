const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => { const H = await start(process.env.BUILD);
  const p = await H.open({ path: '?drill=time-signatures', w: 390, h: 1500, lang: 'en', dsf: 1.5 }); await p.waitForTimeout(1800);
  await p.screenshot({ path: '/home/claude/pbtest/ch8/app-now.png' });
  const q = await H.open({ path: '?drill=time-signatures&tab=drill&level=2', w: 390, h: 1100, lang: 'en', dsf: 1.5 }); await q.waitForTimeout(1500);
  await q.screenshot({ path: '/home/claude/pbtest/ch8/drill-now.png' });
  await H.close(); })();
