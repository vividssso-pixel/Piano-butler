const { chromium } = require('/home/claude/pbtest/kit/node_modules/playwright');
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  for (const f of ['keyboard-patterns', 'posture-and-hand-shape', 'index']) {
    const p = await b.newPage({ viewport: { width: 390, height: 900 } });
    await p.route('**/*', r => r.request().url().startsWith('file:') ? r.continue() : r.abort());
    await p.goto('file:///tmp/claude-0/gchk/' + f + '.html');
    await p.waitForTimeout(500);
    const r = await p.evaluate(() => ({ side: document.documentElement.scrollWidth - innerWidth, h1: document.querySelector('h1').textContent, title: document.title, canon: (document.querySelector('link[rel=canonical]') || {}).href, robots: (document.querySelector('meta[name=robots]') || {}).content, next: [...document.querySelectorAll('nav.next a')].map(a => a.getAttribute('href') + ' ' + a.textContent).join(' | ') }));
    console.log(f, JSON.stringify(r));
    await p.screenshot({ path: '/home/claude/pbtest/kit/p393/guide-' + f + '.png', fullPage: false });
    await p.close();
  }
  await b.close();
})();
