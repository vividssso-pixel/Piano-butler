const { start } = require('/home/claude/pbtest/kit/contentharness'); const fs = require('fs');
(async () => {
  const H = await start('drills.t450.html');
  const p = await H.open({ path: '?lang=en', w: 900, h: 700 }); await p.waitForTimeout(1500);
  let svg = await p.evaluate(() => penSvg(thumbBook450(), { vb: [0, 0, 204, 152], id: 'hpthumb450' }));
  svg = svg.replace('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 204 152">', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 204 152" width="408" height="304">');
  fs.writeFileSync('/home/claude/pbtest/fix449/g450/x/svg/posture-hands/thumb.svg', svg);
  console.log(svg.length, svg.slice(0, 160), p._errs.join('|')); await H.close();
})();
