const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => {
  const H = await start(process.env.BUILD);
  for (const ch of process.env.CHS.split(',')) for (const lang of (process.env.LANGS || 'en').split(',')) {
    const p = await H.open({ path: '?book=lesson&ch=' + ch + '&lang=' + lang, w: 1000, h: 1400 }); await p.waitForTimeout(3000);
    const els = await p.$$('.bk-page');
    for (let i = 0; i < els.length; i++) await els[i].screenshot({ path: '/tmp/claude-0/shots/lb460-' + ch + '-' + lang + '-' + (i + 1) + '.png' });
    console.log(ch, lang, els.length, p._errs.length ? p._errs[0] : '');
    await p.context().close();
  }
  await H.close();
})();
