const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => { const H = await start('drills.t448.html'); const p = await H.open({ path: '?lang=en', w: 900, h: 600, dsf: 2 }); await p.waitForTimeout(1200);
  await p.evaluate(() => { const d = document.createElement('div'); d.id = 'art'; d.style.cssText = 'position:absolute;left:0;top:0;width:880px;background:#fff;display:grid;grid-template-columns:repeat(3,1fr);gap:8px;padding:8px;z-index:99'; document.body.appendChild(d);
    ReactDOM.createRoot(d).render(React.createElement(React.Fragment, null, ...['dot', 'wedge', 'tenuto', 'accent', 'slur', 'fermata'].map(m => React.createElement('div', { key: m, style: { border: '1px solid #ccc' } }, m, React.createElement(ArticBar, { mark: m }))))); });
  await p.waitForTimeout(600); await (await p.$('#art')).screenshot({ path: '/tmp/claude-0/artic448.png' }); await H.close(); })();
