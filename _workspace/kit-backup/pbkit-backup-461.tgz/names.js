const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => { const H = await start('drills.t444.html');
  const p = await H.open({ path: '?lang=en', w: 900, h: 900 }); await p.waitForTimeout(1200);
  const r = await p.evaluate(() => { const ids = PATH_STAGES.flatMap(s => pathStageIds(s)); return ids.map((id, i) => (i + 1) + ' ' + id + ' | ' + bkChapterName(id) + ' | ' + ((CH_SHORT[id] || [])[0] || '')); });
  console.log(r.join('\n')); await H.close(); })();
