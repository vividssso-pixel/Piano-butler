const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => { for (const b of ['drills.t444.html', 'drills.t447.html']) { const H = await start(b);
  const p = await H.open({ path: '?book=lesson&ch=staff&lang=en', w: 900, h: 1200 }); await p.waitForTimeout(3500);
  const svg = await p.evaluateHandle(() => [...document.querySelectorAll('svg text')].find(t => t.textContent.trim() === '𝄞').ownerSVGElement);
  await svg.asElement().screenshot({ path: '/tmp/claude-0/cs-' + b.slice(7, 11) + '.png' });
  await H.close(); } })();
