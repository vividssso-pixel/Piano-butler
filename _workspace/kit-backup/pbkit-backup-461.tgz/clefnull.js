const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => { const H = await start('drills.t447.html');
  for (const path of ['?drill=pulse', '?drill=intervals', '?drill=composers']) {
    const p = await H.open({ path: path + '&lang=en', w: 1024, h: 900 }); await p.waitForTimeout(3500);
    const r = await p.evaluate(() => [...document.querySelectorAll('svg text')].filter(t => t.textContent.trim() === '𝄞').map(t => { const svg = t.ownerSVGElement; const b = svg.getBoundingClientRect(); return { vb: svg.getAttribute('viewBox'), w: Math.round(b.width), h: Math.round(b.height), lines: svg.querySelectorAll('line').length, paths: svg.querySelectorAll('path').length, rects: svg.querySelectorAll('rect').length, cls: (svg.closest('[class]') || {}).className, html: svg.outerHTML.slice(0, 500) }; }));
    console.log(path, JSON.stringify(r[0]).slice(0, 900));
    await p.screenshot({ path: '/tmp/claude-0/cn-' + path.slice(7) + '.png' });
    await p.context().close(); }
  await H.close(); })();
