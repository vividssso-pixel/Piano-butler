const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => {
  const H = await start('drills.nn391.html');
  const p = await H.open({ path: '?book=lesson&ch=note-names&lang=en&draft=1', w: 900, h: 1200 });
  await p.waitForTimeout(1500);
  const r = await p.evaluate(() => { const el = document.querySelector('[data-lb-ask="B1"]'); const d = el.parentElement; return [getComputedStyle(el).fontFamily, d.outerHTML.slice(0, 400), getComputedStyle(d).fontFamily]; });
  console.log(r);
  await H.close(); process.exit(0);
})();
