const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => { const H = await start('drills.t444.html');
  for (const n of [1, 2, 3, 4, 5]) {
    const p = await H.open({ path: '?book=work&ch=tones&lang=en&pages=' + n, w: 1800, h: 2600 });
    await p.waitForTimeout(1500); await p.evaluate(() => { document.documentElement.style.zoom = 2; }); await p.waitForTimeout(800);
    for (const pg of await p.$$('section.bk-page')) if (await pg.isVisible()) { await pg.screenshot({ path: '/tmp/claude-0/wstn-' + n + '.png' }); break; }
    console.log(n, p._errs.join('|')); await p.context().close(); }
  await H.close(); process.exit(0); })();
