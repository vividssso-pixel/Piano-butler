const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => {
  const H = await start('drills.t449.html');
  for (const lang of ['en', 'ko']) {
    const p = await H.open({ path: '?drill=ledger-lines&lang=' + lang, w: 1024, h: 900 }); await p.waitForTimeout(3000);
    const r = await p.evaluate(() => { const C = DRILLS.find(d => d.id === 'ledger-lines'); const c = C.concept || C; return { lv: c.levels.map(l => typeof l.label === 'function' ? l.label() : l.label).join(' | '), chips: [...document.querySelectorAll('button.chip')].map(b => b.textContent).filter(x => /C|도/.test(x)).slice(0, 12).join(' / ') }; });
    const body = await p.evaluate(() => document.body.innerText);
    console.log(lang, JSON.stringify(r)); console.log('  i18n level 4:', /High C and low C: a step or a skip/.test(body), /높은 도와 낮은 도/.test(body), 'errs', p._errs.length);
    await p.context().close();
  }
  await H.close();
})();
