const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => {
  const H = await start('drills.t450.html');
  for (const path of ['?book=teacher&ch=posture-hands&lang=en', '?book=teacher&ch=posture-hands&lang=ko', '?book=spread&ch=posture-hands&lang=en', '?book=spread&ch=posture-hands&lang=ko']) {
    const p = await H.open({ path, w: 1024, h: 900 }); await p.waitForTimeout(3000);
    const info = await p.$$eval('.bk-page', els => els.map(e => { const b = e.querySelector('.bk-body'); return b ? b.scrollHeight - b.clientHeight : null; }));
    console.log(path, info.length, 'over', info.map((v, i) => [i + 1, v]).filter(([, v]) => v > 1).join(' '), p._errs.length); await p.context().close();
  }
  await H.close();
})();
