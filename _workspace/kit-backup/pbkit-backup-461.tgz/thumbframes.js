// frames of the two draft animations, side by side
const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => {
  const H = await start(process.env.BUILD || 'drills.t450d.html');
  const p = await H.open({ path: '?lang=' + (process.env.LANGX || 'en'), w: 1400, h: 900 }); await p.waitForTimeout(1500);
  const frames = { tunnel: [0, 0.27, 0.5, 0.74], balance: [0.04, 0.165, 0.29, 0.415, 0.54] };
  await p.evaluate((frames) => {
    const d = document.createElement('div'); d.id = 'fr'; d.style.cssText = 'position:fixed;left:0;top:0;width:1380px;background:#fff;z-index:99999;padding:10px';
    document.body.appendChild(d);
    const row = (f, phs) => React.createElement('div', { style: { display: 'flex', gap: 10, marginBottom: 10 } }, phs.map((ph, i) => React.createElement('div', { key: i, style: { width: 260, background: '#faf6ec', borderRadius: 8 } }, React.createElement(PenArt, { shapes: f(ph), vb: [0, 0, 204, 152] }))));
    ReactDOM.createRoot(d).render(React.createElement('div', null, row(wuThumbTunnel, frames.tunnel), row(wuFingerBalance, frames.balance)));
  }, frames);
  await p.waitForTimeout(800);
  await (await p.$('#fr')).screenshot({ path: '/tmp/claude-0/shots/thumb-frames-' + (process.env.LANGX || 'en') + '.png' });
  console.log('errs', p._errs.join('|')); await H.close();
})();
