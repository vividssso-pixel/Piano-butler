const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => {
  const H = await start('drills.t437.html');
  const b = await H.open({ path: '?book=teacher&ch=tones&lang=en', w: 900, h: 1200 }); await b.waitForTimeout(2500);
  const pages = await b.$$('.bk-page');
  for (let i = 0; i < pages.length; i++) await pages[i].screenshot({ path: '/tmp/claude-0/tc437-' + (i + 1) + '.png' });
  await H.close();
})();
