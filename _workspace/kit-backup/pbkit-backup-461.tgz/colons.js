const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => { const H = await start(process.env.BUILD || 'drills.t444.html');
  const chs = ['posture-hands', 'first-steps', 'note-names', 'staff', 'whole-staff', 'ledger-lines', 'tones'];
  for (const lang of ['en', 'ko']) for (const ch of chs) for (const kind of ['lesson', 'work', 'teacher']) {
    const b = await H.open({ path: '?book=' + kind + '&ch=' + ch + '&lang=' + lang, w: 900, h: 1200, lang }); await b.waitForTimeout(1800);
    const t = await b.evaluate(() => document.body.innerText);
    const s = t.split(/\n+/).flatMap(l => l.split(/(?<=[.!?])\s+/)).filter(x => (x.match(/: /g) || []).length >= 2);
    s.forEach(x => console.log(lang, ch, kind, '|', x.slice(0, 220)));
    await b.context().close(); }
  await H.close(); })();
