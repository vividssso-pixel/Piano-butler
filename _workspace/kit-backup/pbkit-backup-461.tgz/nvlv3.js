const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => { const H = await start('drills.t460.html');
  const p = await H.open({ path: '?drill=note-values&tab=drill&level=3', w: 390, h: 860, lang: 'en', dsf: 1.5 }); await p.waitForTimeout(1500);
  const c = await p.$('.card'); await c.screenshot({ path: '/tmp/claude-0/lv3.png' }); console.log(p._errs.join('|')); await H.close(); })();
