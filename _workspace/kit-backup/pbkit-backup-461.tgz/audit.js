const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => { const H = await start('drills.t433.html');
  const p = await H.open({ path: '?book=work&ch=front&lang=en', w: 900, h: 900 });
  const r = await p.evaluate(() => {
    const out = [];
    PATH_STAGES.forEach((st, si) => pathStageIds(st).forEach(id => {
      const d = DRILLS.find(x => x.id === id); const c = d.concept || {};
      const lv = (c.levels || []).map(l => (l.n != null ? l.n + ' ' : '') + (l.label || ''));
      out.push({ stage: si + 1, id, label: d.label, track: d.track, levels: lv, learn: c.Learn ? c.Learn.name : null, tools: (typeof CH_TOOLS !== 'undefined' && CH_TOOLS[id]) || null, book: typeof LESSON_BOOKS !== 'undefined' && !!LESSON_BOOKS[id] });
    }));
    return out; });
  console.log(JSON.stringify(r, null, 0)); await H.close(); })();
