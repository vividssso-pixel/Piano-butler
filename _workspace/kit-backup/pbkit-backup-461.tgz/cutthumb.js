const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => {
  const H = await start('drills.t451.html');
  for (const ch of ['chord-loop', 'cards-elements']) {
    const p = await H.open({ path: '?book=cutouts&ch=' + ch + '&lang=en', w: 1800, h: 2600 });
    await p.waitForTimeout(1800); await p.evaluate(() => { document.documentElement.style.zoom = 2; }); await p.waitForTimeout(800);
    for (const el of await p.$$('section.bk-page')) if (await el.isVisible()) { await el.screenshot({ path: '/tmp/claude-0/shots/th-' + ch + '.png' }); break; }
    await p.context().close();
  }
  await H.close(); process.exit(0);
})();
