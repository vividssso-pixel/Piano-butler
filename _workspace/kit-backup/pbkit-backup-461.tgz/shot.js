const { chromium } = require('/home/claude/pbtest/node_modules/playwright');
(async () => { const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' }); const p = await b.newPage({ viewport: { width: Number(process.argv[4] || 1100), height: Number(process.argv[5] || 500) } });
  await p.goto('file://' + process.argv[2]); await p.waitForTimeout(300); await p.screenshot({ path: process.argv[3], fullPage: true }); await b.close(); })();
