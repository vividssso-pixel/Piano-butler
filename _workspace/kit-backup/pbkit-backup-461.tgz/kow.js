const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => {
  const H = await start('drills.t436b.html');
  const p = await H.open({ path: '?book=work&ch=front&lang=ko', w: 1000, h: 1400, dsf: 2 });
  await p.evaluate(() => Promise.all([document.fonts.load('700 12px Cinzel'), document.fonts.load("700 15px 'Cormorant Garamond'")]));
  const r = await p.evaluate(() => {
    rdCtx = null;
    const out = [];
    for (const s of ['걸음·건너뛰기', '온음과 반음', '✓ 오선 전체', 'Steps & skips', '✓ Note values']) {
      const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); svg.setAttribute('width', 400); svg.setAttribute('height', 50);
      svg.innerHTML = stT(0, 30, s, { size: 16.5, weight: 700, font: TH_SERIF });
      document.body.appendChild(svg);
      const bb = svg.querySelector('text').getBBox();
      out.push([s, rdWidth(s, 700, 16.5, TH_SERIF).toFixed(1), bb.width.toFixed(1), getComputedStyle(svg.querySelector('text')).fontFamily]);
    }
    return out;
  });
  console.log(JSON.stringify(r, null, 1)); await H.close();
})();
