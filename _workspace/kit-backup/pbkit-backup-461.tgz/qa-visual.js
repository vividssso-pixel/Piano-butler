// QA B: every drill level, 25 questions mounted one by one (360px wide): render errors, and on every staff each note head
// sits on a line or in a space, ledger lines where they belong (no missing, no extra), stems the right way.
const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => {
  const H = await start(process.env.BUILD || 'drills.t447.html');
  const p = await H.open({ path: '?lang=' + (process.env.LANGX || 'en'), w: 1024, h: 900 }); await p.waitForTimeout(1500); await p.evaluate((t) => { window.__T = t; }, process.env.TARGETS);
  const TARGETS = process.env.TARGETS;
  const r = await p.evaluate(async (N) => { const TARGETS = window.__T;
    const out = [], sleep = (ms) => new Promise(r => setTimeout(r, ms));
    const host = document.createElement('div'); host.style.cssText = 'position:absolute;left:0;top:0;width:360px;background:#fff'; document.body.appendChild(host);
    const errs = []; const oe = console.error; console.error = (...a) => { errs.push(a.map(String).join(' ').slice(0, 200)); };
    const analyse = (root) => {
      const probs = [];
      root.querySelectorAll('svg').forEach(svg => {
        const P = (x, y, el) => { const m = el.getCTM(); const pt = svg.createSVGPoint(); pt.x = x; pt.y = y; return pt.matrixTransform(m); };
        const H = []; svg.querySelectorAll('line').forEach(l => { const a = P(+l.getAttribute('x1'), +l.getAttribute('y1'), l), b = P(+l.getAttribute('x2'), +l.getAttribute('y2'), l); if (Math.abs(a.y - b.y) < 0.3) H.push({ y: a.y, x1: Math.min(a.x, b.x), x2: Math.max(a.x, b.x), dash: l.getAttribute('stroke-dasharray') }); });
        svg.querySelectorAll('rect').forEach(r => { const h = +r.getAttribute('height'), w = +r.getAttribute('width'); if (h > 0 && h <= 2 && w > 6) { const a = P(+r.getAttribute('x'), +r.getAttribute('y') + h / 2, r), b = P(+r.getAttribute('x') + w, +r.getAttribute('y') + h / 2, r); H.push({ y: a.y, x1: a.x, x2: b.x }); } });
        const longs = H.filter(l => l.x2 - l.x1 > 60 && !l.dash);
        const ys = [...new Set(longs.map(l => Math.round(l.y * 4) / 4))].sort((a, b) => a - b);
        const staves = [];
        for (let i = 0; i + 4 < ys.length; i++) { const g = ys.slice(i, i + 5), sp = (g[4] - g[0]) / 4; if (sp > 3 && g.every((y, k) => Math.abs(y - (g[0] + k * sp)) < 0.4)) { staves.push({ top: g[0], sp, x1: Math.min(...longs.filter(l => Math.abs(l.y - g[0]) < 0.3).map(l => l.x1)), x2: Math.max(...longs.filter(l => Math.abs(l.y - g[0]) < 0.3).map(l => l.x2)) }); i += 4; } }
        if (!staves.length) return;
        const heads = [];
        svg.querySelectorAll('ellipse').forEach(e => {
          const rx = +e.getAttribute('rx'), ry = +e.getAttribute('ry'); if (!(rx > 2.5 && rx < 12 && ry > 1.8 && ry < 9)) return;
          if ((e.getAttribute('fill') || '') === 'none' && !e.getAttribute('stroke')) return;
          heads.push({ e, rx, c: P(+e.getAttribute('cx'), +e.getAttribute('cy'), e) });
        });
        heads.forEach(({ e, rx, c }) => {
          const st = staves.filter(s => c.x >= s.x1 - 4 && c.x <= s.x2 + 4).sort((a, b) => Math.abs(c.y - (a.top + 2 * a.sp)) - Math.abs(c.y - (b.top + 2 * b.sp)))[0]; if (!st) return;
          const pos = (c.y - st.top) / (st.sp / 2);
          if (pos < -14 || pos > 22) return;
          if (Math.abs(pos - Math.round(pos)) > 0.15) { probs.push('head off line/space pos=' + pos.toFixed(2)); return; }
          const P0 = Math.round(pos);
          const grp = heads.filter(h => Math.abs(h.c.x - c.x) < rx * 2.2).map(h => Math.round((h.c.y - st.top) / (st.sp / 2)));   // a chord or harmonic interval shares its ledger lines
          const lo = Math.min(...grp), hi = Math.max(...grp);
          const need = []; if (lo <= -2) for (let k = -2; k >= lo; k -= 2) need.push(k); if (hi >= 10) for (let k = 10; k <= hi; k += 2) need.push(k);
          const own = []; if (P0 <= -2) for (let k = -2; k >= P0; k -= 2) own.push(k); if (P0 >= 10) for (let k = 10; k <= P0; k += 2) own.push(k);
          const shorts = H.filter(l => l.x2 - l.x1 <= 60 && l.x1 <= c.x + 2 && l.x2 >= c.x - 2).map(l => Math.round((l.y - st.top) / (st.sp / 2) * 10) / 10).filter(q => q <= -1.5 || q >= 9.5);
          const has = (k) => shorts.some(q => Math.abs(q - k) < 0.2);
          const miss = own.filter(k => !has(k)), extra = shorts.filter(q => !need.some(k => Math.abs(q - k) < 0.2) && Math.abs(q - Math.round(q)) < 0.2 && Math.round(q) % 2 === 0);
          if (miss.length) probs.push('missing ledger at pos ' + miss.join(',') + ' for head pos ' + P0);
          if (extra.length) probs.push('extra ledger at pos ' + [...new Set(extra)].join(',') + ' for head pos ' + P0);
        });
      });
      return probs;
    };
    const want = JSON.parse(TARGETS); const kept = [];
    for (const [id, lvn] of want) {
      const D = DRILLS.find(d => d.id === id), C = D.concept || D, L = C.levels.find(l => l.n === lvn);
      let prev = null, got = 0;
      for (let k = 0; k < 60 && got < 3; k++) {
        const q = C.generate(L, prev); prev = q;
        const div = document.createElement('div'); div.style.cssText = 'width:360px;padding:6px;border:1px solid #ccc;margin:4px'; host.appendChild(div);
        const root = ReactDOM.createRoot(div); root.render(React.createElement(C.Question, { q, given: null, locked: false, onAnswer: () => {}, pixel: false, level: L }));
        await sleep(80);
        const pr = analyse(div);
        if (pr.length) { div.id = 'keep' + kept.length; kept.push([id, lvn, pr.join('; ')]); got++; } else { root.unmount(); div.remove(); }
      }
    }
    out.push(...kept);
    console.error = oe;
    return out;
  }, +(process.env.N || 25)).catch(e => [['ERR', e.message]]);
  r.forEach(x => console.log(JSON.stringify(x)));
  for (let i = 0; i < r.length; i++) { const el = await p.$('#keep' + i); if (el) await el.screenshot({ path: '/tmp/claude-0/qv-' + i + '.png' }); }
  console.log('levels with findings: ' + r.length, 'page errors', p._errs.slice(0, 3).join(' | '));
  await H.close();
})();
