const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => { const H = await start('drills.t447.html'); const p = await H.open({ path: '', w: 800, h: 600 }); await p.waitForTimeout(1000);
  console.log(JSON.stringify(await p.evaluate(() => DRILLS.map(d => [d.id, ((d.concept || d).levels || []).length])))); await H.close(); })();
