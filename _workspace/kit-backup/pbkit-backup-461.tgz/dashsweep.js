const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => {
  const H = await start(process.env.BUILD || 'drills.t444.html');
  const p0 = await H.open({ path: '', w: 1024, h: 900 }); await p0.waitForTimeout(1200);
  const ids = await p0.evaluate(() => (typeof DRILLS !== 'undefined' ? DRILLS.map(d => d.id) : []));
  const books = await p0.evaluate(() => Object.keys(LESSON_BOOKS));
  await p0.context().close();
  const paths = [''].concat(ids.map(i => '?drill=' + i));
  books.forEach(b => ['lesson', 'work', 'teacher'].forEach(k => paths.push('?book=' + k + '&ch=' + b)));
  const hits = {}; let errs = 0;
  for (const lang of ['en', 'ko']) for (const path of paths) {
    const p = await H.open({ path: path + (path.includes('?') ? '&' : '?') + 'lang=' + lang, w: 1024, h: 900, lang }); await p.waitForTimeout(path.includes('book') ? 1800 : 900);
    const r = await p.evaluate(() => { const t = document.body.innerText; const m = t.match(/.{0,40}(--|-⁠-).{0,30}/g) || []; return m; });
    if (r.length) hits[lang + ' ' + path] = r.slice(0, 4);
    errs += p._errs.length; await p.context().close();
  }
  console.log(paths.length * 2 + ' pages, errors ' + errs); for (const k in hits) console.log(k, JSON.stringify(hits[k]));
  await H.close();
})();
