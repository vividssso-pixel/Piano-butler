const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => {
  const H = await start(process.env.BUILD);
  const p = await H.open({ path: '?book=spread&ch=' + (process.env.CH || 'tones'), w: 1100, h: 1400 }); await p.waitForTimeout(2500);
  const r = await p.evaluate(() => [...document.querySelectorAll('section.bk-page')].map((s, i) => (i + 1) + ' ' + (s.innerText || '').replace(/\s+/g, ' ').slice(0, 70)));
  console.log(r.join('\n')); console.log('errs', p._errs.slice(0, 3));
  await H.close();
})();
