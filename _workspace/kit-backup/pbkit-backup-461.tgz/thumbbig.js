const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => {
  const H = await start('drills.t450d.html');
  const p = await H.open({ path: '?lang=ko', w: 1400, h: 900 }); await p.waitForTimeout(1500);
  await p.evaluate(() => {
    const d = document.createElement('div'); d.id = 'fr'; d.style.cssText = 'position:fixed;left:0;top:0;width:1100px;background:#fff;z-index:99999;padding:10px;display:flex;gap:10px';
    document.body.appendChild(d);
    ReactDOM.createRoot(d).render(React.createElement(React.Fragment, null,
      React.createElement('div', { style: { width: 520, background: '#faf6ec' } }, React.createElement(PenArt, { shapes: wuThumbTunnel(0.5), vb: [0, 0, 204, 152] })),
      React.createElement('div', { style: { width: 520, background: '#faf6ec' } }, React.createElement(PenArt, { shapes: wuFingerBalance(0.54), vb: [0, 0, 204, 152] }))));
  });
  await p.waitForTimeout(800);
  await (await p.$('#fr')).screenshot({ path: '/tmp/claude-0/shots/thumb-big.png' });
  await H.close();
})();
