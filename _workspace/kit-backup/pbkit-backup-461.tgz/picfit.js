// does any picture spill out of its frame? (the svg's bottom below the picture box's bottom)
const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => { const H = await start(process.env.BUILD);
  for (const lang of ['en', 'ko']) { const p = await H.open({ path: '?book=lesson&ch=' + process.env.CH + '&lang=' + lang, w: 1000, h: 1400 }); await p.waitForTimeout(2600);
    const r = await p.evaluate(() => [...document.querySelectorAll('.bk-page')].map((pg, i) => { const b = pg.querySelector('.lb-pic'); if (!b) return (i + 1) + ':-'; const R = b.getBoundingClientRect(); const sv = b.querySelector('svg'); if (!sv) return (i + 1) + ':?'; const S = sv.getBoundingClientRect(); return (i + 1) + ':' + Math.round(R.bottom - S.bottom) + '/' + Math.round(S.top - R.top); }));
    console.log(lang, 'bottom gap/top gap', r.join(' ')); await p.context().close(); }
  await H.close(); })();
