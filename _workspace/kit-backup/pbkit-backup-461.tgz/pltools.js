const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => {
  const H = await start(process.env.BUILD || 'drills.t455.html');
  for (const id of ['steady-beat', 'count-ring', 'silent-beats', 'beat-or-rhythm', 'finger-beat', 'beat-groups', 'beat-target', 'count-aloud']) for (const lang of ['en', 'ko']) {
    const p = await H.open({ path: '?tool=' + id, w: 430, h: 900, lang }); await p.waitForTimeout(1600);
    const r = await p.evaluate(() => ({ title: (document.querySelector('.try-box') || {}).textContent ? document.querySelector('.try-box').textContent.slice(0, 50) : 'NO TRY BOX', h: document.body.innerText.slice(0, 80).replace(/\n/g, ' ') }));
    console.log(id, lang, '|', r.title, p._errs.join('|').slice(0, 200));
    if (lang === 'en' && ['count-ring', 'finger-beat'].includes(id)) await p.screenshot({ path: '/home/claude/pbtest/ch3a/shots/tool-' + id + '.png', fullPage: false });
    await p.context().close();
  }
  // the toolbox chapter list
  const p = await H.open({ path: '?view=toolbox', w: 1100, h: 1400, lang: 'en' }); await p.waitForTimeout(2000);
  const txt = await p.evaluate(() => document.body.innerText);
  const i = txt.indexOf('Pulse'); console.log('toolbox around Pulse:', txt.slice(i, i + 500).replace(/\n+/g, ' / '));
  console.log('errs', p._errs.join('|').slice(0, 200));
  await p.close?.(); await H.close();
})();
