// list every string / JSX text in the app that holds a reader-visible double dash (' --' or '-- ')
const fs = require('fs'); const parser = require('/home/claude/pbtest/node_modules/@babel/parser');
const h = fs.readFileSync(process.argv[2], 'utf8'); const open = '<script id="app-jsx" type="text/jsx-raw">';
const i = h.indexOf(open) + open.length, j = h.indexOf('</script>', i); const src = h.slice(i, j);
const ast = parser.parse(src, { sourceType: 'script', plugins: ['jsx'], ranges: true });
const out = []; const re = /(^|\s)--(\s|$)|\s--[^\s>-]|[^\s<!-]--\s/;
(function walk(n, fn) { if (!n || typeof n.type !== 'string') return; for (const k in n) { if (k === 'loc' || k === 'range' || k === 'leadingComments' || k === 'trailingComments' || k === 'innerComments') continue; const v = n[k];
  if (Array.isArray(v)) v.forEach(x => x && typeof x.type === 'string' && (walk(x, fn)));
  else if (v && typeof v.type === 'string') walk(v, fn); }
  if ((n.type === 'StringLiteral' || n.type === 'JSXText') && / --|-- /.test(n.value || '')) out.push({ t: n.type, s: n.start, e: n.end, line: src.slice(0, n.start).split('\n').length, v: n.value });
  if (n.type === 'TemplateElement' && / --|-- /.test(n.value.cooked || '')) out.push({ t: n.type, s: n.start, e: n.end, line: src.slice(0, n.start).split('\n').length, v: n.value.cooked });
})(ast.program);
const n = out.reduce((a, o) => a + (o.v.match(/ --|-- /g) || []).length, 0);
console.log(out.length + ' strings, ' + n + ' dashes'); fs.writeFileSync(process.argv[3], JSON.stringify(out));
