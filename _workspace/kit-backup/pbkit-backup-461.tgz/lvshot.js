const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => { const H = await start('drills.t447.html');
  const p = await H.open({ path: '?drill=staff&level=2&lang=en', w: 390, h: 844 }); await p.waitForTimeout(2500);
  await p.screenshot({ path: '/tmp/claude-0/lv-a.png' });
  const btns = await p.evaluate(() => [...document.querySelectorAll('button')].map(b => b.textContent.trim()).filter(Boolean).slice(0, 30));
  console.log(btns.join(' | '));
  await H.close(); })();
