const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => {
  const H = await start('drills.t444.html');
  for (const kind of ['lesson', 'work']) {
  const p = await H.open({ path: '?book=' + kind + '&ch=tones&lang=en', w: 900, h: 1200 }); await p.waitForTimeout(2500);
  const r = await p.evaluate(() => [...document.querySelectorAll('.lb-page, .bk-page')].map((pg, i) => '#### PAGE ' + (i + 1) + '\n' + pg.innerText + '\nIMGS: ' + [...pg.querySelectorAll('[role=img]')].map(d => d.getAttribute('aria-label')).join(' || ')));
  console.log('======== ' + kind); console.log(r.join('\n'));
  await p.context().close(); }
  await H.close();
})();
