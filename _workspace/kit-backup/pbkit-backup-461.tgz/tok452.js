const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => {
  const H = await start('drills.t452.html');
  const p = await H.open({ path: '?book=cutouts&ch=staff-mat&lang=en', w: 1000, h: 1400, dsf: 1.5 }); await p.waitForTimeout(2600);
  const els = await p.$$('.bk-page'); await els[1].screenshot({ path: '/tmp/claude-0/shots/tok452.png' });
  const info = await p.$$eval('.bk-page', els => els.map(e => { const b = e.querySelector('.bk-body'); return b.scrollHeight - b.clientHeight; }));
  // the time tile is exactly one staff tall: compare to the mat's staff on page 1
  const m = await p.evaluate(() => { const tile = document.querySelector('.bk-page:nth-of-type(2) svg[viewBox^="0 0 14 "]'); const svgs = [...document.querySelectorAll('.bk-page')][0].querySelectorAll('svg'); const mat = svgs[0]; const ls = [...mat.querySelectorAll('line')].map(l => l.getBoundingClientRect().top).filter((v, i, a) => a.indexOf(v) === i).sort((a, b) => a - b); return { tile: tile && tile.getBoundingClientRect().height, staff: ls.length >= 5 ? ls[4] - ls[0] : null }; });
  console.log('overflow', JSON.stringify(info), 'tile vs staff (px)', JSON.stringify(m), p._errs.join('|'));
  await H.close();
})();
