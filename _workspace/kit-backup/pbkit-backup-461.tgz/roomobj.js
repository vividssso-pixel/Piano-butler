// Room-object alternatives to the framed picture (her 2026-10-12 12:53): A frame (today), B glass dome on a stand,
// C arched window with curtains, D oval medallion hung from a bow tie, E fireplace with an overmantel mirror.
const { start } = require('/home/claude/pbtest/kit/contentharness'); const fs = require('fs');
const OUT = '/home/claude/pbtest/fix436/roomobj/';
const V = {
  B: `(cx, top, ic, faded) => {   // a glass dome on a round stand
    const T = top + 33, fl = top + 46, k = 0.5, iw = 48 * k, ih = 34 * k;
    return stR(cx - 16, T - 3, 32, 3, 0.9) + stR(cx - 13, T, 26, 2.2, 0.8) + stR(cx - 1.3, T + 2.2, 2.6, fl - T - 6, 0.7)
      + stP(stD('M', cx - 9, fl, 'Q', cx - 3, fl - 2, cx, fl - 4.5, 'Q', cx + 3, fl - 2, cx + 9, fl), 0.8, 'none')
      + '<path d="' + stD('M', cx - 14, T - 3, 'L', cx - 14, top + 8, 'A', 14, 14, 0, 0, 1, cx + 14, top + 8, 'L', cx + 14, T - 3) + '" fill="#fff" stroke-width="1.1"/>'
      + '<path d="' + stD('M', cx + 9.5, top + 3, 'A', 10, 10, 0, 0, 1, cx + 11, top + 12) + '" fill="none" stroke-width="0.6" opacity="0.5"/>'
      + stC(cx, top - 7.6, 1.6, 0.8)
      + '<g transform="translate(' + pFix(cx - iw / 2) + ' ' + pFix(top + 11) + ') scale(' + k + ')" fill="none" stroke="' + ST.N + '" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" opacity="' + (faded ? 0.5 : 1) + '">' + ic + '</g>';
  }`,
  C: `(cx, top, ic, faded) => {   // an arched window with its curtains tied back
    const k = 0.55, iw = 48 * k, ih = 34 * k, w = 19;
    const arch = (a) => stD('M', cx - w + a, top + 33, 'L', cx - w + a, top + 12, 'A', w - a, w - a, 0, 0, 1, cx + w - a, top + 12, 'L', cx + w - a, top + 33, 'Z');
    let s = stP(arch(0), 1.1) + stP(arch(3), 0.45, 'none') + stR(cx - w - 4, top + 33, 2 * w + 8, 3, 0.9);
    s += stL(cx - w - 9, top - 5, cx + w + 9, top - 5, 0.9) + stC(cx - w - 10, top - 5, 1.3, 0, ST.N) + stC(cx + w + 10, top - 5, 1.3, 0, ST.N);
    [-1, 1].forEach(sd => { const x0 = cx + sd * (w + 7);   // a curtain: falls from the rod, tied back at the middle, then down to the sill
      s += stP(stD('M', x0 - sd * 5, top - 5, 'L', x0 + sd * 3, top - 5, 'Q', x0 + sd * 2, top + 14, x0 + sd * 1, top + 17, 'Q', x0 + sd * 3, top + 26, x0 + sd * 4, top + 33, 'L', x0 - sd * 3, top + 33, 'Q', x0 - sd * 2, top + 24, x0 - sd * 1, top + 17, 'Q', x0 - sd * 7, top + 8, x0 - sd * 5, top - 5, 'Z'), 0.8)
        + stC(x0, top + 17, 1.4, 0, ST.C); });
    return s + '<g transform="translate(' + pFix(cx - iw / 2) + ' ' + pFix(top + 11) + ') scale(' + k + ')" fill="none" stroke="' + ST.N + '" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" opacity="' + (faded ? 0.5 : 1) + '">' + ic + '</g>';
  }`,
  D: `(cx, top, ic, faded) => {   // an oval medallion hung from the butler's bow tie
    const k = 0.55, iw = 48 * k, ih = 34 * k, cy = top + 15.5;
    let s = '<ellipse cx="' + pFix(cx) + '" cy="' + pFix(cy) + '" rx="23" ry="17.5" stroke-width="1.1"/>' + '<ellipse cx="' + pFix(cx) + '" cy="' + pFix(cy) + '" rx="20" ry="14.5" fill="none" stroke-width="0.45"/>';
    s += '<path d="' + stD('M', cx - 8, top - 6, 'L', cx - 1.5, top - 2.5, 'L', cx - 8, top + 1, 'Z', 'M', cx + 8, top - 6, 'L', cx + 1.5, top - 2.5, 'L', cx + 8, top + 1, 'Z') + '" fill="#fff" stroke-width="1" stroke-linejoin="round"/>' + stC(cx, top - 2.5, 1.5, 0, ST.C);
    return s + '<g transform="translate(' + pFix(cx - iw / 2) + ' ' + pFix(cy - ih / 2) + ') scale(' + k + ')" fill="none" stroke="' + ST.N + '" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" opacity="' + (faded ? 0.5 : 1) + '">' + ic + '</g>';
  }`,
  E: `(cx, top, ic, faded) => {   // a fireplace: the mantel shelf, an arched mirror above it, a little fire below
    const k = 0.5, iw = 48 * k, ih = 34 * k, M = top + 31, fl = top + 46;
    let s = stP(stD('M', cx - 15, M, 'L', cx - 15, top + 6, 'A', 15, 11, 0, 0, 1, cx + 15, top + 6, 'L', cx + 15, M, 'Z'), 1.1) + stP(stD('M', cx - 12.5, M - 2, 'L', cx - 12.5, top + 7, 'A', 12.5, 8.5, 0, 0, 1, cx + 12.5, top + 7, 'L', cx + 12.5, M - 2, 'Z'), 0.45, 'none');
    s += stR(cx - 21, fl - (fl - M - 3), 42, fl - M - 3, 0.9) + stR(cx - 23, M, 46, 3, 0.9);
    s += '<path d="' + stD('M', cx - 9, fl, 'L', cx - 9, M + 8, 'A', 9, 5, 0, 0, 1, cx + 9, M + 8, 'L', cx + 9, fl, 'Z') + '" fill="' + ST.N + '" stroke="none"/>';
    s += '<path d="' + stD('M', cx - 4, fl - 1, 'Q', cx - 5, fl - 6, cx - 1.5, fl - 9, 'Q', cx - 1, fl - 5, cx + 1, fl - 5.5, 'Q', cx + 1, fl - 9, cx + 3, fl - 10, 'Q', cx + 6, fl - 5, cx + 4, fl - 1, 'Z') + '" fill="' + ST.C + '" stroke="none"/>';
    return s + '<g transform="translate(' + pFix(cx - iw / 2) + ' ' + pFix(top + 9) + ') scale(' + k + ')" fill="none" stroke="' + ST.N + '" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" opacity="' + (faded ? 0.5 : 1) + '">' + ic + '</g>';
  }`,
  F: `(cx, top, ic, faded) => {   // no frame: the picture alone, a little bigger, on the wall
    const k = 0.8, iw = 48 * k, ih = 34 * k;
    return '<g transform="translate(' + pFix(cx - iw / 2) + ' ' + pFix(top + 2) + ') scale(' + k + ')" fill="none" stroke="' + ST.N + '" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" opacity="' + (faded ? 0.5 : 1) + '">' + ic + '</g>';
  }`,
};
(async () => {
  const L = JSON.parse(fs.readFileSync('/home/claude/pbtest/plan435/levels.json'));
  const H = await start('drills.t436d.html');
  for (const key of (process.argv[2] || 'ABCDE').split('')) for (const wide of [true, false]) {
    const p = await H.open({ path: '?book=work&ch=front&lang=en', w: 1000, h: 1400, dsf: 2 });
    await p.evaluate(() => Promise.all([document.fonts.load('700 12px Cinzel'), document.fonts.load("700 15px 'Cormorant Garamond'")]));
    const svg = await p.evaluate(({ src, wide }) => {
      rdCtx = null;
      if (src) thPic = eval(src);
      const stages = PATH_STAGES.map((s, i) => { const ids = pathStageIds(s); return { s, i, ids, st: ids.map(id => ['posture-hands', 'first-steps', 'pulse', 'note-names'].includes(id) ? 'done' : id === 'note-values' ? 'started' : 'new') }; });
      const nums = {}; stages.flatMap(x => x.ids).forEach((id, k) => { nums[id] = k + 1; });
      const h = townhouseSvg({ stages, here: 'note-values', nums }, { wide }); return penSvg([{ k: 'raw', svg: h.svg }], { vb: h.vb, id: 'ro' });
    }, { src: V[key] || null, wide });
    await p.evaluate(({ svg, wide }) => { document.body.innerHTML = '<div id="mock" style="width:' + (wide ? 900 : 420) + 'px;background:#fff">' + svg.replace('<svg ', '<svg style="width:100%;display:block" ') + '</div>'; }, { svg, wide });
    await p.waitForTimeout(300);
    await (await p.$('#mock')).screenshot({ path: OUT + key + '-' + (wide ? 'wide' : 'tall') + '.png' });
    await p.context().close();
  }
  await H.close(); console.log('ok');
})();
