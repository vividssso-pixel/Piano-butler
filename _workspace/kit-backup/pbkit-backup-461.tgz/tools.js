const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => { const H = await start('drills.t448.html'); const p = await H.open({ path: '?lang=en', w: 800, h: 600 }); await p.waitForTimeout(1000);
  const r = await p.evaluate(() => ({ tools: TOOLS.map(t => [t.id, t.title || t.label || t.name, t.ch || t.chapter || t.track || t.concept || '', (t.blurb || '').slice(0, 90)]), drills: DRILLS.map(d => [d.id, d.label, ((d.concept || d).levels || []).map(l => l.label).join(' / ')]) }));
  console.log(JSON.stringify(r)); await H.close(); })();
