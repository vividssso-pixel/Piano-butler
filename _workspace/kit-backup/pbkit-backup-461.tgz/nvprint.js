const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => { const H = await start(process.env.BUILD);
  for (const lv of [9, 2, 5]) { const p = await H.open({ path: '?print=1&drill=note-values&level=' + lv, w: 760, h: 1400, lang: 'en' }); await p.waitForTimeout(1500);
    await p.screenshot({ path: '/tmp/claude-0/shots/nvprint' + lv + '.png', clip: { x: 0, y: 0, width: 760, height: 1400 } }); await p.context().close(); }
  await H.close(); })();
