const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => { const H = await start('drills.t444.html');
  const p = await H.open({ path: '?drill=pulse&lang=en', w: 900, h: 1400 }); await p.waitForTimeout(1500);
  // open every step
  const txt = await p.evaluate(async () => { const out = []; const steps = [...document.querySelectorAll('[id^="pulse-step-"]')]; for (const s of steps) out.push(s.innerText.slice(0, 1500)); return { n: steps.length, body: steps.length ? out.join('\n=====\n') : document.body.innerText.slice(0, 6000) }; });
  console.log('STEPS', txt.n); console.log(txt.body);
  await p.screenshot({ path: 'pack446/app-now.png', fullPage: true });
  await p.context().close();
  for (const kind of ['work', 'teacher', 'lesson']) {
    const b = await H.open({ path: '?book=' + kind + '&ch=pulse&lang=en', w: 900, h: 1200 }); await b.waitForTimeout(2500);
    const r = await b.evaluate(() => ({ n: document.querySelectorAll('.bk-page').length, t: document.body.innerText.slice(0, 5000) }));
    console.log('==== BOOK', kind, r.n); console.log(r.t);
    await b.context().close(); }
  await H.close(); })();
