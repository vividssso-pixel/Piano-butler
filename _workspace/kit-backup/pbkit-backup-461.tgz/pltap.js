// Tap timing test: press the space bar on the audio clock's beat times and read the verdicts
const { start } = require('/home/claude/pbtest/kit/contentharness');
const SPB = 60 / 72;
// in the page: click a button, then schedule taps at beat offsets (in beats from the first beat after `lead` count-in beats)
const tapPlan = async (p, btnSel, beats, opts = {}) => p.evaluate(({ btnSel, beats, SPB, jitter }) => new Promise(res => {
  const btn = [...document.querySelectorAll('button')].find(b => b.textContent.trim().startsWith(btnSel) && !b.disabled);
  if (!btn) return res('no button ' + btnSel);
  btn.click();
  const ctx = window.__pbAudio, t0 = ctx.currentTime + 0.18, lat = outLatency(ctx);
  beats.forEach((b, i) => { const at = t0 + b * SPB + lat + (jitter ? jitter[i % jitter.length] : 0); setTimeout(() => window.dispatchEvent(new KeyboardEvent('keydown', { code: 'Space', key: ' ' })), Math.max(0, (at - ctx.currentTime) * 1000)); });
  res('ok lat ' + lat.toFixed(3));
}), { btnSel, beats, SPB, jitter: opts.jitter || null });
(async () => {
  const H = await start(process.env.BUILD || 'drills.t455.html');
  const range = (a, b) => Array.from({ length: b - a }, (_, i) => a + i);
  // drill levels
  const runLevel = async (lv, plan, label) => {
    const p = await H.open({ path: '?drill=pulse&tab=drill&level=' + lv, w: 430, h: 900, lang: 'en' }); await p.waitForTimeout(1200);
    const prompt = await p.evaluate(() => (document.querySelector('.card p') || {}).textContent || '');
    const beats = typeof plan === 'function' ? plan(prompt) : plan;
    console.log('L' + lv, label, await tapPlan(p, '▶ Start', beats));
    await p.waitForTimeout(15000);
    const fb = await p.evaluate(() => { const c = [...document.querySelectorAll('.card span')].map(d => d.textContent).find(t => / correct$/.test(t)) || ''; return c + ' / ' + [...document.querySelectorAll('.card div')].map(d => d.textContent).filter(t => /Not quite/.test(t)).slice(-1).join(''); });
    console.log('   ', fb.slice(0, 160), p._errs.join('|').slice(0, 200));
    await p.context().close();
  };
  await runLevel(2, range(4, 12), 'tap all 8 beats');
  await runLevel(2, range(4, 12).map(b => b + (b % 2 ? 0.35 : 0)), 'every other tap 0.35 beat late');
  await runLevel(3, range(4, 12), 'tap with clicks then alone');
  await runLevel(3, [...range(4, 8), 8.6, 9.6, 10.6, 11.6], 'alone part rushed by 0.4');
  await runLevel(4, (pr) => { const n = +(pr.match(/only on (\d)/) || [0, 1])[1]; return [4 + n - 1, 8 + n - 1]; }, 'beat N twice');
  await runLevel(4, (pr) => { const n = +(pr.match(/only on (\d)/) || [0, 1])[1]; return [4 + n - 1, 8 + n - 1, 4 + (n % 4)]; }, 'beat N twice plus an extra');
  await runLevel(5, range(4, 8), 'tap the 4 beats');
  await runLevel(5, [4, 4.5, 5, 5.5, 6, 6.5, 7, 7.5], 'tap every half beat (like the words)');
  // the book's live parts
  const p = await H.open({ path: '?drill=pulse', w: 430, h: 900, lang: 'en' }); await p.waitForTimeout(1500);
  console.log('steady pad', await tapPlan(p, '▶ With the click', range(4, 12)));
  await p.waitForTimeout(11500);
  console.log('   ', await p.evaluate(() => [...document.querySelectorAll('[data-pl="steady"] div')].map(d => d.textContent).filter(t => /Steady:|gaps change|Tap 8/.test(t)).join(' | ')));
  console.log('silent', await p.evaluate(() => { document.querySelector('[data-pl="silent"]').scrollIntoView(); return 1; }));
  // silent: start button inside [data-pl=silent]; play on 1 and 2 -> beats 4,5,8,9
  console.log('   ', await p.evaluate(({ SPB }) => new Promise(res => { const box = document.querySelector('[data-pl="silent"]'); const btn = [...box.querySelectorAll('button')].find(b => b.textContent.includes('Start')); btn.click(); const ctx = window.__pbAudio, t0 = ctx.currentTime + 0.18, lat = outLatency(ctx);
    [4, 5, 8, 9].forEach(b => setTimeout(() => window.dispatchEvent(new KeyboardEvent('keydown', { code: 'Space', key: ' ' })), (t0 + b * SPB + lat - ctx.currentTime) * 1000)); res('scheduled'); }), { SPB }));
  await p.waitForTimeout(11500);
  console.log('   ', await p.evaluate(() => [...document.querySelectorAll('[data-pl="silent"] div')].map(d => d.textContent).filter(t => /Played on time/.test(t)).join(' | ')));
  console.log('   errs', p._errs.join('|').slice(0, 300));
  await p.context().close();
  await H.close();
})();
