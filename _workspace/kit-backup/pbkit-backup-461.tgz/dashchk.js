const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => {
  const H = await start('drills.t439.html');
  for (const [path, lang] of [['?book=lesson&ch=ledger-lines&lang=en', 'en'], ['?book=lesson&ch=tones&lang=ko', 'ko'], ['?drill=tones', 'en']]) {
    const p = await H.open({ path, w: 900, h: 1200, lang }); await p.waitForTimeout(2500);
    const r = await p.evaluate(() => { const t = document.body.innerText; return { plain: (t.match(/ -- /g) || []).length, glued: (t.match(/ -⁠-/g) || []).length, lang: document.documentElement.lang, wb: getComputedStyle(document.body).wordBreak }; });
    console.log(path, JSON.stringify(r), p._errs.length ? 'ERR ' + p._errs[0] : '');
    await p.context().close();
  }
  await H.close();
})();
