const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => {
  const H = await start(process.argv[2]);
  const p = await H.open({ path: '?book=lesson&ch=tones&lang=ko', w: 900, h: 1200 }); await p.waitForTimeout(2600);
  const pages = await p.$$('.bk-page'); await pages[1].screenshot({ path: '/tmp/claude-0/ko-' + process.argv[3] + '.png' });
  await H.close();
})();
