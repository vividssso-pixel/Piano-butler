const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => {
  const H = await start('drills.t450.html');
  for (const lang of ['ko', 'en']) {
    const p = await H.open({ path: '?drill=posture-hands&lang=' + lang, w: 820, h: 1000 }); await p.waitForTimeout(2500);
    const el = await p.$('[data-thumb-moves]');
    if (!el) { console.log('no element', lang); continue; }
    await el.scrollIntoViewIfNeeded(); await p.waitForTimeout(300);
    for (let i = 0; i < 56; i++) { await el.screenshot({ path: `/tmp/claude-0/shots/tg-${lang}-${String(i).padStart(2, '0')}.png` }); await p.waitForTimeout(100); }
    console.log(lang, 'ok', p._errs.join('|')); await p.context().close();
  }
  await H.close();
})();
