const { chromium } = require('/home/claude/pbtest/node_modules/playwright');
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' }); const p = await b.newPage({ viewport: { width: 460, height: 340 } });
  const svg = require('fs').readFileSync(process.argv[2], 'utf8');
  await p.setContent('<body style="margin:10px;background:#fff">' + svg + '</body>'); await p.waitForTimeout(300);
  await p.screenshot({ path: process.argv[3] }); await b.close();
})();
