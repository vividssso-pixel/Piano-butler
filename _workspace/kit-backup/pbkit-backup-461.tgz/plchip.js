const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => {
  const H = await start(process.env.BUILD || 'drills.t455.html');
  for (const lang of ['en', 'ko']) {
    const p = await H.open({ path: '?tool=beat-or-rhythm', w: 360, h: 800, lang, dsf: 2 }); await p.waitForTimeout(1500);
    const chips = await p.$$('[data-pl="words"] button.chip'); await chips[2].click(); await p.waitForTimeout(300);
    const box = await p.$('[data-pl="words"]'); await box.screenshot({ path: '/tmp/claude-0/chip3-' + lang + '.png' });
    const ov = await p.evaluate(() => { const ws = [...document.querySelectorAll('[data-pl="words"] div')].filter(d => d.style.whiteSpace === 'nowrap'); const r = ws.map(d => d.getBoundingClientRect()); let o = 0; for (let i = 1; i < r.length; i++) o = Math.max(o, r[i - 1].right - r[i].left); return o; });
    console.log(lang, 'max overlap px', ov.toFixed(1));
    await p.context().close();
  }
  await H.close();
})();
