const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => {
  const H = await start('drills.p395.html');
  const p = await H.open({ path: '?drill=first-steps', w: 390, h: 1000 });
  await p.waitForTimeout(900);
  const el = await p.$('#first-steps-step-4 [data-five-checks]'); await el.scrollIntoViewIfNeeded();
  const b = await p.$$('#first-steps-step-4 [data-five-checks] button[aria-pressed]'); await b[2].click(); await b[4].click(); await p.waitForTimeout(200);
  await el.screenshot({ path: '/home/claude/pbtest/kit/p395/app-checks.png' });
  console.log('errs', p._errs.join('|'));
  await H.close(); process.exit(0);
})();
