const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => {
  const H = await start('drills.p394.html');
  for (const [ch, n, out] of [['first-steps', 3, 'first-steps-worksheet'], ['posture-hands', 2, 'posture-hands-worksheet']]) {
    const p = await H.open({ path: '?book=work&ch=' + ch + '&lang=en', w: 900, h: 1300 });
    await p.waitForTimeout(1800);
    const pg = (await p.$$('.bk-page'))[n - 1];
    const no = await pg.evaluate(e => e.innerText.slice(0, 80));
    await pg.screenshot({ path: '/tmp/claude-0/' + out + '.png' });
    console.log(out, JSON.stringify(no.slice(0, 60)), p._errs.join('|'));
    await p.context().close();
  }
  await H.close(); process.exit(0);
})();
