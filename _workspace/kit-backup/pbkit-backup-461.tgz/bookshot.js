// every page of a book as PNGs: BOOK=lesson CH=ledger-lines LANG=ko
const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => {
  const H = await start(process.env.BUILD);
  const p = await H.open({ path: '?book=' + process.env.BOOK + '&ch=' + process.env.CH + '&lang=' + process.env.LANG, w: 1000, h: 1400 });
  await p.waitForTimeout(3500);
  const els = await p.$$('.bk-page'); let i = 0;
  for (const el of els) { i++; await el.screenshot({ path: '/tmp/claude-0/shots/' + process.env.TAG + '-' + process.env.CH + '-' + process.env.LANG + '-' + i + '.png' }); }
  console.log(process.env.CH, els.length, p._errs.join('|')); await H.close();
})();
