const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => {
  const H = await start('drills.nn396.html');
  const p = await H.open({ path: '?book=lesson&ch=note-names&lang=en&draft=1', w: 900, h: 1200 });
  await p.waitForTimeout(2000);
  await p.pdf({ path: '/mnt/user-data/outputs/Chapter-03-Lesson-Book-draft-v2.pdf', preferCSSPageSize: true, printBackground: true });
  await H.close(); process.exit(0);
})();
