const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => { const H = await start('drills.t444.html');
  const p = await H.open({ path: '?drill=pulse&lang=en', w: 820, h: 1100 }); await p.waitForTimeout(1500);
  await p.screenshot({ path: 'pack446/app-now.png' }); await p.context().close();
  for (const n of [3, 4]) { const b = await H.open({ path: '?book=work&ch=pulse&lang=en&pages=' + n, w: 1800, h: 2600 }); await b.waitForTimeout(1500);
    await b.evaluate(() => { document.documentElement.style.zoom = 1.4; }); await b.waitForTimeout(600);
    for (const pg of await b.$$('section.bk-page')) if (await pg.isVisible()) { await pg.screenshot({ path: 'pack446/wb-old-' + n + '.png' }); break; }
    await b.context().close(); }
  await H.close(); })();
