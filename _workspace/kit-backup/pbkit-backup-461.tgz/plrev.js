const { start } = require('/home/claude/pbtest/kit/contentharness');
const OUT = '/home/claude/pbtest/ch3a/review/';
(async () => {
  const H = await start(process.env.BUILD || 'drills.t455.html');
  for (const [kind, lang] of [['lesson', 'en'], ['lesson', 'ko'], ['work', 'en'], ['teacher', 'en']]) {
    const p = await H.open({ path: '?book=' + kind + '&ch=pulse&lang=' + lang, w: 1000, h: 1400 }); await p.waitForTimeout(3000);
    const els = await p.$$('.bk-page');
    for (let i = 0; i < els.length; i++) await els[i].screenshot({ path: OUT + kind + '-' + lang + '-' + (kind === 'work' ? i + 2 : i + 1) + '.png' });
    console.log(kind, lang, els.length, p._errs.join('|'));
    await p.context().close();
  }
  for (const lang of ['en', 'ko']) {
    const p = await H.open({ path: '?drill=pulse', w: 390, h: 860, lang, dsf: 1.5 }); await p.waitForTimeout(1800);
    await p.screenshot({ path: OUT + 'app-' + lang + '-top.png' });
    const boxes = await p.$$('.try-box');
    for (let i = 0; i < boxes.length; i++) { await boxes[i].scrollIntoViewIfNeeded(); await boxes[i].screenshot({ path: OUT + 'app-' + lang + '-page' + (i + 2) + '.png' }); }
    await p.context().close();
  }
  for (let lv = 1; lv <= 5; lv++) { const p = await H.open({ path: '?drill=pulse&tab=drill&level=' + lv, w: 390, h: 860, lang: 'en', dsf: 1.5 }); await p.waitForTimeout(1500); await p.screenshot({ path: OUT + 'drill-level' + lv + '.png' }); await p.context().close(); }
  await H.close();
})();
