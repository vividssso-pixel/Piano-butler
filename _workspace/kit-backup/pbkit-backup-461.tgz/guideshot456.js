const { chromium } = require('/home/claude/pbtest/kit/node_modules/playwright');
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  for (const [w, tag] of [[1280, 'desk'], [390, 'phone']]) {
    const p = await b.newPage({ viewport: { width: w, height: 900 }, deviceScaleFactor: w < 500 ? 2 : 1 });
    const errs = []; p.on('pageerror', e => errs.push(e.message));
    await p.goto('file:///home/claude/pbtest/g456/repo/lessons/pulse-and-counting.html'); await p.waitForTimeout(1200);
    const r = await p.evaluate(() => { const t = document.body.innerText; return { dash: (t.match(/.{0,30}(--|—|–).{0,30}/g) || []), hscroll: document.documentElement.scrollWidth - document.documentElement.clientWidth, colons: t.split(/(?<=[.!?])\s+/).filter(s => (s.match(/:/g) || []).length > 1).slice(0, 5), imgs: [...document.querySelectorAll('svg')].length }; });
    console.log(tag, JSON.stringify(r), errs.join('|'));
    await p.screenshot({ path: '/tmp/claude-0/guide456-' + tag + '.png', fullPage: true });
    await p.close();
  }
  await b.close();
})();
