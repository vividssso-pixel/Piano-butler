// the wide house on a big screen (hall, then inside) and the Workbook's page to colour in
const { start } = require('./contentharness');
(async () => {
  const H = await start(process.env.BUILD || 'drills.t426.html');
  const full = (n) => { const o = {}; for (let i = 0; i < n; i++) o[i] = 1; return o; };
  const store = { pb_lesson_steps_v1: JSON.stringify({ 'posture-hands': full(6), 'first-steps': full(9), 'note-names': full(8), staff: { 0: 1, 1: 1 } }), pb_steps_total_v1: JSON.stringify({ 'posture-hands': 6, 'first-steps': 9, 'note-names': 8, staff: 7 }) };
  const w = await H.open({ path: '?view=map', w: 1200, h: 900, store, dsf: 2 }); await w.waitForTimeout(1300);
  console.log('wide', await w.$eval('[data-house]', e => e.getAttribute('data-wide') + ' ' + e.getAttribute('data-layout') + ' ' + e.clientWidth));
  await (await w.$('[data-house-view]')).screenshot({ path: 'p425/w428-hall.png' });
  await (await w.$('[data-door]')).click(); await w.waitForTimeout(1800);
  await (await w.$('[data-house-view]')).screenshot({ path: 'p425/w428-house.png' });
  console.log('rooms', await w.$$eval('[data-chapter]', a => a.length), w._errs.join('|'));
  const b = await H.open({ path: '?book=work&ch=front&lang=en', w: 900, h: 1200, dsf: 2 }); await b.waitForTimeout(2600);
  const pages = await b.$$('.bk-page'); console.log('front pages', pages.length);
  for (let i = 0; i < pages.length; i++) { const txt = await pages[i].innerText(); if (/Piano Butler’s house/.test(txt)) { await pages[i].screenshot({ path: 'p425/wb428-house.png' }); console.log('house page', i + 1); } }
  console.log(b._errs.join('|'));
  await H.close();
})().catch(e => { console.error('CRASH', e); process.exit(1); });
