const { start } = require('./contentharness');
(async () => {
  const H = await start('drills.new.html');
  const p1 = await H.open({ path: '?drill=posture-hands', w: 390, h: 900 });
  const warmSel = '#posture-hands-step-1 [data-warm]';
  await p1.waitForTimeout(600);
  const cards = await p1.$$(warmSel);
  console.log('cards', cards.length);
  // all playing without any tap: svg should change over time on every card
  const snap = async () => p1.$$eval(warmSel, els => els.map(e => e.querySelector('svg').innerHTML.length));
  const a = await snap(); await p1.waitForTimeout(700); const b = await snap();
  console.log('autoplay (lengths differ per card):', JSON.stringify(a), '->', JSON.stringify(b), a.map((x, i) => x !== b[i]));
  const names = ['rag', 'wings', 'glide', 'drop', 'bridge', 'balloon'];
  for (let k = 0; k < 3; k++) {
    for (let i = 0; i < cards.length; i++) {
      await p1.evaluate(({ sel, j }) => document.querySelectorAll(sel)[j].scrollIntoView({ block: "center" }), { sel: warmSel, j: i });
      await cards[i].screenshot({ path: 'warm-' + names[i] + '-' + k + '.png' });
    }
    await p1.waitForTimeout(1100);
  }
  console.log('errs:', p1._errs.join('|') || 'none');
  await p1.context().close(); await H.close(); process.exit(0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
