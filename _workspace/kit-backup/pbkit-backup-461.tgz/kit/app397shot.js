const { start } = require('./contentharness');
(async () => {
  const H = await start(process.env.BUILD || 'drills.t397.html');
  const p = await H.open({ path: '?drill=note-names', w: 390, h: 900, lang: process.env.LANGX || 'en' });
  await p.waitForTimeout(800);
  for (const i of [3, 5]) { const el = await p.$('#note-names-step-' + i); await el.screenshot({ path: 'p397/app-step' + (i + 1) + '.png' }); }
  await p.click('#note-names-step-3 [data-who-lives] [data-key="7"]'); await p.waitForTimeout(300);
  await (await p.$('#note-names-step-3 [data-who-lives]')).screenshot({ path: 'p397/app-who.png' });
  const tab = await p.$('button:has-text("Drill")'); await tab.click(); await p.waitForTimeout(600);
  await (await p.$('button:has-text("Level 5")')).click(); await p.waitForTimeout(900);
  await p.screenshot({ path: 'p397/app-l5.png' });
  await H.close(); process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
