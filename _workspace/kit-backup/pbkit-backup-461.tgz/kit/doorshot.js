// the hall first; through the door the house rises, anchored at the bottom (frames for a GIF + stills)
const { start } = require('./contentharness');
const fs = require('fs');
(async () => {
  const H = await start(process.env.BUILD || 'drills.t426.html');
  const full = (n) => { const o = {}; for (let i = 0; i < n; i++) o[i] = 1; return o; };
  const store = { pb_lesson_steps_v1: JSON.stringify({ 'posture-hands': full(6), 'first-steps': full(9), 'note-names': full(8), staff: { 0: 1, 1: 1 } }), pb_steps_total_v1: JSON.stringify({ 'posture-hands': 6, 'first-steps': 9, 'note-names': 8, staff: 7 }) };
  const p = await H.open({ path: '?view=map', w: 390, h: 844, store, dsf: 2 }); await p.waitForTimeout(1200);
  fs.mkdirSync('p425/door', { recursive: true });
  const door = await p.$('[data-door]');
  await door.scrollIntoViewIfNeeded(); await p.evaluate(() => window.scrollBy(0, 120)); await p.waitForTimeout(300);
  await p.screenshot({ path: 'p425/door/hall.png' });
  console.log('layout', await p.$eval('[data-house]', e => e.getAttribute('data-layout')));
  const before = await p.evaluate(() => document.querySelector('[data-house-view]').getBoundingClientRect().bottom);
  await door.click();
  for (let i = 0; i < 26; i++) { await p.screenshot({ path: 'p425/door/f' + String(i).padStart(2, '0') + '.png' }); await p.waitForTimeout(70); }
  await p.waitForTimeout(900);
  await p.screenshot({ path: 'p425/door/after.png' }); await (await p.$('[data-house-view]')).screenshot({ path: 'p425/s428-townhouse.png' });
  const after = await p.evaluate(() => document.querySelector('[data-house-view]').getBoundingClientRect().bottom);
  console.log('anchor bottom before/after', before, after, 'layout', await p.$eval('[data-house]', e => e.getAttribute('data-layout')), 'chapters', await p.$$eval('[data-chapter]', a => a.length), p._errs.join('|'));
  await H.close();
})().catch(e => { console.error('CRASH', e); process.exit(1); });
