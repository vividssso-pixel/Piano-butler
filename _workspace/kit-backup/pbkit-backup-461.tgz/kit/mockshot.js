const { start } = require('./contentharness');
(async () => {
  for (const [b, name] of [['drills.p392.html', 'before'], ['drills.mock.html', 'after']]) {
    const H = await start(b);
    const p = await H.open({ path: '?book=work&ch=first-steps&lang=en', w: 900, h: 1200 });
    await p.waitForTimeout(1500);
    const pg = (await p.$$('.bk-page'))[0];
    const ov = await p.$$eval('.bk-page', els => els.map(e => { const x = e.querySelector('.bk-body'); return x ? x.scrollHeight - x.clientHeight : e.scrollHeight - e.clientHeight; }));
    console.log(name, 'overflow', JSON.stringify(ov.slice(0, 2)), p._errs.join('|').slice(0, 200));
    await pg.screenshot({ path: 'p392/map-' + name + '.png' });
    await H.close();
  }
  process.exit(0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
