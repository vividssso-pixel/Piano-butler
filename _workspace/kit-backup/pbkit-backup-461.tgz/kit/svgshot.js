const { chromium } = require('playwright'); const fs = require('fs');
(async () => {
  const [src, out, w] = process.argv.slice(2);
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const p = await b.newPage({ viewport: { width: +(w || 400), height: 600 }, deviceScaleFactor: 2 });
  const html = fs.readFileSync(src, 'utf8');
  await p.setContent(src.endsWith('.svg') ? '<html><body style="margin:0;background:#fff">' + html.replace('<svg ', '<svg width="' + (w || 400) + '" ') + '</body></html>' : html);
  await p.waitForTimeout(400);
  const el = await p.$('body'); await el.screenshot({ path: out });
  await b.close();
})();
