const { start } = require('./contentharness');
(async () => {
  const H = await start('drills.t426.html');
  const p = await H.open({ path: '?view=map', w: 390, h: 844, store: {}, dsf: 1 }); await p.waitForTimeout(1500);
  console.log(await p.evaluate(async () => { await document.fonts.load("700 15px 'Cormorant Garamond'"); await document.fonts.load('700 12px Cinzel'); return [...document.fonts].filter(f => /Cinzel|Cormorant/.test(f.family)).map(f => f.family + ' ' + f.weight + ' ' + f.style + ' ' + f.status).join(' | ') + ' || links: ' + [...document.querySelectorAll('link[href*=googleapis]')].map(l => l.href.slice(0, 200)).join(' '); }));
  await H.close();
})();
