const { start } = require('./contentharness');
(async () => {
  const H = await start('drills.new.html');
  const p = await H.open({ path: '?drill=first-steps', w: 390, h: 1100 });
  await p.waitForTimeout(1000);
  for (const [i, name] of [[1, 'whose-house'], [2, 'which-letter'], [4, 'play']]) {
    await p.evaluate((j) => document.querySelectorAll('section[id^="first-steps-step-"]')[j].scrollIntoView(), i);
    await p.waitForTimeout(300);
    const el = await p.$('#first-steps-step-' + i);
    await el.screenshot({ path: 'app2-' + name + '.png' });
  }
  // tap a key in whose-house for a live shot
  await p.evaluate(() => document.querySelector('[data-whose-house]').scrollIntoView({ block: 'center' }));
  await p.click('[data-whose-house] [data-key="14"]');
  await p.waitForTimeout(350);
  await (await p.$('[data-whose-house]')).screenshot({ path: 'app2-whose-live.png' });
  const tab = await p.$('button:has-text("Drill")'); await tab.click(); await p.waitForTimeout(700);
  const chip = await p.$('button:has-text("Level 3")'); await chip.click(); await p.waitForTimeout(900);
  await p.screenshot({ path: 'app2-drill-name.png' });
  await p.context().close();
  const p2 = await H.open({ path: '?book=lesson&ch=first-steps&lang=en', w: 900, h: 1200 });
  await p2.waitForTimeout(1600);
  await p2.pdf({ path: 'pack/ch2-book-applied.pdf', preferCSSPageSize: true, printBackground: true });
  await p2.context().close();
  await H.close(); console.log('done'); process.exit(0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
