const { start } = require('./contentharness');
(async () => {
  const H = await start('drills.t426.html');
  const p = await H.open({ path: '?view=map', w: 390, h: 844, store: {}, dsf: 1 }); await p.waitForTimeout(1000);
  const door = await p.$('[data-door]'); await door.scrollIntoViewIfNeeded();
  const t0 = Date.now(); await door.click();
  for (let i = 0; i < 14; i++) {
    console.log(Date.now() - t0, JSON.stringify(await p.evaluate(() => { const h = document.querySelector('[data-house]'), g = document.querySelector('[data-grow]'), l = document.querySelector('[data-leaf="l"]'); return [h.getAttribute('data-layout'), !!document.querySelector('[data-opening]'), g ? getComputedStyle(g).animationName + ' ' + getComputedStyle(g).clipPath : '-', l ? getComputedStyle(l).transform : '-']; })));
    await p.waitForTimeout(60);
  }
  await H.close();
})();
