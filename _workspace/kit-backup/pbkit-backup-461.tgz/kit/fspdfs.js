const { start } = require('./contentharness');
(async () => {
  const H = await start('drills.fs382.html');
  // 1. the draft Lesson Book (with draft marks)
  let p = await H.open({ path: '?book=lesson&ch=first-steps&lang=en&draft=1', w: 900, h: 1200 });
  await p.waitForTimeout(1800);
  await p.pdf({ path: 'pack/lesson-draft.pdf', preferCSSPageSize: true, printBackground: true });
  await p.context().close();
  // 2. current workbook + teacher copy
  for (const kind of ['work', 'teacher']) {
    p = await H.open({ path: '?book=' + kind + '&ch=first-steps&lang=en', w: 900, h: 1200 });
    await p.waitForTimeout(1500);
    await p.pdf({ path: 'pack/' + kind + '.pdf', preferCSSPageSize: true, printBackground: true });
    await p.context().close();
  }
  // 3. the drill, levels 1-3 (student view)
  p = await H.open({ path: '?drill=first-steps', w: 390, h: 844 });
  await p.waitForTimeout(600);
  const tab = await p.$('button:has-text("Drill")'); if (tab) { await tab.click(); await p.waitForTimeout(700); }
  await p.screenshot({ path: 'pack/drill-levels.png' });
  for (let lv = 1; lv <= 3; lv++) {
    const b = await p.$(`[data-level="${lv}"] button, button:has-text("Level ${lv}")`);
    if (b) { await b.click(); await p.waitForTimeout(400); }
    const go = await p.$('button:has-text("Start"), button:has-text("시작")');
    if (go) { await go.click(); await p.waitForTimeout(900); }
    await p.screenshot({ path: 'pack/drill-l' + lv + '.png' });
    const back = await p.$('button:has-text("Back"), [aria-label="Back"], button:has-text("←")');
    if (back) { await back.click(); await p.waitForTimeout(500); }
  }
  console.log('errs', p._errs.join('|').slice(0, 200));
  await p.context().close(); await H.close(); process.exit(0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
