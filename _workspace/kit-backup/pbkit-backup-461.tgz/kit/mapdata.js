const { start } = require('./contentharness');
(async () => {
  const H = await start(process.env.BUILD);
  const p = await H.open({ path: '?book=work&ch=front&lang=en', w: 900, h: 900 });
  const d = await p.evaluate(() => PATH_STAGES.map((s, i) => ({ i, name: s.name || s.title || s.label || JSON.stringify(Object.keys(s)), ids: pathStageIds(s), names: pathStageIds(s).map(id => { const x = DRILLS.find(q => q.id === id); return x ? x.label : id; }) })));
  console.log(JSON.stringify(d, null, 1));
  await H.close();
})();
