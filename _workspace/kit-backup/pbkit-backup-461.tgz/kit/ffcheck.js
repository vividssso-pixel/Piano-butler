const { start } = require('./contentharness');
(async () => {
  const H = await start('drills.new.html');
  for (const w of [320, 390, 768]) {
    const p = await H.open({ path: '?tool=finger-friends', w, h: 900 });
    await p.waitForTimeout(900);
    const sw = await p.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
    console.log(w + 'px sideways scroll:', sw, 'errs:', p._errs.join('|') || 'none');
    if (w === 390) await p.screenshot({ path: 'ff-390.png' });
    await p.context().close();
  }
  await H.close(); process.exit(0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
