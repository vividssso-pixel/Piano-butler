const { start } = require('./contentharness');
(async () => {
  const H = await start('drills.t399.html');
  const jobs = [['lesson', 'first-steps', [5]], ['work', 'first-steps', [5]], ['lesson', 'note-names', [7, 8]], ['work', 'note-names', [7]]];
  for (const [kind, ch, pgs] of jobs) {
    const p = await H.open({ path: '?book=' + kind + '&ch=' + ch + '&lang=en', w: 900, h: 1200 });
    await p.waitForTimeout(1500);
    const pages = await p.$$('.bk-page');
    for (const n of pgs) await pages[n - 1].screenshot({ path: 'p397/s399-' + kind + '-' + ch + '-' + n + '.png' });
    await p.context().close();
  }
  await H.close(); process.exit(0);
})();
