const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  for (const [f, w] of [['ledger-lines.html', 390], ['ledger-lines.html', 1200], ['index.html', 390]]) {
    const p = await b.newPage({ viewport: { width: w, height: 900 } });
    await p.route(/^https?:\/\//, r => r.abort());
    await p.goto('file:///tmp/sitetest/lessons/' + f); await p.waitForTimeout(500);
    const r = await p.evaluate(() => ({ sx: document.documentElement.scrollWidth - document.documentElement.clientWidth, robots: (document.querySelector('meta[name=robots]') || {}).content, canon: (document.querySelector('link[rel=canonical]') || {}).href, h1: document.querySelector('h1').textContent, next: [...document.querySelectorAll('nav.next a')].map(a => a.getAttribute('href')), rooms: [...document.querySelectorAll('a.room')].map(a => a.getAttribute('href')), svgs: document.querySelectorAll('svg.pic').length, imgs: [...document.querySelectorAll('img')].map(i => i.getAttribute('src') + ':' + i.naturalWidth) }));
    console.log(f, w, JSON.stringify(r));
    await p.screenshot({ path: 'p428/guide-' + f.replace('.html', '') + '-' + w + '.png', fullPage: true });
    await p.close();
  }
  await b.close();
})();
