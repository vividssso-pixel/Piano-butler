const { chromium } = require('playwright'); const http = require('http'), fs = require('fs'), path = require('path');
const ROOT = '/home/claude/pbtest/site';
(async () => {
  const srv = http.createServer((q, r) => { const f = path.join(ROOT, decodeURIComponent(q.url.split('?')[0])); try { const b = fs.readFileSync(f); r.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html' : f.endsWith('.jpg') ? 'image/jpeg' : 'application/octet-stream' }); r.end(b); } catch (e) { r.writeHead(404); r.end(); } });
  await new Promise(r => srv.listen(0, r)); const base = 'http://localhost:' + srv.address().port;
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  for (const [w, name] of [[390, 'm'], [1100, 'd']]) {
    const p = await b.newPage({ viewport: { width: w, height: 900 } });
    const errs = []; p.on('pageerror', e => errs.push(e.message));
    await p.route(/googlesyndication|googletagmanager|google-analytics|fonts\.g/, r => r.abort());
    await p.goto(base + '/lessons/' + (process.env.PG || 'keyboard-patterns-and-note-names.html') + ''); await p.waitForTimeout(700);
    const r = await p.evaluate(() => ({ sw: document.documentElement.scrollWidth - document.documentElement.clientWidth,
      spill: [...document.querySelectorAll('svg, img')].filter(e => e.getBoundingClientRect().right > document.documentElement.clientWidth + 1).length,
      ids: (() => { const all = [...document.querySelectorAll('[id]')].map(e => e.id); return all.length - new Set(all).size; })(),
      broken: [...document.querySelectorAll('[fill^="url(#"]')].filter(e => !document.getElementById(e.getAttribute('fill').slice(5, -1))).length,
      robots: document.querySelector('meta[name=robots]')?.content, canon: document.querySelector('link[rel=canonical]')?.href, author: document.querySelector('meta[name=author]')?.content,
      imgOk: [...document.querySelectorAll('img')].every(i => i.complete && i.naturalWidth > 0) }));
    console.log(w + 'px', JSON.stringify(r), 'errs', errs.join('|') || 'none');
    await p.screenshot({ path: 'g388-' + name + '.png', fullPage: true });
    await p.close();
  }
  const p = await b.newPage({ viewport: { width: 1100, height: 900 } });
  await p.route(/googlesyndication|googletagmanager|google-analytics|fonts\.g/, r => r.abort());
  await p.goto(base + '/lessons/index.html'); await p.waitForTimeout(600);
  const links = await p.$$eval('.house-wide a, #open a', els => els.map(e => e.getAttribute('href')));
  console.log('index links', JSON.stringify(links));
  await p.screenshot({ path: 'g388-index.png', fullPage: false });
  await b.close(); srv.close(); process.exit(0);
})();
