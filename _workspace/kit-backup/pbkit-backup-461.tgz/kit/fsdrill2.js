const { start } = require('./contentharness');
(async () => {
  const H = await start('drills.fs382.html');
  const p = await H.open({ path: '?drill=first-steps', w: 390, h: 844 });
  await p.waitForTimeout(600);
  const tab = await p.$('button:has-text("Drill")'); if (tab) { await tab.click(); await p.waitForTimeout(700); }
  for (const lv of [1, 2, 3]) {
    const chip = await p.$(`button:has-text("Level ${lv}")`);
    if (chip) { await chip.click(); await p.waitForTimeout(900); }
    await p.screenshot({ path: 'pack/drill-l' + lv + '.png' });
  }
  console.log('done', p._errs.join('|').slice(0, 100));
  await p.context().close(); await H.close(); process.exit(0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
