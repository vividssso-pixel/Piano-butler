const { start } = require('./contentharness');
(async () => {
  const H = await start('drills.new.html');
  // current workbook + teacher pages for first-steps
  for (const kind of ['work', 'teacher', 'lesson']) {
    const p = await H.open({ path: '?book=' + kind + '&ch=first-steps&lang=en', w: 900, h: 1200 });
    await p.waitForTimeout(1500);
    const pages = await p.$$('.bk-page');
    const info = await p.$$eval('.bk-page', els => els.map(e => { const b = e.querySelector('.bk-body'); return b ? b.scrollHeight - b.clientHeight : null; }));
    console.log(kind, pages.length, 'pages, overflow', JSON.stringify(info), 'errs', p._errs.join('|').slice(0, 150));
    for (let i = 0; i < pages.length; i++) await pages[i].screenshot({ path: 'ch2/' + kind + '-p' + (i + 1) + '.png' });
    await p.context().close();
  }
  // the app lesson steps
  const p = await H.open({ path: '?drill=first-steps', w: 390, h: 900 });
  await p.waitForTimeout(800);
  const steps = await p.$$('section[id^="first-steps-step-"]');
  console.log('app steps', steps.length);
  for (let i = 0; i < steps.length; i++) { await p.evaluate(j => document.querySelectorAll('section[id^="first-steps-step-"]')[j].scrollIntoView(), i); await p.waitForTimeout(250); await steps[i].screenshot({ path: 'ch2/app-step' + (i + 1) + '.png' }); }
  console.log('errs', p._errs.join('|').slice(0, 150));
  await p.context().close();
  await H.close(); process.exit(0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
