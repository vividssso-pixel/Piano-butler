// the left-to-right village: the whole map (wide screen) and the phone view (scrolled to your building)
const { start } = require('./contentharness');
(async () => {
  const H = await start(process.env.BUILD || 'drills.t426.html');
  const full = (n) => { const o = {}; for (let i = 0; i < n; i++) o[i] = 1; return o; };
  const store = { pb_lesson_steps_v1: JSON.stringify({ 'posture-hands': full(6), 'first-steps': full(9), 'note-names': full(8), staff: { 0: 1, 1: 1 } }), pb_steps_total_v1: JSON.stringify({ 'posture-hands': 6, 'first-steps': 9, 'note-names': 8, staff: 7 }) };
  const w = await H.open({ path: '?view=map', w: 1100, h: 900, store, dsf: 3 }); await w.waitForTimeout(1200);
  await (await w.$('[data-village]')).screenshot({ path: 'p425/land-full.png' });
  console.log('wide errs', w._errs.join('|'));
  const p = await H.open({ path: '?view=map', w: 390, h: 844, store, dsf: 2 }); await p.waitForTimeout(1200);
  await (await p.$('[data-house]')).screenshot({ path: 'p425/land-phone.png' });
  console.log('phone scrollLeft', await p.evaluate(() => { const e = document.querySelector('[data-pan]'); return [e.scrollLeft, e.scrollWidth, e.clientWidth]; }), p._errs.join('|'));
  await H.close();
})().catch(e => { console.error('CRASH', e); process.exit(1); });
