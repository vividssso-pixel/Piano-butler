const { start } = require('./contentharness');
(async () => {
  const H = await start('drills.new.html');
  for (const kind of ['work', 'teacher']) {
    const p = await H.open({ path: '?book=' + kind + '&ch=note-names&lang=en', w: 900, h: 1200 });
    await p.waitForTimeout(1500);
    const pages = await p.$$('.bk-page');
    console.log(kind, pages.length, 'pages');
    for (let i = 0; i < pages.length; i++) await pages[i].screenshot({ path: 'ch3/' + kind + '-p' + (i + 1) + '.png' });
    await p.pdf({ path: 'ch3/' + kind + '.pdf', preferCSSPageSize: true, printBackground: true });
    await p.context().close();
  }
  const p = await H.open({ path: '?drill=note-names', w: 390, h: 1000 });
  await p.waitForTimeout(900);
  const steps = await p.$$('section[id^="note-names-step-"]');
  console.log('app steps', steps.length);
  for (let i = 0; i < steps.length; i++) { await p.evaluate(j => document.querySelectorAll('section[id^="note-names-step-"]')[j].scrollIntoView(), i); await p.waitForTimeout(250); await steps[i].screenshot({ path: 'ch3/app-step' + (i + 1) + '.png' }); }
  const tab = await p.$('button:has-text("Drill")'); await tab.click(); await p.waitForTimeout(700);
  for (const lv of [1, 2, 3, 4, 5, 6]) { const chip = await p.$(`button:has-text("Level ${lv}")`); if (chip) { await chip.click(); await p.waitForTimeout(800); } await p.screenshot({ path: 'ch3/drill-l' + lv + '.png' }); }
  console.log('errs', p._errs.join('|').slice(0, 200));
  await H.close(); process.exit(0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
