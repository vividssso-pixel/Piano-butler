const { start } = require('./contentharness');
(async () => {
  const H = await start('drills.new.html');
  const p = await H.open({ path: '?book=work&ch=first-steps&lang=en&pages=3', w: 900, h: 1300 });
  await p.waitForTimeout(1500);
  const pg = await p.$('.bk-page');
  await pg.screenshot({ path: 'ws388.png' });
  console.log('errs', p._errs.join('|'));
  await H.close(); process.exit(0);
})();
