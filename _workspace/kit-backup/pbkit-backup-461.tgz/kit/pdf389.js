const { start } = require('./contentharness');
(async () => {
  const H = await start('drills.new.html');
  const p = await H.open({ path: '?book=spread&ch=first-steps&lang=en', w: 900, h: 1200 });
  await p.waitForTimeout(1800);
  await p.pdf({ path: '/mnt/user-data/outputs/Chapter-02-Lesson-Book-and-Workbook.pdf', preferCSSPageSize: true, printBackground: true });
  await H.close(); process.exit(0);
})();
