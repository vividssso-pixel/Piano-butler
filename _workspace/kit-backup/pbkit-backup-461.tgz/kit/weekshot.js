// the map page with a week of practice: Clara (no link) and a named student
const { start } = require('./contentharness');
(async () => {
  const H = await start(process.env.BUILD || 'drills.t426.html');
  const at = (d) => new Date(d + 'T16:00:00').getTime();
  const days = ['2026-10-05', '2026-10-06', '2026-10-08', '2026-09-28', '2026-09-29', '2026-09-30', '2026-10-01', '2026-10-02', '2026-09-22', '2026-09-24', '2026-09-15', '2026-09-16', '2026-09-17', '2026-09-18'];
  const recs = { 'staff|1|lesson': { plays: days.length, best: 8, lastAt: at(days[0]), history: days.map(d => ({ at: at(d), score: 8, correct: 8, total: 10 })) } };
  const base = { pb_lesson_steps_v1: JSON.stringify({ 'posture-hands': { 0: 1, 1: 1, 3: 1, 5: 1, 6: 1, 7: 1 }, 'first-steps': { 0: 1 } }), pb_steps_total_v1: JSON.stringify({ 'posture-hands': 6, 'first-steps': 9 }), pb_drill_records_v1: JSON.stringify(recs) };
  for (const [tag, extra] of [['clara', {}], ['named', { pb_link_token_v1: 'abcdefghijklmnopqrstuvwxyzABCDEF0123456789', pb_link_name_v1: 'Minjun' }]]) {
    const p = await H.open({ path: '?view=map', w: 390, h: 844, store: { ...base, ...extra }, dsf: 2 }); await p.waitForTimeout(1200);
    const m = await p.$('[data-house]');
    if (m) await m.screenshot({ path: 'p425/week-' + tag + '.png' }); else console.log(tag, 'no map');
    console.log(tag, 'errs', p._errs.join('|').slice(0, 200));
    await p.context().close();
  }
  await H.close();
})().catch(e => { console.error('CRASH', e); process.exit(1); });
