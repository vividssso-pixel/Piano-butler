const { start } = require('./contentharness');
(async () => {
  const H = await start(process.env.BUILD);
  const p = await H.open({ path: '?book=work&ch=front&lang=en', w: 900, h: 900 });
  const d = await p.evaluate(() => ({ icons: HOUSE_ICONS, short: CH_SHORT, stages: PATH_STAGES.map(s => ({ en: s.en[0], ids: pathStageIds(s) })) }));
  require('fs').writeFileSync('/home/claude/pbtest/cast/mapicons.json', JSON.stringify(d));
  console.log(Object.keys(d.icons).length, Object.keys(d.short).length);
  await H.close();
})();
