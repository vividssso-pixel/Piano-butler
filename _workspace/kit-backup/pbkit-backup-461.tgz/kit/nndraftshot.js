const { start } = require('./contentharness');
(async () => {
  const H = await start(process.env.BUILD || 'drills.nn391.html');
  const p = await H.open({ path: '?book=lesson&ch=note-names&lang=en&draft=' + (process.env.DRAFT || '1'), w: 900, h: 1200 });
  await p.waitForTimeout(1800);
  const pages = await p.$$('.bk-page');
  const info = await p.$$eval('.bk-page', els => els.map(e => { const b = e.querySelector('.bk-body'); return b ? b.scrollHeight - b.clientHeight : null; }));
  console.log('pages', pages.length, 'overflow', JSON.stringify(info), 'errs', p._errs.join('|').slice(0, 300));
  for (let i = 0; i < pages.length; i++) await pages[i].screenshot({ path: 'ch3/nn-p' + (i + 1) + '.png' });
  await p.context().close(); await H.close(); process.exit(0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
