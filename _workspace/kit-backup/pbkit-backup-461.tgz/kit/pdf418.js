const { start } = require('./contentharness');
(async () => {
  const H = await start(process.env.BUILD);
  for (const ch of ['posture-hands', 'first-steps', 'note-names', 'staff']) {
    const p = await H.open({ path: '?book=work&ch=' + ch + '&lang=en', w: 900, h: 1200 });
    await p.waitForTimeout(2600);
    await p.emulateMedia({ media: 'print' });
    await p.pdf({ path: 'pdf418/' + ch + '.pdf', format: 'A4', printBackground: true, preferCSSPageSize: true });
    console.log(ch, 'ok');
    await p.context().close();
  }
  await H.close();
})();
