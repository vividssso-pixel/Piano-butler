const { start } = require('./contentharness');
(async () => {
  const H = await start('drills.new.html');
  // glide card mid-animation
  const p1 = await H.open({ path: '?drill=posture-hands', w: 390, h: 900 });
  const warmSel = '#posture-hands-step-1 [data-warm]';
  await p1.waitForTimeout(500);
  const cards = await p1.$$(warmSel);
  await p1.evaluate(({ sel, j }) => document.querySelectorAll(sel)[j].scrollIntoView({ block: 'center' }), { sel: warmSel, j: 2 });
  await p1.waitForTimeout(1400); await cards[2].screenshot({ path: 'g383-a.png' });
  await p1.waitForTimeout(1500); await cards[2].screenshot({ path: 'g383-b.png' });
  console.log('errs', p1._errs.join('|') || 'none');
  await p1.context().close();
  // ch1 book page 6 (finger walks hands) + fit
  const p2 = await H.open({ path: '?book=lesson&ch=posture-hands&lang=en', w: 900, h: 1200 });
  await p2.waitForTimeout(1600);
  const info = await p2.$$eval('.bk-page', els => els.map(e => { const b = e.querySelector('.bk-body'); return b ? b.scrollHeight - b.clientHeight : null; }));
  console.log('ch1 book overflow', JSON.stringify(info));
  const pages = await p2.$$('.bk-page');
  await pages[5].screenshot({ path: 'g383-book-p6.png' });
  await p2.context().close();
  await H.close(); process.exit(0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
