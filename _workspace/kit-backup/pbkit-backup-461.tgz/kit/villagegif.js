// frames of a building growing out of the village, for a short GIF
const { start } = require('./contentharness');
(async () => {
  const H = await start(process.env.BUILD || 'drills.t426.html');
  const store = { pb_lesson_steps_v1: JSON.stringify({ 'posture-hands': { 0: 1, 1: 1, 3: 1, 5: 1, 6: 1, 7: 1 }, 'first-steps': { 0: 1 } }), pb_steps_total_v1: JSON.stringify({ 'posture-hands': 6, 'first-steps': 9 }) };
  const p = await H.open({ path: '', w: 390, h: 760, store, dsf: 1 }); await p.waitForTimeout(900);
  await p.evaluate(() => { const m = document.querySelector('[data-house]'); window.scrollTo(0, m.getBoundingClientRect().top + window.scrollY - 8); });
  await p.waitForTimeout(300);
  let n = 0; const shot = async () => { await p.screenshot({ path: 'p425/gif/f' + String(n++).padStart(3, '0') + '.png' }); };
  for (let i = 0; i < 8; i++) await shot();
  await p.click('[data-building="2"]');
  for (let i = 0; i < 14; i++) { await shot(); await p.waitForTimeout(25); }
  for (let i = 0; i < 14; i++) await shot();
  await H.close();
})().catch(e => { console.error('CRASH', e); process.exit(1); });
