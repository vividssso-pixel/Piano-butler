const { chromium } = require('playwright'); const http = require('http'), fs = require('fs'), path = require('path');
const ROOT = '/home/claude/pbtest/site';
(async () => {
  const srv = http.createServer((q, r) => { const f = path.join(ROOT, decodeURIComponent(q.url.split('?')[0])); try { r.writeHead(200); r.end(fs.readFileSync(f)); } catch (e) { r.writeHead(404); r.end(); } });
  await new Promise(r => srv.listen(0, r));
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const p = await b.newPage({ viewport: { width: 390, height: 900 } });
  await p.route(/googlesyndication|googletagmanager|google-analytics|fonts\.g/, r => r.abort());
  await p.goto('http://localhost:' + srv.address().port + '/lessons/keyboard-patterns-and-note-names.html');
  await p.evaluate(() => document.querySelector('#worksheet').scrollIntoView()); await p.waitForTimeout(800);
  console.log(await p.$eval('#worksheet img', i => [i.complete, i.naturalWidth, i.naturalHeight]));
  await (await p.$('#worksheet')).screenshot({ path: 'g388-ws.png' });
  await b.close(); srv.close();
})();
