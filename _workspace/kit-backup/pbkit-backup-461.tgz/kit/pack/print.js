const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const p = await browser.newPage();
  for (const f of ['front', 'drillpg']) {
    await p.goto('file://' + path.resolve(f + '.html'));
    await p.evaluate(() => document.fonts.ready);
    await p.waitForTimeout(400);
    await p.pdf({ path: f + '.pdf', preferCSSPageSize: true, printBackground: true });
  }
  await browser.close();
  console.log('printed');
})();
