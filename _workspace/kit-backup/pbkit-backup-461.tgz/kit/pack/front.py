# Chapter 2 review pack: front pages (cover, A, B) + the drill page, as HTML for Chromium to print
import os
NM = os.path.abspath('../node_modules/@fontsource')
FONTS = ''.join(f"@font-face{{font-family:'Inter';font-weight:{w};src:url(file://{NM}/inter/files/inter-latin-{w}-normal.woff2) format('woff2');}}" for w in (400, 600, 700, 800)) + \
        ''.join(f"@font-face{{font-family:'Playfair Display';font-weight:{w};src:url(file://{NM}/playfair-display/files/playfair-display-latin-{w}-normal.woff2) format('woff2');}}" for w in (800, 900))
CSS = FONTS + """
@page { size:A4; margin:0; }
* { box-sizing:border-box; }
body { margin:0; font-family:Inter,'Noto Sans CJK KR',sans-serif; color:#26296b; font-size:11.5pt; line-height:1.45; }
.pg { width:210mm; height:297mm; padding:13mm 15mm 17mm; page-break-after:always; position:relative; overflow:hidden; }
.pg:last-child { page-break-after:auto; }
h1, h2 { font-family:'Playfair Display',Georgia,serif; margin:0; line-height:1.1; }
h1 { font-size:30pt; font-weight:900; }
h2 { font-size:17pt; font-weight:900; margin:0 0 2mm; }
.k { color:#e4572e; font-weight:800; font-size:10pt; margin-bottom:2mm; }
.sub { color:#4a4d86; margin:2mm 0 0; }
.box { border:1.2px solid #26296b; border-radius:3mm; padding:3.5mm 5mm; margin-top:4mm; }
.toc { width:100%; border-collapse:collapse; margin-top:2mm; font-size:11pt; }
.toc td { padding:1.4mm 0; border-bottom:0.6px solid #d9d4c4; }
.toc td.n { text-align:right; color:#6d6f9c; white-space:nowrap; }
.how li { margin:1mm 0; }
.q { margin-top:4mm; }
.q > b { display:block; }
.lines { height:12mm; background:repeating-linear-gradient(#fff 0 6.6mm, #b9b6d8 6.6mm 6.9mm); margin-top:1mm; }
.lines.s { height:8.5mm; }
.item { display:grid; grid-template-columns:9mm 1fr 30mm; gap:2mm; padding:2.2mm 0; border-bottom:0.6px solid #d9d4c4; font-size:10.3pt; break-inside:avoid; }
.item .id { font-weight:800; color:#e4572e; }
.item .t b { color:#26296b; }
.item .t { color:#3c3f78; }
.item .fx { color:#26296b; font-weight:600; margin-top:0.8mm; }
.tick { font-size:9.5pt; color:#26296b; white-space:nowrap; }
.tick span { display:inline-block; width:3.6mm; height:3.6mm; border:1.2px solid #26296b; border-radius:0.8mm; vertical-align:-0.6mm; margin-right:1mm; }
.yel { background:#fff1a8; }
.grid3 { display:grid; grid-template-columns:repeat(3,1fr); gap:4mm; margin-top:3mm; align-items:start; }
.grid3 img { width:100%; border:0.6px solid #d9d4c4; border-radius:2mm; }
.cap { font-size:9.5pt; font-weight:700; margin-top:1mm; }
.foot { position:absolute; bottom:8mm; left:15mm; right:15mm; font-size:8.5pt; color:#6d6f9c; display:flex; justify-content:space-between; }
"""

def page(inner, foot):
    return f'<section class="pg">{inner}<div class="foot"><span>Piano Butler · Chapter 2 review · Black Keys &amp; Your First Song</span><span>{foot}</span></div></section>'

def doc(pages):
    return f'<!doctype html><html lang="en"><head><meta charset="utf-8"><style>{CSS}</style></head><body>{"".join(pages)}</body></html>'

tick = '<div class="tick"><span></span>Fix it &nbsp;&nbsp;<span></span>No / differently</div>'

cover = f"""
<div class="k">PIANO BUTLER · CHAPTER-BY-CHAPTER REVIEW · 2026-10-09</div>
<h1>Chapter 2<br>Black Keys &amp; Your First Song</h1>
<p class="sub"><b>v2 재구성판</b>이에요 (2026-10-09 오전 방향 반영): 중심을 곡이 아니라 <b>패턴 인식 → 집마다 딸린 흰건반(3개와 4개) → 알파벳 음이름 → 가운데 도</b>로 다시 잡았어요. 높낮이는 패턴 페이지의 방향 한 줄로 접었고, 크고 작게는 챕터에서 뺐고, 음자리표·여왕과 왕은 악보 챕터로 아껴 뒀어요(B7). 종이에 빨간펜으로, 또는 채팅으로 답해 주시면 돼요. <span class="yel">노란 표시</span> = 답을 기다리는 부분.</p>
<div class="box">
  <h2>공개 가이드 페이지를 위한 질문 3개</h2>
  <div class="q"><b>Q1. 검은건반 지도나 첫 노래에서, 학생들이 가장 많이 틀리는 것은 무엇인가요?</b> ("From the teacher" 칸에 들어가요)<div class="lines"></div></div>
  <div class="q"><b>Q2. 레가토(또는 집 찾기)에 쓰는 소현님만의 팁이 있나요?</b> (거북이 지우개처럼, 다른 선생님이 바로 따라 할 수 있는 것)<div class="lines"></div></div>
  <div class="q"><b>Q3. 실제로 처음 가르치는 노래는 무엇인가요?</b> (핫 크로스 번? 비행기? 다른 곡? — 공개 페이지의 예시도 그 곡에 맞출까요?)<div class="lines"></div></div>
</div>
<div class="box">
  <h2>In this pack</h2>
  <table class="toc">
    <tr><td>A. What I found (6 items)</td><td class="n">p. 2</td></tr>
    <tr><td>B. Teaching questions (10)</td><td class="n">p. 3</td></tr>
    <tr><td><b>The new Lesson Book — draft</b> (yellow = waiting for B answers)</td><td class="n">p. 4–10</td></tr>
    <tr><td>The Workbook as it is today</td><td class="n">p. 11–18</td></tr>
    <tr><td>The Teacher copy as it is today</td><td class="n">p. 19–20</td></tr>
    <tr><td>The drill as it is today (3 levels)</td><td class="n">p. 21</td></tr>
  </table>
</div>
<div class="box how">
  <h2>How to mark</h2>
  <ul>
    <li>A 항목: <b>Fix it</b>에 체크하면 그대로 고칠게요. 다르게 고치고 싶으면 옆에 적어 주세요.</li>
    <li>B 질문: 한 줄이면 충분해요. "응"도 답이에요.</li>
    <li>레슨북 초안: 아무 쪽이나 빨간펜 환영 — 사진으로 보내시거나 채팅에 번호로 답해 주세요.</li>
  </ul>
</div>
"""

a_items = [
    ("A1", "Workbook p.4 says <b>“little house”</b> (the lead picture and its example line) while the app, the check-up and the Teacher copy all say <b>“small house”</b>.",
     "→ Make it “small house” everywhere."),
    ("A2", "The app's first-song tool shows <b>note names</b> (G♭ A♭ B♭, D♭) under the keyboard — but note names are only taught in the Note Names chapter. (In the code an unused label map even numbers the keys 1 2 3 5, which matches nothing.)",
     "→ Show <b>finger numbers 2 3 4 (5)</b> under the keyboard instead, like the new book page."),
    ("A3", "One chapter, several names: the chapter list and the books say <b>“Black Keys &amp; Your First Song”</b>; the drill header says <b>“Piano keys &amp; note names”</b>; the drill's game screen says <b>“Keyboard Patterns”</b>; the app lesson's title says <b>“The keyboard and your first song” / ‘건반과 첫 곡’</b>.",
     "→ One name everywhere: “Black Keys &amp; Your First Song” / ‘검은건반과 첫 노래’."),
    ("A4", "“Mary Had a Little Lamb”: the tool's intro says <b>“fingers 2, 3 and 4 on its three black keys”</b>, but Mary also needs <b>D♭ in the next small house</b> — the intro never says which finger plays it.",
     "→ Either add the D♭/finger-5 line when Mary is chosen, or keep Mary out (B2)."),
    ("A5", "The Workbook's hand drawings (p.6 and check-up C) are still the old <b>skin-tone</b> pictures; chapter 1's books moved to the two inks.",
     "→ Redraw with the book's pen hands when the chapter is applied."),
    ("A6", "The app's house tools colour the houses <b>gold and green</b> with tinted keys; the book draws everything in <b>navy + coral</b>.",
     "→ When the chapter is applied, the app's tools follow the book's inks (as chapter 1's tools did)."),
]

a_page = '<div class="k">CHAPTER 2 REVIEW</div><h2>A. What I found</h2><p class="sub" style="font-size:10pt">각 항목: 그대로 고칠까요? 체크해 주세요.</p>' + ''.join(
    f'<div class="item"><div class="id">{i}</div><div class="t">{txt}<div class="fx">{fx}</div></div>{tick}</div>' for i, txt, fx in a_items)

b_items = [
    ("B1", "곰과 새: 패턴 페이지의 <b>방향 한 줄</b>(곰 = 낮은 쪽, 새 = 높은 쪽)로 접었어요 — 이 정도면 될까요, 아니면 더 줄이거나 키울까요?"),
    ("B2", "연주 페이지의 첫 튠: <b>핫 크로스 번(검은건반, 2 3 4)</b> 유지 — 아니면 이름을 배웠으니 흰건반 곡으로 바꿀까요?"),
    ("B3", "챕터 3(음이름)과의 분담: <b>챕터 2 = 이름이 어디 사는지</b>(패턴→글자, 가운데 도), <b>챕터 3 = 이름을 빨리 대기</b>(알파벳 체인, 전체 옥타브, 속도 게임; 샵·플랫은 더 뒤) — 이렇게 나눌까요?"),
    ("B4", "한국어 모드에서 <b>도레미 병기</b>(C=도)를 여기서부터 할까요, 아직 알파벳만 할까요?"),
    ("B5", "맨 아래 외로운 검은건반의 <b>\u201c개집(kennel)\u201d</b> — 책에 그대로 둘까요?"),
    ("B6", "에코 게임 규칙: 검은건반 2–3개를 바로 따라 치고, 쉬워지면 4–5개 — 이대로 괜찮을까요?"),
    ("B7", "제 선택: <b>음자리표와 여왕·왕은 악보 읽기 챕터</b>에서 데뷔하고, 여기는 \u201c낮은 목소리와 높은 목소리가 가운데 도에서 만난다\u201d만 심어 둠 — 괜찮을까요, 아니면 여기서 미리 등장시킬까요?"),
    ("B8", "7쪽 <b>다섯 가지 확인</b>(집 찾기 / 흰건반 3·4 / 음이름 대기 / 가운데 도 / 핫 크로스 레가토) — 실제로 확인하실 다섯 가지와 맞나요?"),
    ("B9", "<b>크고 작게(loud/soft)</b>는 이 챕터에서 빼고 앱의 듣기 도구로만 남겼어요. 드릴 2단계는 \u201c이 건반의 이름은?\u201d 같은 음이름 문제로 바꾸면 될까요?"),
    ("B10", "챕터 이름: <b>\u201cKeyboard Patterns &amp; Note Names / 건반 패턴과 음이름\u201d</b> — 이걸로 바꿀까요? (앱·책·드릴·하우스 맵 전부 통일)"),
]
b_page = '<div class="k">CHAPTER 2 REVIEW</div><h2>B. Teaching questions</h2><p class="sub" style="font-size:10pt">한 줄씩이면 충분해요.</p>' + ''.join(
    f'<div class="q"><b>{i}. {txt}</b><div class="lines s"></div></div>' for i, txt in b_items)

drill_page = """
<div class="k">CHAPTER 2 · AS IT IS TODAY</div><h2>The drill (3 levels)</h2>
<p class="sub" style="font-size:10pt">1단계 높낮이 듣기 · 2단계 크기 듣기 · 3단계 작은 집/큰 집. (2단계 답 표기는 B7을 봐 주세요.)</p>
<div class="grid3">
  <div><img src="drill-l1.png"><div class="cap">Level 1 · High or low?</div></div>
  <div><img src="drill-l2.png"><div class="cap">Level 2 · Loud or soft?</div></div>
  <div><img src="drill-l3.png"><div class="cap">Level 3 · Which house?</div></div>
</div>
"""

pages = [page(cover, 'p. 1'), page(a_page, 'p. 2'), page(b_page, 'p. 3'), page(drill_page, 'p. 21')]
open('front.html', 'w').write(doc(pages[:3]))
open('drillpg.html', 'w').write(doc([pages[3]]))
print('front.html + drillpg.html written')
