const { start } = require('./contentharness');
const { chromium } = require('playwright'); const http = require('http'), fs = require('fs'), path = require('path');
(async () => {
  const H = await start('drills.new.html');
  const p = await H.open({ path: '?book=lesson&ch=posture-hands&lang=en', w: 900, h: 1200 });
  await p.waitForTimeout(1500);
  const pages = await p.$$('.bk-page'); await pages[1].screenshot({ path: 'f389-ch1p2.png' }); await pages[5].screenshot({ path: 'f389-ch1p6.png' });
  await p.context().close();
  const q = await H.open({ path: '?book=lesson&ch=first-steps&lang=en', w: 900, h: 1200 });
  await q.waitForTimeout(1500);
  const pg2 = await q.$$('.bk-page'); await pg2[4].screenshot({ path: 'f389-ch2p5.png' });
  await H.close();
  // ch1 guide page at phone width
  const ROOT = '/home/claude/pbtest/site';
  const srv = http.createServer((a, r) => { try { r.writeHead(200); r.end(fs.readFileSync(path.join(ROOT, decodeURIComponent(a.url.split('?')[0])))); } catch (e) { r.writeHead(404); r.end(); } });
  await new Promise(r => srv.listen(0, r));
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const g = await b.newPage({ viewport: { width: 390, height: 900 } });
  await g.route(/googlesyndication|googletagmanager|google-analytics|fonts\.g/, r => r.abort());
  await g.goto('http://localhost:' + srv.address().port + '/lessons/posture-and-hand-shape.html'); await g.waitForTimeout(500);
  console.log('ch1 guide 390px sideways', await g.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth));
  await b.close(); srv.close(); process.exit(0);
})();
