const { start } = require('./contentharness');
(async () => {
  const H = await start(process.env.BUILD || 'drills.t426.html');
  const w = await H.open({ path: '?view=map', w: 1100, h: 900, store: {}, dsf: 1 }); await w.waitForTimeout(900);
  console.log(JSON.stringify(await w.evaluate(() => [...document.querySelectorAll('[data-building] rect')].map(r => { const y = +r.getAttribute('y') + 4, h = +r.getAttribute('height'); return [r.parentNode.getAttribute('data-building'), +r.getAttribute('width') - 8, Math.round(h - 34 - 4)]; }))));
  await H.close();
})().catch(e => { console.error('CRASH', e); process.exit(1); });
