const { start } = require('./contentharness');
(async () => {
  const H = await start('drills.new.html');
  // 1. teacher copy still fits
  const p0 = await H.open({ path: '?book=teacher&ch=posture-hands&lang=en', w: 900, h: 1200 });
  await p0.waitForTimeout(1500);
  const info = await p0.$$eval('.bk-page', els => els.map(e => { const b = e.querySelector('.bk-body'); return b ? b.scrollHeight - b.clientHeight : null; }));
  console.log('teacher pages', info.length, 'overflow', JSON.stringify(info), 'errs', p0._errs.join('|').slice(0, 200));
  await p0.context().close();
  // 2. game-mode label
  const p1 = await H.open({ path: '?drill=posture-hands', w: 390, h: 900 });
  const label = await p1.evaluate(() => { const b = [...document.querySelectorAll('button')].find(x => /Game mode/.test(x.textContent)); return b ? b.textContent : 'NOT FOUND'; });
  console.log('game label:', JSON.stringify(label), '| pixel gone:', !/pixel/i.test(label));
  // 3. sit-check: good preset -> green, bad preset -> coral
  await p1.evaluate(() => document.querySelector('#posture-hands-step-0 button')?.scrollIntoView());
  const sit = await p1.$('[data-pen-sit]');
  // presets: click "Just right"
  await p1.$$eval('[data-pen-sit] button.chip', els => els.find(e => /Just right/.test(e.textContent)).click());
  await p1.waitForTimeout(600);
  const okSvg = await p1.$eval('[data-pen-sit] svg', el => el.outerHTML);
  console.log('good preset: green strokes', (okSvg.match(/#2e8a6e/g) || []).length, '| coral labels', /elbow/.test(okSvg));
  await sit.screenshot({ path: 'shot-sit-good.png' });
  await p1.$$eval('[data-pen-sit] button.chip', els => els.find(e => /Too close/.test(e.textContent)).click());
  await p1.waitForTimeout(600);
  const badSvg = await p1.$eval('[data-pen-sit] svg', el => el.outerHTML);
  console.log('bad preset: green strokes', (badSvg.match(/#2e8a6e/g) || []).length, 'coral strokes', (badSvg.match(/#e4572e/g) || []).length);
  await sit.screenshot({ path: 'shot-sit-bad.png' });
  // 4. warm-ups: play glide and dive, screenshot mid-animation
  const warmSel = '#posture-hands-step-1 [data-warm]';
  await p1.evaluate(sel => document.querySelectorAll(sel)[2].scrollIntoView({ block: 'center' }), warmSel);
  const cards = await p1.$$(warmSel);
  await (await cards[2].$('svg, .pb-art, div')).click();
  await p1.waitForTimeout(2200);
  await cards[2].screenshot({ path: 'shot-glide-mid.png' });
  await p1.waitForTimeout(6800);
  await cards[2].screenshot({ path: 'shot-glide-rest.png' });
  await p1.evaluate(sel => document.querySelectorAll(sel)[3].scrollIntoView({ block: 'center' }), warmSel);
  await (await cards[3].$('svg, .pb-art, div')).click();
  await p1.waitForTimeout(700);
  await cards[3].screenshot({ path: 'shot-drop-lift.png' });
  await p1.waitForTimeout(800);
  await cards[3].screenshot({ path: 'shot-drop-press.png' });
  await p1.waitForTimeout(3600);
  await cards[3].screenshot({ path: 'shot-drop-rest.png' });
  console.log('errs:', p1._errs.join('|') || 'none');
  await p1.context().close();
  await H.close();
  process.exit(0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
