const { start } = require('./contentharness');
(async () => {
  const H = await start('drills.new.html');
  for (const kind of ['work', 'teacher', 'spread']) {
    const p = await H.open({ path: '?book=' + kind + '&ch=first-steps&lang=en', w: 900, h: 1200 });
    await p.waitForTimeout(1600);
    const info = await p.$$eval('.bk-page', els => els.map(e => { const b = e.querySelector('.bk-body'); return b ? b.scrollHeight - b.clientHeight : null; }));
    const spill = await p.$$eval('.bk-page .pb-art', els => els.filter(a => { const b = a.getBoundingClientRect(), q = a.closest('.bk-body'); if (!q) return false; const r = q.getBoundingClientRect(); return b.bottom > r.bottom + 1.5 || b.right > r.right + 1.5; }).map(a => a.dataset.art));
    const rows = await p.$$eval('[data-map-row]', els => els.length);
    console.log(kind, 'pages', info.length, 'overflow', JSON.stringify(info), 'spill', JSON.stringify(spill), 'map rows', rows, 'errs', p._errs.join('|').slice(0, 200));
    if (kind !== 'spread') { const pages = await p.$$('.bk-page'); for (let i = 0; i < pages.length; i++) await pages[i].screenshot({ path: 'wb2/' + kind + '-p' + (i + 1) + '.png' }); }
    await p.pdf({ path: 'wb2/' + kind + '.pdf', preferCSSPageSize: true, printBackground: true });
    await p.context().close();
  }
  await H.close(); process.exit(0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
