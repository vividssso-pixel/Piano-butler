// screenshots for a fresh-eyes review of the townhouse map
const { start } = require('./contentharness');
(async () => {
  const H = await start('drills.t426.html');
  const full = (n) => { const o = {}; for (let i = 0; i < n; i++) o[i] = 1; return o; };
  const store = { pb_lesson_steps_v1: JSON.stringify({ 'posture-hands': full(6), 'first-steps': full(9), 'note-names': full(8), staff: { 0: 1, 1: 1 } }), pb_steps_total_v1: JSON.stringify({ 'posture-hands': 6, 'first-steps': 9, 'note-names': 8, staff: 7 }) };
  for (const [lang, w] of [['en', 390], ['ko', 390], ['en', 320]]) {
    const p = await H.open({ path: '', w, h: 844, store, lang, dsf: 2 }); await p.waitForTimeout(1200);
    await p.screenshot({ path: 'p425/review426/' + lang + w + '-1-hall-page.png', fullPage: true });
    await p.click('[data-door]'); await p.waitForTimeout(1800);
    await (await p.$('[data-house-view]')).screenshot({ path: 'p425/review426/' + lang + w + '-2-house.png' });
    await p.context().close();
  }
  const s = await H.open({ path: '?view=student', w: 390, h: 844, store, dsf: 2 }); await s.waitForTimeout(1200);
  const m = await s.$('[data-house]'); if (m) await m.screenshot({ path: 'p425/review426/student-compact.png' });
  await s.context().close();
  const b = await H.open({ path: '?book=work&ch=front&lang=en', w: 900, h: 1200, dsf: 1.5 }); await b.waitForTimeout(2600);
  const pages = await b.$$('.bk-page'); for (let i = 0; i < pages.length; i++) await pages[i].screenshot({ path: 'p425/review426/workbook-front-' + (i + 1) + '.png' });
  await H.close();
})().catch(e => { console.error('CRASH', e); process.exit(1); });
