const { chromium } = require('playwright'); const path = require('path');
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const q = await (await b.newContext()).newPage();
  await q.goto('file://' + path.resolve('pack435/pack.html')); await q.waitForTimeout(800);
  await q.evaluate(() => document.fonts.ready);
  await q.pdf({ path: 'pack435/pack.pdf', format: 'A4', printBackground: true, preferCSSPageSize: true });
  const over = await q.evaluate(() => [...document.querySelectorAll('.page')].map(e => e.scrollHeight - e.clientHeight));
  console.log('pack overflow', JSON.stringify(over)); await b.close();
})();
