const { start } = require('./contentharness');
(async () => {
  const H = await start(process.env.BUILD || 'drills.p393.html');
  for (const [path, tag] of [['?book=spread&ch=first-steps&lang=en', 'fs'], ['?book=lesson&ch=posture-hands&lang=en', 'ph'], ['?book=work&ch=posture-hands&lang=en', 'phw'], ['?book=lesson&ch=note-names&lang=en&draft=1', 'nn']]) {
    const p = await H.open({ path, w: 900, h: 1200 });
    await p.waitForTimeout(2000);
    const pages = await p.$$('.bk-page');
    const ov = await p.$$eval('.bk-page', els => els.map(e => { const b = e.querySelector('.bk-body'); return b ? b.scrollHeight - b.clientHeight : e.scrollHeight - e.clientHeight; }));
    console.log(tag, pages.length, 'overflow', JSON.stringify(ov), p._errs.join('|').slice(0, 200));
    for (let i = 0; i < pages.length; i++) await pages[i].screenshot({ path: 'p393/' + tag + '-' + i + '.png' });
    if (tag === 'fs') await p.pdf({ path: 'p393/spread.pdf', preferCSSPageSize: true, printBackground: true });
    await p.context().close();
  }
  await H.close(); process.exit(0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
