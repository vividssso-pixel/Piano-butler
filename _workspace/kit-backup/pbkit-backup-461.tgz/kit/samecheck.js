// The printed books: old vs new build. Only the Teacher copy may differ (the turtle line).
const { start } = require('./contentharness');
(async () => {
  const out = {};
  for (const b of ['drills.old.html', 'drills.new.html']) {
    const H = await start(b);
    for (const k of ['lesson', 'work', 'teacher', 'spread']) {
      const p = await H.open({ path: '?book=' + k + '&ch=posture-hands&lang=en', w: 900, h: 1200 });
      await p.waitForTimeout(1200);
      out[b + k] = await p.evaluate(() => document.querySelector('#root').innerHTML);
      out[b + k + 'err'] = p._errs.join('|');
      await p.context().close();
    }
    await H.close();
  }
  for (const k of ['lesson', 'work', 'teacher', 'spread']) {
    const a = out['drills.old.html' + k], b = out['drills.new.html' + k];
    let i = 0; while (i < a.length && a[i] === b[i]) i++;
    console.log(k, a === b ? 'SAME' : 'DIFF at ' + i + ': ' + JSON.stringify(a.slice(i - 60, i + 140)) + '\n   new: ' + JSON.stringify(b.slice(i - 60, i + 140)), out['drills.new.html' + k + 'err']);
  }
  process.exit(0);
})();
