const { start } = require('./contentharness');
(async () => {
  const H = await start('drills.t397.html');
  const p = await H.open({ path: '', w: 600, h: 800 });
  const r = await p.evaluate(() => ({ ids: STAGES.map(s => s.title + ': ' + s.ids.join(',')).slice(0, 2), n4: STAGES.flatMap(s => s.ids)[3], name4: bkChapterName(STAGES.flatMap(s => s.ids)[3]), no3: bkChapterNo('note-names') }));
  console.log(JSON.stringify(r, null, 1)); await H.close(); process.exit(0);
})();
