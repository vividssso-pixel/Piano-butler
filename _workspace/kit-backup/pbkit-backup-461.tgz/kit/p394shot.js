const { start } = require('./contentharness');
(async () => {
  const H = await start(process.env.BUILD || 'drills.p395.html');
  for (const [path, tag] of [['?book=spread&ch=first-steps&lang=en', 'fs'], ['?book=spread&ch=posture-hands&lang=en', 'ph'], ['?book=work&ch=first-steps&lang=en', 'fsw'], ['?book=teacher&ch=first-steps&lang=en', 'fst'], ['?book=teacher&ch=posture-hands&lang=en', 'pht']]) {
    const p = await H.open({ path, w: 900, h: 1200 });
    await p.waitForTimeout(2200);
    const pages = await p.$$('.bk-page');
    const ov = await p.$$eval('.bk-page', els => els.map(e => { const b = e.querySelector('.bk-body'); return b ? b.scrollHeight - b.clientHeight : e.scrollHeight - e.clientHeight; }));
    const nos = await p.$$eval('.bk-page', els => els.map(e => (e.querySelector('.lb-no, .wb-no') || {}).textContent || '?'));
    console.log(tag, pages.length, 'overflow', JSON.stringify(ov), 'errs', p._errs.join('|').slice(0, 300));
    for (let i = 0; i < pages.length; i++) await pages[i].screenshot({ path: 'p395/' + tag + '-' + i + '.png' });
    if (tag === 'fs' || tag === 'ph') await p.pdf({ path: 'p395/' + tag + '-spread.pdf', preferCSSPageSize: true, printBackground: true });
    await p.context().close();
  }
  await H.close(); process.exit(0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
