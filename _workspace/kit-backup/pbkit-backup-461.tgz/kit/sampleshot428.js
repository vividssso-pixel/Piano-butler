// the two samples on a phone (and the house on a wide screen)
const { start } = require('./contentharness');
(async () => {
  const H = await start(process.env.BUILD || 'drills.t426.html');
  const full = (n) => { const o = {}; for (let i = 0; i < n; i++) o[i] = 1; return o; };
  const base = { pb_lesson_steps_v1: JSON.stringify({ 'posture-hands': full(6), 'first-steps': full(9), 'note-names': full(8), staff: { 0: 1, 1: 1 } }), pb_steps_total_v1: JSON.stringify({ 'posture-hands': 6, 'first-steps': 9, 'note-names': 8, staff: 7 }) };
  for (const v of (process.env.VARS || 'house,snake').split(',')) {
    const p = await H.open({ path: '?view=map', w: 390, h: 844, store: Object.assign({ pb_map_variant_dev: v }, base), dsf: 2 }); await p.waitForTimeout(1200);
    await (await p.$('[data-village]')).screenshot({ path: 'p425/s428-' + v + '.png' });
    console.log(v, p._errs.join('|'), await p.evaluate(() => document.querySelectorAll('[data-village] [data-chapter]').length));
  }
  await H.close();
})().catch(e => { console.error('CRASH', e); process.exit(1); });
