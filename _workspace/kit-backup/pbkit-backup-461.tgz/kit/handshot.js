const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const p = await b.newPage({ viewport: { width: 900, height: 600 } });
  await p.goto('file:///home/claude/pbtest/hands.html');
  await p.waitForTimeout(300);
  await p.screenshot({ path: 'bakedhands.png', fullPage: true });
  await b.close();
})();
