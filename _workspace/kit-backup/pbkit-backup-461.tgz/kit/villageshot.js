// the village map: the overview, then a building opened (mid-zoom and settled), en and ko
const { start } = require('./contentharness');
(async () => {
  const H = await start(process.env.BUILD || 'drills.t426.html');
  const store = { pb_lesson_steps_v1: JSON.stringify({ 'posture-hands': { 0: 1, 1: 1, 3: 1, 5: 1, 6: 1, 7: 1 }, 'first-steps': { 0: 1 } }), pb_steps_total_v1: JSON.stringify({ 'posture-hands': 6, 'first-steps': 9 }) };
  for (const lang of ['en', 'ko']) {
    const p = await H.open({ path: '', w: 390, h: 844, store, lang, dsf: 2 }); await p.waitForTimeout(900);
    const m = await p.$('[data-house]'); await m.screenshot({ path: 'p425/vill-' + lang + '.png' });
    if (lang === 'en') {
      await p.click('[data-building="0"]'); await p.waitForTimeout(140);
      await m.screenshot({ path: 'p425/vill-zoom-mid.png' });
      await p.waitForTimeout(700); await m.screenshot({ path: 'p425/vill-zoom-end.png' });
      await p.click('[data-house] .chip:has-text("›")'); await p.waitForTimeout(800); await m.screenshot({ path: 'p425/vill-next.png' });
      await p.click('[data-back]'); await p.waitForTimeout(600);
      console.log('back to village', await p.evaluate(() => document.querySelector('[data-house]').dataset.layout));
    }
    console.log(lang, 'errs', p._errs.join('|').slice(0, 200));
    await p.context().close();
  }
  await H.close();
})().catch(e => { console.error('CRASH', e); process.exit(1); });
