const { start } = require('./contentharness');
(async () => {
  const H = await start('drills.new.html');
  const issues = [];
  let p = await H.open({ path: '', w: 1024, h: 900 });
  await p.waitForTimeout(800);
  const ids = await p.evaluate(() => [...document.querySelectorAll('[data-house] [data-chapter]')].map(e => e.dataset.chapter));
  await p.context().close();
  for (const id of ids) {
    p = await H.open({ path: '?drill=' + id, w: 390, h: 900 });
    await p.waitForTimeout(700);
    const t = await p.$('button:has-text("Drill")');
    if (t) { await t.click(); await p.waitForTimeout(900); }
    // answer nothing; just check the question screen rendered without errors
    if (p._errs.length) issues.push('drill ' + id + ': ' + p._errs.join(' | ').slice(0, 160));
    await p.context().close();
  }
  // the known finger-friends width issue, still true?
  p = await H.open({ path: '?tool=finger-friends', w: 390, h: 900 });
  await p.waitForTimeout(900);
  const sw = await p.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
  console.log('finger-friends sideways scroll:', sw, 'px');
  if (p._errs.length) issues.push('finger-friends: ' + p._errs.join('|').slice(0, 160));
  await p.context().close();
  await H.close();
  console.log('DRILL ISSUES', issues.length); issues.forEach(x => console.log(' -', x));
  process.exit(0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
