const { chromium } = require('playwright');
(async () => {
  const [src, out, w] = process.argv.slice(2);
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const p = await b.newPage({ viewport: { width: +(w || 1400), height: 900 }, deviceScaleFactor: 1.5 });
  await p.goto('file://' + src); await p.waitForTimeout(800); await p.evaluate(() => document.fonts.ready);
  await p.screenshot({ path: out, fullPage: true });
  await b.close();
})();
