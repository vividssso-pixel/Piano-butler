const { start } = require('./contentharness');
(async () => {
  const H = await start('drills.new.html');
  for (const path of ['?drill=posture-hands', '?drill=posture-hands&view=drill', '?drill=first-steps']) {
    const p = await H.open({ path, w: 390, h: 900 });
    const hits = await p.evaluate(() => (document.body.innerText.match(/Game mode[^\n]*/g) || []).concat(document.body.innerText.match(/게임 모드[^\n]*/g) || []));
    console.log(path, JSON.stringify(hits));
    await p.context().close();
  }
  const p = await H.open({ path: '?drill=posture-hands', w: 390, h: 900 });
  const clicked = await p.evaluate(() => { const b = [...document.querySelectorAll('button')].find(x => /Drill|Level/i.test(x.textContent)); if (b) { b.click(); return b.textContent; } return null; });
  await p.waitForTimeout(800);
  const hits = await p.evaluate(() => (document.body.innerText.match(/(Game|Lesson) mode[^\n]*/g) || []));
  console.log('after click', JSON.stringify(clicked), JSON.stringify(hits));
  await p.context().close(); await H.close(); process.exit(0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
