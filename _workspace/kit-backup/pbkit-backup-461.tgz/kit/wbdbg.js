const { start } = require('./contentharness');
(async () => {
  const H = await start('drills.new.html');
  const p = await H.open({ path: '?book=work&ch=first-steps&lang=en', w: 900, h: 1200 });
  p.on('console', m => { if (m.type() === 'error') console.log('console:', m.text().slice(0, 300)); });
  await p.reload(); await p.waitForTimeout(2000);
  console.log('errs', p._errs.join(' | ').slice(0, 600));
  console.log((await p.evaluate(() => document.body.innerText)).slice(0, 300));
  await H.close(); process.exit(0);
})();
