// the map page in three moments: a beginner (Clara), a student who jumped straight to Theory, a named student further on
const { start } = require('./contentharness');
(async () => {
  const H = await start(process.env.BUILD || 'drills.t426.html');
  const at = (d) => new Date(d + 'T16:00:00').getTime();
  const days = ['2026-10-05', '2026-10-06', '2026-10-08', '2026-09-28', '2026-09-29', '2026-09-30', '2026-10-01', '2026-10-02', '2026-09-22', '2026-09-24'];
  const recs = { 'staff|1|lesson': { plays: days.length, best: 8, lastAt: at(days[0]), history: days.map(d => ({ at: at(d), score: 8, correct: 8, total: 10 })) } };
  const full = (n) => { const o = {}; for (let i = 0; i < n; i++) o[i] = 1; return o; };
  const cases = [
    ['beginner', { pb_lesson_steps_v1: JSON.stringify({ 'posture-hands': full(6), 'first-steps': { 0: 1 } }), pb_steps_total_v1: JSON.stringify({ 'posture-hands': 6, 'first-steps': 9 }), pb_drill_records_v1: JSON.stringify(recs) }],
    ['jumped', { pb_lesson_steps_v1: JSON.stringify({ scales: { 0: 1, 1: 1 } }), pb_steps_total_v1: JSON.stringify({ scales: 6 }), pb_last_chapter_v1: 'scales', pb_drill_records_v1: JSON.stringify(recs) }],
    ['further', { pb_lesson_steps_v1: JSON.stringify({ 'posture-hands': full(6), 'first-steps': full(9), 'note-names': full(8), staff: full(7), 'whole-staff': full(7), 'ledger-lines': full(4), tones: { 0: 1 } }), pb_steps_total_v1: JSON.stringify({ 'posture-hands': 6, 'first-steps': 9, 'note-names': 8, staff: 7, 'whole-staff': 7, 'ledger-lines': 4, tones: 5 }), pb_drill_records_v1: JSON.stringify(recs), pb_link_token_v1: 'abcdefghijklmnopqrstuvwxyzABCDEF0123456789', pb_link_name_v1: 'Minjun' }],
  ];
  for (const [tag, store] of cases) {
    const p = await H.open({ path: '?view=map', w: 390, h: 844, store, dsf: 2 }); await p.waitForTimeout(1200);
    const m = await p.$('[data-house]'); await m.screenshot({ path: 'p425/m4-' + tag + '.png' });
    console.log(tag, 'errs', p._errs.join('|').slice(0, 200));
    await p.context().close();
  }
  await H.close();
})().catch(e => { console.error('CRASH', e); process.exit(1); });
