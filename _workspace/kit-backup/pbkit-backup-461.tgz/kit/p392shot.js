const { start } = require('./contentharness');
(async () => {
  const H = await start('drills.p392.html');
  let p = await H.open({ path: '?book=spread&ch=first-steps&lang=en', w: 900, h: 1200 });
  await p.waitForTimeout(2000);
  const pages = await p.$$('.bk-page');
  const info = await p.$$eval('.bk-page', els => els.map(e => { const b = e.querySelector('.bk-body'); return b ? b.scrollHeight - b.clientHeight : (e.scrollHeight - e.clientHeight); }));
  console.log('spread pages', pages.length, 'overflow', JSON.stringify(info), 'errs', p._errs.join('|').slice(0, 300));
  for (const i of [0, 1, 2, 3, 4]) await pages[i].screenshot({ path: 'p392/spread-' + i + '.png' });
  await p.pdf({ path: 'p392/spread.pdf', preferCSSPageSize: true, printBackground: true });
  await p.context().close();
  p = await H.open({ path: '?drill=first-steps', w: 390, h: 900 });
  await p.waitForTimeout(800);
  const st = await p.$('section[id^="first-steps-step-"]'); if (st) { await st.scrollIntoViewIfNeeded(); await st.screenshot({ path: 'p392/app-step1.png' }); }
  console.log('app errs', p._errs.join('|').slice(0, 200), 'sideways', await p.evaluate(() => document.documentElement.scrollWidth - innerWidth));
  await H.close(); process.exit(0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
