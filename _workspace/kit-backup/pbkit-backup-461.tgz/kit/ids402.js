const { start } = require('./contentharness');
(async () => {
  const H = await start(process.env.BUILD || 'drills.t400.html');
  const p = await H.open({ path: '?book=work&ch=front&lang=en', w: 900, h: 900 });
  console.log(JSON.stringify(await p.evaluate(() => pathIds())));
  await H.close(); process.exit(0);
})();
