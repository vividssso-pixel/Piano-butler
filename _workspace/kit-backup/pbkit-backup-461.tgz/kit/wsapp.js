const { start } = require('./contentharness');
(async () => {
  const H = await start(process.env.BUILD);
  const p = await H.open({ path: '?drill=whole-staff', w: 420, h: 900 });
  await p.waitForTimeout(2200);
  // open every step (they may be collapsed) by clicking each step header
  const heads = await p.$$('[data-step-head], .step-head, button[aria-expanded="false"]');
  for (const h of heads) { try { await h.click(); await p.waitForTimeout(150); } catch (e) {} }
  await p.waitForTimeout(600);
  const H0 = await p.evaluate(() => document.documentElement.scrollHeight);
  let i = 0; for (let y = 0; y < Math.min(H0, 9000); y += 880) { await p.evaluate(yy => window.scrollTo(0, yy), y); await p.waitForTimeout(300); await p.screenshot({ path: 'wsapp-' + (++i) + '.png' }); }
  console.log('height', H0, 'shots', i, p._errs.join('|'));
  await H.close();
})();
