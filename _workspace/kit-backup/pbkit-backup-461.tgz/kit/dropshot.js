const { start } = require('./contentharness');
(async () => {
  const H = await start('drills.new.html');
  const p1 = await H.open({ path: '?drill=posture-hands', w: 390, h: 900 });
  const warmSel = '#posture-hands-step-1 [data-warm]';
  const cards = await p1.$$(warmSel);
  await p1.evaluate(sel => document.querySelectorAll(sel)[3].scrollIntoView({ block: 'center' }), warmSel);
  await (await cards[3].$('svg, .pb-art, div')).click();
  await p1.waitForTimeout(600);
  await cards[3].screenshot({ path: 'shot-drop-lift.png' });
  await p1.waitForTimeout(950);
  await cards[3].screenshot({ path: 'shot-drop-press.png' });
  await p1.waitForTimeout(3500);
  await cards[3].screenshot({ path: 'shot-drop-rest.png' });
  console.log('errs:', p1._errs.join('|') || 'none');
  await p1.context().close(); await H.close(); process.exit(0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
