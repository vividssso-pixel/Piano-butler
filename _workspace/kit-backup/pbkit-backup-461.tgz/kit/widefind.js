const { start } = require('./contentharness');
(async () => {
  const H = await start('drills.new.html');
  for (const lang of ['en', 'ko']) {
    const p = await H.open({ path: '?drill=first-steps', w: 390, h: 900, lang });
    await p.waitForTimeout(900);
    const wide = await p.evaluate(() => {
      const out = [];
      document.querySelectorAll('*').forEach(e => {
        const r = e.getBoundingClientRect();
        if (r.right > 391 && r.width < 2000 && !e.querySelector('*')) {
          let el = e, path = [];
          for (let i = 0; i < 5 && el; i++) { path.push(el.tagName + (el.dataset && el.dataset.warm ? '.' + el.dataset.warm : '') + (el.className && typeof el.className === 'string' ? '.' + el.className.split(' ')[0] : '')); el = el.parentElement; }
          out.push({ right: Math.round(r.right), w: Math.round(r.width), txt: (e.textContent || '').slice(0, 40), path: path.join(' < ') });
        }
      });
      return out.slice(0, 8);
    });
    console.log(lang, JSON.stringify(wide, null, 1));
    await p.context().close();
  }
  await H.close(); process.exit(0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
