const { start } = require('./contentharness');
(async () => {
  const H = await start('drills.new.html');
  const p1 = await H.open({ path: '?drill=posture-hands', w: 390, h: 900 });
  const warmSel = '#posture-hands-step-1 [data-warm]';
  const cards = await p1.$$(warmSel);
  await p1.evaluate(sel => document.querySelectorAll(sel)[2].scrollIntoView({ block: 'center' }), warmSel);
  await (await cards[2].$('svg, .pb-art, div')).click();
  for (const [ms, n] of [[900, 'a'], [1300, 'b'], [1600, 'c']]) {
    await p1.waitForTimeout(ms);
    await cards[2].screenshot({ path: 'shot-glide-' + n + '.png' });
  }
  await p1.context().close(); await H.close(); process.exit(0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
