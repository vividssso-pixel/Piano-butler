# Chapter 2 review pack: front pages (cover, A, B) + the drill page, as HTML for Chromium to print
import os
NM = os.path.abspath('../node_modules/@fontsource')
FONTS = ''.join(f"@font-face{{font-family:'Inter';font-weight:{w};src:url(file://{NM}/inter/files/inter-latin-{w}-normal.woff2) format('woff2');}}" for w in (400, 600, 700, 800)) + \
        ''.join(f"@font-face{{font-family:'Playfair Display';font-weight:{w};src:url(file://{NM}/playfair-display/files/playfair-display-latin-{w}-normal.woff2) format('woff2');}}" for w in (800, 900))
CSS = FONTS + """
@page { size:A4; margin:0; }
* { box-sizing:border-box; }
body { margin:0; font-family:Inter,'Noto Sans CJK KR',sans-serif; color:#26296b; font-size:11.5pt; line-height:1.45; }
.pg { width:210mm; height:297mm; padding:13mm 15mm 17mm; page-break-after:always; position:relative; overflow:hidden; }
.pg:last-child { page-break-after:auto; }
h1, h2 { font-family:'Playfair Display',Georgia,serif; margin:0; line-height:1.1; }
h1 { font-size:30pt; font-weight:900; }
h2 { font-size:17pt; font-weight:900; margin:0 0 2mm; }
.k { color:#e4572e; font-weight:800; font-size:10pt; margin-bottom:2mm; }
.sub { color:#4a4d86; margin:2mm 0 0; }
.box { border:1.2px solid #26296b; border-radius:3mm; padding:3.5mm 5mm; margin-top:4mm; }
.toc { width:100%; border-collapse:collapse; margin-top:2mm; font-size:11pt; }
.toc td { padding:1.4mm 0; border-bottom:0.6px solid #d9d4c4; }
.toc td.n { text-align:right; color:#6d6f9c; white-space:nowrap; }
.how li { margin:1mm 0; }
.q { margin-top:4mm; }
.q > b { display:block; }
.lines { height:12mm; background:repeating-linear-gradient(#fff 0 6.6mm, #b9b6d8 6.6mm 6.9mm); margin-top:1mm; }
.lines.s { height:8.5mm; }
.item { display:grid; grid-template-columns:9mm 1fr 30mm; gap:2mm; padding:2.2mm 0; border-bottom:0.6px solid #d9d4c4; font-size:10.3pt; break-inside:avoid; }
.item .id { font-weight:800; color:#e4572e; }
.item .t b { color:#26296b; }
.item .t { color:#3c3f78; }
.item .fx { color:#26296b; font-weight:600; margin-top:0.8mm; }
.tick { font-size:9.5pt; color:#26296b; white-space:nowrap; }
.tick span { display:inline-block; width:3.6mm; height:3.6mm; border:1.2px solid #26296b; border-radius:0.8mm; vertical-align:-0.6mm; margin-right:1mm; }
.yel { background:#fff1a8; }
.grid3 { display:grid; grid-template-columns:repeat(3,1fr); gap:4mm; margin-top:3mm; align-items:start; }
.grid3 img { width:100%; border:0.6px solid #d9d4c4; border-radius:2mm; }
.cap { font-size:9.5pt; font-weight:700; margin-top:1mm; }
.foot { position:absolute; bottom:8mm; left:15mm; right:15mm; font-size:8.5pt; color:#6d6f9c; display:flex; justify-content:space-between; }
"""


def page(inner, foot):
    return f'<section class="pg">{inner}<div class="foot"><span>Piano Butler · Chapter 3 review · The Musical Alphabet (Note Names)</span><span>{foot}</span></div></section>'

def doc(pages):
    return f'<!doctype html><html lang="en"><head><meta charset="utf-8"><style>{CSS}</style></head><body>{"".join(pages)}</body></html>'

tick = '<div class="tick"><span></span>Fix it &nbsp;&nbsp;<span></span>No / differently</div>'

cover = """
<div class="k">PIANO BUTLER · CHAPTER-BY-CHAPTER REVIEW · 2026-10-09</div>
<h1>Chapter 3 · Note Names</h1><div style="font-family:'Playfair Display',Georgia,serif;font-size:15pt;font-weight:800;margin-top:1mm">proposed name: The Musical Alphabet <span class="yel" style="font-size:9pt;font-family:Inter">B1</span></div>
<p class="sub">챕터 2가 <b>이름이 어디 사는지</b>(패턴 → 집 → 글자 → 가운데 도)를 맡았으니, 챕터 3은 <b>이름을 빨리 대기</b>로 새로 짰어요: 글자 관람차(일곱 글자가 돌고 돌기, 같은 글자 = 옥타브) → 위로는 앞으로, 아래로는 거꾸로 → 보자마자 이름 대기(문과 집 안) → 한 글자 건너뛰기 → 음이름 보고 핫 크로스 번. 샵·플랫은 6챕터(온음과 반음), 3도·5도 같은 숫자는 음정 챕터로 아꼈어요. 그림은 2챕터와 같은 펜·두 잉크예요. <span class="yel">노란 표시</span> = 답을 기다리는 부분.</p>
<div class="box">
  <h2>공개 가이드 페이지를 위한 질문 3개</h2>
  <div class="q"><b>Q1. 음이름에서 학생들이 가장 자주 막히는 곳은 어디인가요?</b> (거꾸로? C부터 세기? — "From the teacher" 칸에 들어가요)<div class="lines s"></div></div>
  <div class="q"><b>Q2. 음이름을 빨리 나오게 만드는 소현님만의 방법이 있나요?</b> (릴레이 바통처럼, 다른 선생님이 바로 따라 할 수 있는 것 — "Teacher's tip")<div class="lines s"></div></div>
  <div class="q"><b>Q3. 집에서는 음이름 연습을 어떻게 시키세요?</b> (하루 몇 분, 어떤 놀이 — 공개 페이지의 연습 안내에 들어가요)<div class="lines s"></div></div>
</div>
<div class="box">
  <h2>In this pack</h2>
  <table class="toc">
    <tr><td>A. What I found (7 items)</td><td class="n">p. 2</td></tr>
    <tr><td>B. Teaching questions (10)</td><td class="n">p. 3</td></tr>
    <tr><td><b>The new Lesson Book &mdash; draft</b> (yellow = waiting for B answers)</td><td class="n">p. 4&ndash;10</td></tr>
    <tr><td>The Workbook as it is today</td><td class="n">p. 11&ndash;17</td></tr>
    <tr><td>The Teacher copy as it is today</td><td class="n">p. 18&ndash;19</td></tr>
    <tr><td>The online lesson and the drill as they are today</td><td class="n">p. 20</td></tr>
  </table>
</div>
<div class="box how">
  <h2>How to mark</h2>
  <ul>
    <li>A 항목: <b>Fix it</b>에 체크하면 그대로 고칠게요. 다르게 고치고 싶으면 옆에 적어 주세요.</li>
    <li>B 질문: 한 줄이면 충분해요. "응"도 답이에요.</li>
    <li>레슨북 초안: 아무 쪽이나 빨간펜 환영 — 사진으로 보내시거나 채팅에 번호로 답해 주세요.</li>
  </ul>
</div>
"""

a_items = [
    ("A1", "<b>Chapter 2 is repeated.</b> The app lesson's steps 1&ndash;2 (“The black-key map”, C and F by the black keys, “Seven letters”), Workbook p.3 (Find every C and F) and check-up A teach again what chapter 2's pages 3&ndash;4 now teach.",
     "&rarr; The chapter starts where chapter 2 stops (the draft): the app lesson, Workbook and check-up follow the new pages."),
    ("A2", "<b>“Front door” vs “left door”.</b> The Workbook cover (“C is its front door”), p.3 and the Teacher copy p.3 say <b>front door</b>; chapter 2 now says C and F are the houses' <b>left doors</b>.",
     "&rarr; “Left door” everywhere (and the new “doors and insides” words on p.4 of the draft)."),
    ("A3", "<b>Sharps and flats arrive early.</b> The app's first keyboard labels the black keys C&#9839;/D&#9837;, F&#9839;/G&#9837;&hellip; and drill level 4 is “Black keys too (sharps &amp; flats)” &mdash; but sharps and flats are taught in chapter 6, Tones &amp; Semitones.",
     "&rarr; Black keys stay unnamed in chapter 3; level 4 moves (see B7)."),
    ("A4", "<b>Interval numbers arrive early.</b> The letter-chain tool has 2nd&ndash;7th/8ve chips and drill level 6 asks “down a 5th” &mdash; intervals are chapter 13.",
     "&rarr; In chapter 3 only: next letter (step), skip a letter, same letter (octave). The numbers move to Intervals (see B7)."),
    ("A5", "<b>The staff arrives early.</b> The letter-chain tool (app step 4) has a “Staff” switch &mdash; the staff is chapter 4.",
     "&rarr; Hide the switch in chapter 3; it stays in Reading the Staff."),
    ("A6", "<b>One chapter, several names.</b> The map says “Note Names”, the app lesson's title says “Finding notes on the keyboard / 건반에서 음이름 찾기”, the house map's room says “음 이름” (with a space) &mdash; and chapter 2 is already “Keyboard Patterns &amp; <b>Note Names</b>”.",
     "&rarr; One name everywhere (B1)."),
    ("A7", "<b>Old drawings, old steps.</b> The Workbook's pictures (houses with doors, the Ferris wheel, the staircase, the treasure-hunt keyboard) are the old flat style without the pastel house tints, and its pages follow the old 4 app steps.",
     "&rarr; When applied: pen drawings in the two inks, the house tints, and one Workbook page facing each book page (as chapter 2). The good activities stay: missing letters, word search, treasure hunt, the letter star."),
]

a_page = '<div class="k">CHAPTER 3 REVIEW</div><h2>A. What I found</h2><p class="sub" style="font-size:10pt">각 항목: 그대로 고칠까요? 체크해 주세요.</p>' + ''.join(
    f'<div class="item"><div class="id">{i}</div><div class="t">{txt}<div class="fx">{fx}</div></div>{tick}</div>' for i, txt, fx in a_items)

b_items = [
    ("B1", "챕터 이름: 2챕터가 이미 “건반 패턴과 <b>음이름</b>”이라, 3챕터를 <b>“The Musical Alphabet / 음악 알파벳”</b>으로 바꿀까요? (앱·책·드릴·하우스 맵·가이드 페이지 전부 통일)"),
    ("B2", "도레미: 한국어 앱은 이미 글자 옆에 도레미를 보여 줘요 (C 도). 책(영어)에도 “C = Do” 한 줄을 넣을까요, 아니면 지금처럼 글자만?"),
    ("B3", "<b>“옥타브”</b>라는 말을 여기서 처음 쓸까요? (“C에서 다음 C까지, 두 C를 모두 세면 흰건반 8개”) &mdash; 아니면 “다음 C”까지만?"),
    ("B4", "빨리 대기의 도구로 <b>문과 집 안</b>: C·E·F·B = 문, D·G·A = 집 안 (G 왼쪽, A 오른쪽). 실제로 이렇게 가르치시나요, 다른 기준점이 있나요?"),
    ("B5", "<b>건너뛰기(C E G B D F A)와 별</b>을 이 챕터에 넣고, “다음 챕터 오선보에서 다시 만나요”로 다리를 놓을까요?"),
    ("B6", "연주 페이지: <b>핫 크로스 번이 작은 집으로 이사</b> (오른손 2 3 4를 C D E에, 이번엔 글자를 읽고; 왼손은 한 집 아래) &mdash; 괜찮을까요, 다른 곡이 좋을까요? (2 3 4만 쓰는 곡이어야 해요)"),
    ("B7", "드릴 단계 제안: 1 이름 대기 · 2 건반 찾기 · 3 두 옥타브 양쪽 · 4 다음 글자 위/아래 · 5 한 글자 건너뛰기. <b>검은건반(샵·플랫)은 온음과 반음 챕터</b>로, <b>3도~옥타브 숫자는 음정 챕터</b>로 옮길까요?"),
    ("B8", "속도 목표: <b>“둘 세기 전에”</b>(약 2초) 이름 대기 &mdash; 실제로 기대하시는 속도와 맞나요?"),
    ("B9", "7쪽 <b>다섯 가지 확인</b>(앞으로·거꾸로 / 보자마자 이름 / 모든 옥타브 / 건너뛰기 / 글자 보고 핫 크로스 번) &mdash; 실제로 확인하실 다섯 가지와 맞나요?"),
    ("B10", "<b>소리 내어 글자 잇기</b>(선생님과 한 글자씩 번갈아, 그다음 거꾸로)를 연주 페이지 세 번째 활동으로 &mdash; 이대로 괜찮을까요?"),
]
b_page = '<div class="k">CHAPTER 3 REVIEW</div><h2>B. Teaching questions</h2><p class="sub" style="font-size:10pt">한 줄씩이면 충분해요.</p>' + ''.join(
    f'<div class="q"><b>{i}. {txt}</b><div class="lines s"></div></div>' for i, txt in b_items)

drill_page = """
<div class="k">CHAPTER 3 · AS IT IS TODAY</div><h2>The online lesson (4 steps) and the drill (6 levels)</h2>
<p class="sub" style="font-size:10pt">레슨 1&ndash;2단계는 2챕터와 겹쳐요 (A1). 4단계의 숫자 칩과 Staff 스위치는 A4&middot;A5, 드릴 4&middot;6단계는 B7을 봐 주세요.</p>
<img src="app-sheet.png" style="width:100%;border:0.6px solid #d9d4c4;border-radius:2mm;margin-top:3mm">
<div class="grid3" style="grid-template-columns:repeat(6,1fr);gap:2.5mm">
  <div><img src="drill-l1.png"><div class="cap">1 · Name the key</div></div>
  <div><img src="drill-l2.png"><div class="cap">2 · Find the key</div></div>
  <div><img src="drill-l3.png"><div class="cap">3 · Two octaves</div></div>
  <div><img src="drill-l4.png"><div class="cap">4 · Black keys (A3)</div></div>
  <div><img src="drill-l5.png"><div class="cap">5 · Next letter</div></div>
  <div><img src="drill-l6.png"><div class="cap">6 · 3rds to octaves (A4)</div></div>
</div>
"""

pages = [page(cover, 'p. 1'), page(a_page, 'p. 2'), page(b_page, 'p. 3'), page(drill_page, 'p. 20')]
open('front.html', 'w').write(doc(pages[:3]))
open('drillpg.html', 'w').write(doc([pages[3]]))
print('front.html + drillpg.html written')
