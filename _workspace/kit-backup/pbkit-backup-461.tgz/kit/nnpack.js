const { start } = require('./contentharness');
(async () => {
  let H = await start('drills.nn391.html');
  let p = await H.open({ path: '?book=lesson&ch=note-names&lang=en&draft=1', w: 900, h: 1200 });
  await p.waitForTimeout(1800);
  await p.pdf({ path: 'pack3/lesson-draft.pdf', preferCSSPageSize: true, printBackground: true });
  await p.context().close(); await H.close();
  H = await start('drills.new.html');
  for (const kind of ['work', 'teacher']) {
    p = await H.open({ path: '?book=' + kind + '&ch=note-names&lang=en', w: 900, h: 1200 });
    await p.waitForTimeout(1500);
    await p.pdf({ path: 'pack3/' + kind + '.pdf', preferCSSPageSize: true, printBackground: true });
    await p.context().close();
  }
  await H.close(); process.exit(0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
