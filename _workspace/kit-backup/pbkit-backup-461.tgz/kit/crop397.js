const { start } = require('./contentharness');
(async () => {
  const H = await start(process.env.BUILD || 'drills.t398.html');
  const p = await H.open({ path: '?book=lesson&ch=note-names&lang=en', w: 900, h: 1200 }); await p.setViewportSize({width:900,height:1200});
  await p.waitForTimeout(1800);
  const el = (await p.$$('.bk-page'))[4];
  const pic = await el.$('.lb-pic');
  await p.evaluate(() => { document.body.style.zoom = 1; });
  await pic.screenshot({ path: 'p397/crop-p5.png', scale: 'device' });
  await H.close(); process.exit(0);
})();
