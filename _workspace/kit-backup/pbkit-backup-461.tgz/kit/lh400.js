const { start } = require('./contentharness');
(async () => {
  const H = await start('drills.t400.html');
  const p = await H.open({ path: '?book=lesson&ch=first-steps&lang=en', w: 900, h: 1200 });
  await p.waitForTimeout(1500);
  const pg = (await p.$$('.bk-page'))[3];
  await (await pg.$('.lb-pic')).screenshot({ path: 'p397/lh.png' });
  console.log(p._errs.join('|'));
  await H.close(); process.exit(0);
})();
