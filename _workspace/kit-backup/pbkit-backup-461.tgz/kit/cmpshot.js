const { chromium } = require('playwright');
(async () => { const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' }); const p = await b.newPage({ viewport: { width: 600, height: 900 } });
  await p.goto('file:///home/claude/pbtest/cmp389.html'); await p.waitForTimeout(300); await p.screenshot({ path: 'cmp389.png', fullPage: true }); await b.close(); })();
