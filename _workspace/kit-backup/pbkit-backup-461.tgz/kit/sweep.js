// Full error sweep: every chapter's lesson page + every book page (work/teacher) + ch1 lesson/spread
const { start } = require('./contentharness');
(async () => {
  const H = await start(process.env.BUILD || 'drills.new.html');
  const issues = [];
  // chapter ids from the map
  let p = await H.open({ path: '', w: 1024, h: 900 });
  await p.waitForTimeout(900);
  const ids = await p.evaluate(() => [...document.querySelectorAll('[data-house] [data-chapter]')].map(e => e.dataset.chapter));
  console.log('chapters', ids.length);
  await p.context().close();
  // 1. lesson pages at phone width
  for (const id of ids) {
    p = await H.open({ path: '?drill=' + id, w: 390, h: 900 });
    await p.waitForTimeout(900);
    const scroll = await p.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
    if (p._errs.length) issues.push('lesson ' + id + ' ERRORS: ' + p._errs.join(' | ').slice(0, 200));
    if (scroll > 1) issues.push('lesson ' + id + ' sideways scroll ' + scroll + 'px');
    await p.context().close();
  }
  console.log('lessons done');
  // 2. books: workbook + teacher for every chapter that has one, plus front matter and ch1 lesson/spread
  const books = [['work', 'front']].concat(ids.flatMap(id => [['work', id], ['teacher', id]]));
  books.push(['lesson', 'posture-hands'], ['spread', 'posture-hands']);
  for (const [kind, ch] of books) {
    p = await H.open({ path: '?book=' + kind + '&ch=' + ch + '&lang=en', w: 900, h: 1200 });
    await p.waitForTimeout(1300);
    const n = await p.$$eval('.bk-page', els => els.length).catch(() => 0);
    if (!n) { if (!['lesson'].includes(kind)) issues.push('book ' + kind + '/' + ch + ': no pages'); await p.context().close(); continue; }
    const over = await p.$$eval('.bk-page', els => els.map((e, i) => { const b = e.querySelector('.bk-body'); return b ? [i + 1, b.scrollHeight - b.clientHeight] : [i + 1, null]; }).filter(([, v]) => v !== null && v > 1));
    const spill = await p.$$eval('.bk-page .pb-art', els => els.filter(a => { const b = a.getBoundingClientRect(), q = a.closest('.bk-body'); if (!q) return false; const r = q.getBoundingClientRect(); return b.bottom > r.bottom + 1.5 || b.right > r.right + 1.5; }).map(a => a.dataset.art)).catch(() => []);
    if (over.length) issues.push('book ' + kind + '/' + ch + ' overflow ' + JSON.stringify(over));
    if (spill.length) issues.push('book ' + kind + '/' + ch + ' art spills ' + JSON.stringify(spill));
    if (p._errs.length) issues.push('book ' + kind + '/' + ch + ' ERRORS: ' + p._errs.join(' | ').slice(0, 200));
    await p.context().close();
  }
  console.log('books done');
  await H.close();
  console.log('ISSUES', issues.length);
  issues.forEach(x => console.log(' -', x));
  process.exit(0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
