const { start } = require('./contentharness');
(async () => {
  const H = await start(process.env.BUILD);
  const p = await H.open({ path: '?book=lesson&ch=ledger-lines&lang=en', w: 900, h: 1200 });
  await p.waitForTimeout(2200);
  const el = await p.$$('.bk-page'); await el[2].screenshot({ path: 'p430-page.png' });
  const q = await H.open({ path: '?map=1', w: 420, h: 900 }); await q.waitForTimeout(2500); await q.screenshot({ path: 'p430-map.png' });
  console.log(p._errs.join('|'), q._errs.join('|'));
  await H.close();
})();
