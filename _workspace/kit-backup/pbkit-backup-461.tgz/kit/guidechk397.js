const { chromium } = require('playwright'); const path = require('path');
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  for (const [f, w] of [['musical-alphabet.html', 390], ['musical-alphabet.html', 1200], ['index.html', 390], ['keyboard-patterns.html', 390]]) {
    const p = await b.newPage({ viewport: { width: w, height: 900 } });
    await p.route(/^https?:\/\//, r => r.abort());
    await p.goto('file:///tmp/claude-0/site397/lessons/' + f); await p.waitForTimeout(500);
    const r = await p.evaluate(() => ({ sx: document.documentElement.scrollWidth - document.documentElement.clientWidth, robots: (document.querySelector('meta[name=robots]') || {}).content, canon: (document.querySelector('link[rel=canonical]') || {}).href, h1: document.querySelector('h1').textContent, next: [...document.querySelectorAll('nav.next a')].map(a => a.getAttribute('href')), rooms: [...document.querySelectorAll('a.room')].map(a => a.getAttribute('href')), svgs: document.querySelectorAll('svg.pic').length, ld: !!document.querySelector('script[type="application/ld+json"]') }));
    console.log(f, w, JSON.stringify(r));
    if (f === 'musical-alphabet.html') await p.screenshot({ path: 'p397/guide-' + w + '.png', fullPage: true });
    await p.close();
  }
  await b.close();
})();
