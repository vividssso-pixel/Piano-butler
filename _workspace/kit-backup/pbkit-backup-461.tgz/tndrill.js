const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => {
  const H = await start('drills.t437.html');
  for (let lv = 1; lv <= 7; lv++) {
    const p = await H.open({ path: '?drill=tones&tab=drill&level=' + lv, w: 430, h: 1000, lang: 'en', dsf: 1.5 }); await p.waitForTimeout(1500);
    const el = await p.evaluateHandle(() => { const c = [...document.querySelectorAll('div')].filter(d => /^Question 1 \/ 10/.test(d.textContent.trim())).map(d => [d, d.getBoundingClientRect().height]).filter(([, h]) => h < 700).sort((a, b) => b[1] - a[1]); return c[0] && c[0][0]; });
    await el.screenshot({ path: '/home/claude/pbtest/kit/pack437/q-' + lv + '.png' });
    await p.context().close();
  }
  await H.close();
})();
