const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => {
  const H = await start('drills.t442.html');
  for (const [ch, nm] of [['posture-hands', 'p1'], ['first-steps', 'p2']]) {
    const p = await H.open({ path: '?drill=' + ch, w: 430, h: 900 }); await p.waitForTimeout(1500);
    const el = await p.$('.try-box, [role=img]'); const imgs = await p.$$('[role=img], .pb-art');
    if (imgs[0]) await imgs[0].screenshot({ path: '/tmp/claude-0/v442-' + nm + '.png' });
    console.log(ch, 'errs', p._errs.join('|')); await p.context().close();
  }
  const p = await H.open({ path: '', w: 390, h: 900 }); await p.waitForTimeout(1500);
  const l0 = await p.evaluate(() => document.querySelector('[data-house]').dataset.layout);
  await p.click('[data-house] [data-door]'); await p.waitForTimeout(1500);
  const l1 = await p.evaluate(() => document.querySelector('[data-house]').dataset.layout);
  const pos = await p.evaluate(() => { const o = {}; document.querySelectorAll('[data-house] [data-chapter]').forEach(e => { const b = e.getBoundingClientRect(); o[e.dataset.chapter] = [Math.round(b.left), Math.round(b.top)]; }); return o; });
  const lv1 = await p.$('[data-house-view]'); await p.evaluate(() => { const r = document.querySelector('[data-chapter="posture-hands"]'); r.scrollIntoView({ block: 'center' }); }); await p.waitForTimeout(300);
  await p.screenshot({ path: '/tmp/claude-0/v442-house.png' });
  await p.reload(); await p.waitForTimeout(1500);
  const l2 = await p.evaluate(() => document.querySelector('[data-house]').dataset.layout);
  console.log('door', l0, l1, 'after reload', l2); console.log(JSON.stringify(pos));
  await H.close();
})();
