const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => {
  const H = await start(process.argv[2]);
  const lang = process.argv[4] || 'en';
  const p = await H.open({ path: '?book=lesson&ch=tones&lang=' + lang, w: 900, h: 1200, dsf: 2 }); await p.waitForTimeout(2600);
  const n = await p.$$eval('.bk-page', ps => ps.length);
  for (let i = 0; i < Math.min(n, 6); i++) {
    const h = await p.evaluateHandle((i) => { const pg = document.querySelectorAll('.bk-page')[i]; return [...pg.querySelectorAll('svg')].sort((a, b) => b.getBoundingClientRect().width * b.getBoundingClientRect().height - a.getBoundingClientRect().width * a.getBoundingClientRect().height)[0]; }, i);
    await h.screenshot({ path: '/tmp/claude-0/' + process.argv[3] + '-p' + (i + 1) + '.png' });
  }
  await H.close();
})();
