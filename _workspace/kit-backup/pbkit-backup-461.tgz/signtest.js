const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => { const H = await start('drills.t432.html');
  const p = await H.open({ path: '?book=lesson&ch=tones&lang=en', w: 900, h: 700, dsf: 2 }); await p.waitForTimeout(800);
  await p.evaluate(() => {
    const MF = "'Noto Music','Apple Symbols','Segoe UI Symbol',serif";
    const d = document.createElement('div'); d.id = 'tst'; d.style.cssText = 'position:fixed;left:0;top:0;width:900px;background:#fff;z-index:99999;padding:20px;font:500 17px Inter;color:#26296b';
    const rows = [['plain Inter', 'C♯ D♭ E♮ -- C sharp, C♯.'], ['music 1em', '<span style="font-family:' + MF + '">♯ ♭ ♮</span> C<span style="font-family:' + MF + '">♯</span> D<span style="font-family:' + MF + '">♭</span>'],
      ['music 1.35em -0.05', 'C<span style="font-family:' + MF + ';font-size:1.35em;line-height:0;vertical-align:-0.05em">♯</span> D<span style="font-family:' + MF + ';font-size:1.35em;line-height:0;vertical-align:-0.05em">♭</span> E<span style="font-family:' + MF + ';font-size:1.35em;line-height:0;vertical-align:-0.05em">♮</span> sharp'],
      ['music 1.5em 0.1', 'C<span style="font-family:' + MF + ';font-size:1.5em;line-height:0;vertical-align:0.08em">♯</span> D<span style="font-family:' + MF + ';font-size:1.5em;line-height:0;vertical-align:0.08em">♭</span> E<span style="font-family:' + MF + ';font-size:1.5em;line-height:0;vertical-align:0.08em">♮</span> sharp'],
      ['music 1.6em 0.15', 'C<span style="font-family:' + MF + ';font-size:1.6em;line-height:0;vertical-align:0.15em">♯</span> D<span style="font-family:' + MF + ';font-size:1.6em;line-height:0;vertical-align:0.15em">♭</span> E<span style="font-family:' + MF + ';font-size:1.6em;line-height:0;vertical-align:0.15em">♮</span> sharp']];
    d.innerHTML = rows.map(([a, b]) => '<div style="display:flex;gap:20px;border-bottom:1px solid #ccc;padding:6px 0"><span style="width:180px;font-size:12px">' + a + '</span><span>' + b + '</span></div>').join('');
    document.body.appendChild(d); });
  const el = await p.$('#tst'); await el.screenshot({ path: '/tmp/signtest.png' }); await H.close(); })();
