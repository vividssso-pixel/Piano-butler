const { start } = require('/home/claude/pbtest/kit/contentharness'); const fs = require('fs');
(async () => {
  const L = JSON.parse(fs.readFileSync('/home/claude/pbtest/plan435/levels.json'));
  const OUT = process.argv[3] || '/home/claude/pbtest/fix438/mock';
  fs.mkdirSync(OUT, { recursive: true });
  const H = await start(process.argv[2] || 'drills.t436a.html');
  for (const wide of [true, false]) for (const lang of ['en', 'ko']) for (const print of [false, true]) {
    if (print && (lang === 'ko' || !wide)) continue;
    const p = await H.open({ path: '?book=work&ch=front&lang=' + lang, w: 1000, h: 1400, dsf: 2 });
    await p.evaluate(() => Promise.all([document.fonts.load('700 12px Cinzel'), document.fonts.load("700 15px 'Cormorant Garamond'")]));
    const svg = await p.evaluate(({ L, wide, print }) => {
      rdCtx = null;
      if (!DRILLS.find(d => d.id === 'accidentals')) { const tn = DRILLS.find(d => d.id === 'tones'); DRILLS.push({ ...tn, id: 'accidentals', label: 'Accidentals' }); }
      CH_SHORT['accidentals'] = CH_SHORT['accidentals'] || ['Accidentals', '임시표']; CH_SHORT['tones'] = ['Tones & semitones', '온음과 반음']; CH_SHORT['reading-steps'] = [CH_SHORT['reading-steps'][0], '걸음·건너뛰기'];
      HOUSE_ICONS['accidentals'] = HOUSE_ICONS['accidentals'] || '<path d="M17 7 V26 M27 13 V32"/><path d="M17 16 L27 12.5 M17 24 L27 20.5" stroke-width="2.6"/><path d="M36 5 V31"/>';
      const nums = {}; let n = 0; L.forEach(l => l.ids.forEach(id => { nums[id] = ++n; }));
      const doneIds = ['posture-hands', 'first-steps', 'note-names', 'staff', 'whole-staff', 'ledger-lines', 'pulse', 'note-values'];
      const stages = L.map((l, i) => ({ s: { en: l.en, ko: l.ko }, i, ids: l.ids, st: l.ids.map(id => print ? 'print' : doneIds.includes(id) ? 'done' : id === 'tones' ? 'started' : 'new') }));
      const h = townhouseSvg({ stages, here: print ? null : 'tones', nums }, { wide, print }); return penSvg([{ k: 'raw', svg: h.svg }], { vb: h.vb, id: 'hv' });
    }, { L, wide, print });
    await p.evaluate(({ svg, wide }) => { document.body.innerHTML = '<div id="mock" style="width:' + (wide ? 900 : 420) + 'px;background:#fff">' + svg.replace('<svg ', '<svg style="width:100%;display:block" ') + '</div>'; }, { svg, wide });
    await p.waitForTimeout(300);
    const nm = OUT + '/house-' + (wide ? 'wide' : 'tall') + '-' + lang + (print ? '-print' : '');
    await (await p.$('#mock')).screenshot({ path: nm + '.png' }); fs.writeFileSync(nm + '.svg', svg);
    await p.context().close();
  }
  await H.close(); console.log('ok');
})();
