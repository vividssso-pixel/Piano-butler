const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => { const H = await start('drills.t444.html');
  const b = await H.open({ path: '?book=lesson&ch=tones&lang=en', w: 900, h: 1200 }); await b.waitForTimeout(2500);
  const t = await b.evaluate(() => document.body.innerText);
  console.log(/black keys get their names/i.test(t), /not always a black key/.test(t), /very next key, black or white/.test(t), /hidden attic/.test(t), (t.match(/.{0,40}( --|-- ).{0,30}/g) || []).slice(0, 5));
  await H.close(); })();
