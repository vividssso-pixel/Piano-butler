const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => {
  const H = await start('drills.p393.html');
  const p = await H.open({ path: '?book=spread&ch=posture-hands&lang=en', w: 900, h: 1200 });
  await p.waitForTimeout(2000);
  const ov = await p.$$eval('.bk-page', els => els.map(e => { const b = e.querySelector('.bk-body'); return b ? b.scrollHeight - b.clientHeight : 0; }));
  console.log('pages', ov.length, JSON.stringify(ov), p._errs.join('|'));
  await p.pdf({ path: '/mnt/user-data/outputs/Chapter-01-Lesson-Book-and-Workbook-v2.pdf', preferCSSPageSize: true, printBackground: true });
  await H.close(); process.exit(0);
})();
