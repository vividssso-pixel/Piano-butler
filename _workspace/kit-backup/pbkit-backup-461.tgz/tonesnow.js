const { start } = require('/home/claude/pbtest/kit/contentharness');
(async () => { const H = await start('drills.t431.html');
  const p = await H.open({ path: '?drill=tones', w: 390, h: 900 }); await p.waitForTimeout(1500);
  const hgt = await p.evaluate(() => document.documentElement.scrollHeight); console.log('height', hgt, p._errs);
  await p.screenshot({ path: '/tmp/tones-now.png', fullPage: true });
  const q = await H.open({ path: '?book=work&ch=tones&lang=en', w: 1100, h: 1400 }); const els = await q.$$('.bk-page'); console.log('wb pages', els.length);
  for (let i = 0; i < els.length; i++) await els[i].screenshot({ path: '/tmp/tones-wb-' + (i + 1) + '.png' });
  const r = await H.open({ path: '?book=lesson&ch=tones&lang=en', w: 1100, h: 1400 }); console.log('lb pages', (await r.$$('.bk-page')).length);
  await H.close(); })();
