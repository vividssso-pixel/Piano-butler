# The fox butler, full figure: standing in tails, a white-gloved hand holding a candlestick, his bushy tail below the coat.
import sys; sys.path.insert(0, '/home/claude/pbtest/cast')
import butlers
from butlers import bowtie, eye
NAVY = '#26296b'
FOXHEAD = ('M76 72 C70 78 66 84 62 88 C54 94 46 100 37 104 C33 106 33 111 37 112 C44 114 50 115 56 116 C60 117 63 119 65 122 '
           'L77 124 L69 130 L81 132 L73 138 L83 141 L76 146 L76 160 L112 160 C116 150 120 140 124 128 C130 112 132 96 126 78 L118 28 L100 66 L94 67 L80 24 Z')
RUFF = 'M39 111 C47 113 55 115 65 120 L77 124 L69 130 L81 132 L73 138 L83 141 L76 146 L68 142 C58 134 48 122 39 111 Z'
def fox_figure(ink=NAVY, bow='#e4572e', ground='#ffffff', candle=True):
    s = []
    # the tail first (behind the coat), white tip
    s.append('<path d="M94 156 C118 164 136 192 134 224 C133 240 124 250 112 247 C118 228 112 200 92 184 Z" fill="%s"/>' % ink)
    s.append('<path d="M120 232 C126 236 131 236 133.5 228 C133 240 124 250 112 247 C115 242 118 237 120 232 Z" fill="%s"/>' % ground)
    # legs and shoes
    s.append('<path d="M60 146 L74 146 L70 248 L60 248 Z M78 146 L92 146 L86 248 L76 248 Z" fill="%s"/>' % ink)
    s.append('<path d="M48 253 C48 247 54 245 62 245 L71 245 L71 253 Z M64 253 C64 247 70 245 78 245 L87 245 L87 253 Z" fill="%s"/>' % ink)
    s.append('<path d="M52 248 L60 247 M68 248 L76 247" stroke="%s" stroke-width="0.8" stroke-opacity="0.6"/>' % ground)
    # the tailcoat: chest, the cut-away front, the tails behind
    s.append('<path d="M55 88 C50 96 49 108 51 120 C52 130 54 138 57 144 L70 148 L90 148 L95 200 L103 200 L102 148 C102 126 100 104 95 92 C91 87 86 85 80 85 Z" fill="%s"/>' % ink)
    s.append('<path d="M96 160 L100 197" stroke="%s" stroke-width="0.9" stroke-opacity="0.6"/>' % ground)
    # shirt front and waistcoat point
    s.append('<path d="M56 89 L69 89 L61 126 Z" fill="%s"/>' % ground)
    s.append('<path d="M54 92 C56 106 58 118 61 128 M70 91 C69 104 66 118 62 128" fill="none" stroke="%s" stroke-width="0.9"/>' % ground)
    s.append('<path d="M64 132 C70 134 76 134 82 130" fill="none" stroke="%s" stroke-width="0.9" stroke-dasharray="1 1.8"/>' % ground)
    # the head (the cameo's fox, smaller), the white ruff, the eye
    s.append('<g transform="translate(8 -6) scale(0.58)"><path d="%s" fill="%s"/><path d="%s" fill="%s"/>%s'
             '<path d="M80 66 L82 36 L91 62" fill="none" stroke="%s" stroke-width="2.4" stroke-opacity="0.5" stroke-linejoin="round"/><circle cx="36" cy="107.5" r="2.8" fill="%s"/></g>' % (FOXHEAD, ink, RUFF, ground, eye(70, 87, ground, ink, 5.6, 3, -20), ground, ink))
    s.append(bowtie(62, 91, 0.7, bow, ink))
    # the arm with the candlestick (a white glove), the other arm behind his back
    s.append('<path d="M78 96 C74 106 70 116 68 124 C60 124 50 122 42 118" fill="none" stroke="%s" stroke-width="9" stroke-linecap="round" stroke-linejoin="round"/>' % ink)
    s.append('<path d="M72 100 C70 110 67 118 66 122" fill="none" stroke="%s" stroke-width="0.8" stroke-opacity="0.55"/>' % ground)
    s.append('<circle cx="39" cy="117" r="4.6" fill="%s" stroke="%s" stroke-width="1"/>' % (ground, ink))
    if candle:
        s.append('<ellipse cx="38" cy="123" rx="8" ry="2.2" fill="%s"/><rect x="36.6" y="100" width="3" height="22" fill="%s"/><rect x="35" y="86" width="6" height="15" fill="%s" stroke="%s" stroke-width="0.9"/><path d="M38 85 Q34.6 79 38 72 Q41.4 79 38 85 Z" fill="%s"/>' % (ink, ink, ground, ink, bow))
    return ''.join(s)
if __name__ == '__main__':
    svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="10 0 135 258" width="320">%s</svg>' % fox_figure()
    open('foxfig.html', 'w').write('<html><body style="margin:10px">%s</body></html>' % svg)
