#!/usr/bin/env python3
# SAMPLE ONLY, round 6 (Sohyun 2026-10-10 12:08: coral bow tie; the first upright; 'is the fox only in the portrait?'):
# the fox in person where the rabbit stood in person -- at the chapter map's front door and on the print cover page.
import sys, json
sys.path.insert(0, '/home/claude/pbtest/cast')
from foxfig import fox_figure
src = sys.argv[1]; s = open(src, encoding='utf-8').read()
i = s.index('"rabbit": "<svg viewBox=\\"0 0 160 210\\">'); j = s.index('\n', i)
line = s[i:j]; comma = ',' if line.rstrip().endswith(',') else ''
fox = '<svg viewBox="0 0 160 210"><g transform="translate(14 1) scale(0.8)">%s</g></svg>' % fox_figure()
s = s[:i] + '"rabbit": ' + json.dumps(fox) + comma + s[j:]
open(src, 'w', encoding='utf-8').write(s); print('vic6 ok')
