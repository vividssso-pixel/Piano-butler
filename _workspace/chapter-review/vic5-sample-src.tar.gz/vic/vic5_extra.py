#!/usr/bin/env python3
# SAMPLE ONLY, round 5 (Sohyun 2026-10-10 11:55): '남색, 코랄, 그린 미니멀하게 가자 클라라 캐릭터에만 핑크로 하고 나머지는 저 세 가지 색만';
# '집사는 여우가 더 이쁘고 잘어울려 ... 여우로 가자'. Clara the pawn in pink (the only pink); the fox in the REMEMBER band
# (bow tie coral until she picks one).
#   python3 vic5_extra.py <src after vic_sample, vic2, vic3, vic4 (no --rose)> [bow colour]
import sys, re, json, urllib.parse
sys.path.insert(0, '/home/claude/pbtest/cast')
from cast import piece
from butlers import cameo_svg
src = sys.argv[1]; bow = sys.argv[2] if len(sys.argv) > 2 else '#e4572e'
CLARA, CLARA_D = '#f4a9bb', '#e07c96'
s = open(src, encoding='utf-8').read()
m = re.search(r'VIC_PAWN = ("(?:[^"\\]|\\.)*");', s)
if not m: raise SystemExit('pawn')
s = s[:m.start(1)] + json.dumps(piece('pawn', 'flat', CLARA, CLARA, tiara=True, tiara_col=CLARA_D)) + s[m.end(1):]
m = re.search(r"const VIC_CAMEO = 'data:image/svg\+xml,' \+ \"[^\"]*\";", s)
if not m: raise SystemExit('cameo')
s = s[:m.start()] + "const VIC_CAMEO = 'data:image/svg+xml,' + \"%s\";" % urllib.parse.quote(cameo_svg('fox', pink=bow), safe='') + s[m.end():]
open(src, 'w', encoding='utf-8').write(s); print('vic5 ok')
