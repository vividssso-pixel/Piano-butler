# Victorian cast drawings (original): Staunton-style pieces for the royals, the rabbit butler as a silhouette cameo.
# Every function returns an SVG fragment in its own units; pieces stand on y = 0 with x = 0 at the centre (y up).
import math
NAVY, CORAL, CORAL_L, CREAM, PAPER = '#26296b', '#e4572e', '#f2a48f', '#faf6ec', '#fffdf7'
def f(v): return ('%.2f' % v).rstrip('0').rstrip('.')
def spline(pts):
    """Catmull-Rom through pts -> list of cubic segments (c1, c2, p) starting after pts[0]."""
    out = []
    for i in range(len(pts) - 1):
        p0 = pts[i - 1] if i > 0 else pts[i]; p1 = pts[i]; p2 = pts[i + 1]; p3 = pts[i + 2] if i + 2 < len(pts) else pts[i + 1]
        c1 = (p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6); c2 = (p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6)
        out.append((c1, c2, p2))
    return out
def P(x, y): return f(x) + ' ' + f(-y)
def lathe(right, top=None):
    """right: profile points (x>=0) bottom->top; top: straight points (any x) drawn between the right side and the mirrored left."""
    d = 'M' + P(-right[0][0], 0) + ' L' + P(right[0][0], 0)
    for c1, c2, p in spline(right): d += ' C' + P(*c1) + ' ' + P(*c2) + ' ' + P(*p)
    for x, y in (top or []): d += ' L' + P(x, y)
    left = [(-x, y) for x, y in reversed(right)]
    d += ' L' + P(*left[0])
    for c1, c2, p in spline(left): d += ' C' + P(*c1) + ' ' + P(*c2) + ' ' + P(*p)
    return d + ' Z'
KING = [(22,0),(22.6,1.5),(23,3.5),(22.2,6),(20,7.6),(18.5,8.4),(19.2,10),(18.6,12),(16.5,13.2),(14,14.2),(12,17),(10.3,22),(9,30),(8.2,38),(7.9,46),(8.2,51.6),
        (10.5,53),(13.5,54),(14.3,55.9),(13.5,57.8),(10,58.8),(8.6,59.8),(9.2,62),(11,67),(13.4,72),(15.2,76),(15.7,77.6),(14.8,78.7),(12.4,79.6),(9.6,80.9),(6.4,82),(3.4,82.8),(2.2,83.6)]
KING_TOP = [(1.4,84.4),(1.4,88.6),(5.4,88),(5.4,92.6),(1.4,92),(1.8,97),(-1.8,97),(-1.4,92),(-5.4,92.6),(-5.4,88),(-1.4,88.6),(-1.4,84.4)]
QUEEN = [(21,0),(21.6,1.5),(22,3.4),(21.2,5.8),(19,7.4),(17.6,8.2),(18.2,9.8),(17.6,11.6),(15.6,12.8),(13.2,13.8),(11.2,16.5),(9.6,21),(8.4,28),(7.6,36),(7.3,43),(7.6,47.6),
         (10,49),(13,50),(13.7,51.9),(13,53.8),(9.6,54.8),(8.2,55.8),(8.8,58),(10.8,63),(13.4,68),(15.6,71.6),(16.4,73.6)]
QUEEN_TOP = [(12.6,72.4),(11.6,75.6),(7.4,73.4),(5.6,76.2),(3.6,75),(2.4,77.4),(1.2,78.6),(-1.2,78.6),(-2.4,77.4),(-3.6,75),(-5.6,76.2),(-7.4,73.4),(-11.6,75.6),(-12.6,72.4)]
QUEEN_BALLS = [(16.6,75.2,1.5),(11.6,76.6,1.25),(5.6,77.2,1.15),(-5.6,77.2,1.15),(-11.6,76.6,1.25),(-16.6,75.2,1.5),(0,81.6,3.1)]
PAWN = [(18,0),(18.5,1.4),(18.8,3.2),(18,5.4),(16,6.8),(14.6,7.6),(15.2,9),(14.6,10.6),(12.6,11.6),(10.6,12.6),(9,15),(7.9,19),(7.2,23),(7.2,26),
        (9.6,27),(12,27.8),(12.5,29.2),(11.9,30.6),(8.8,31.4),(6.8,32.6),(6.6,34.4)]
PAWN_BALL = (0, 41.6, 9.4)
RINGS = {'king': [3.5, 12, 55.9, 77.6], 'queen': [3.4, 11.6, 51.9, 72.8], 'pawn': [3.2, 10.6, 29.2]}
def piece_path(kind):
    if kind == 'king': return lathe(KING, KING_TOP)
    if kind == 'queen': return lathe(QUEEN, QUEEN_TOP)
    return lathe(PAWN)
def width_at(kind, y):
    prof = {'king': KING, 'queen': QUEEN, 'pawn': PAWN}[kind]
    for (x0, y0), (x1, y1) in zip(prof, prof[1:]):
        if y0 <= y <= y1: return x0 + (x1 - x0) * (y - y0) / max(1e-6, y1 - y0)
    return 0
UID = [0]
def piece(kind, style='engraved', ink=NAVY, tone=None, tiara=False, tiara_col=None):
    """style: 'silhouette' (filled) or 'engraved' (white, outline, hatching on the shaded side)."""
    UID[0] += 1; cid = 'pc%d' % UID[0]; d = piece_path(kind); tone = tone or ink; out = []
    extra = ''
    if kind == 'queen': extra = ''.join('<circle cx="%s" cy="%s" r="%s"/>' % (f(x), f(-y), f(r)) for x, y, r in QUEEN_BALLS)
    if kind == 'pawn': x, y, r = PAWN_BALL; extra = '<circle cx="%s" cy="%s" r="%s"/>' % (f(x), f(-y), f(r))
    shape = '<path d="%s"/>%s' % (d, extra)
    if style == 'flat':   # for the books at small sizes: no ids, only lines that stay inside the shape
        out.append('<g fill="%s" stroke="%s" stroke-width="0.8" stroke-linejoin="round">%s</g>' % (tone, tone, shape))
        g = []
        for y in RINGS[kind]:
            w = width_at(kind, y) * 0.82
            if w: g.append('<path d="M%s Q%s %s"/>' % (P(-w, y - 0.4), P(0, y - 1.8), P(w, y - 0.4)))
        g.append('<path d="M%s L%s"/>' % (P(-3.6, 18 if kind != 'pawn' else 15), P(-2.8, 46 if kind != 'pawn' else 24)))
        out.append('<g fill="none" stroke="#fff" stroke-opacity="0.55" stroke-width="0.9" stroke-linecap="round">%s</g>' % ''.join(g))
    elif style == 'silhouette':
        out.append('<g fill="%s" stroke="%s" stroke-width="0.8" stroke-linejoin="round">%s</g>' % (tone, tone, shape))
        # a fine gleam down the lit side, as on a turned piece
        out.append('<clipPath id="%s">%s</clipPath>' % (cid, shape))
        g = []
        for y in [r for r in RINGS[kind]]:
            w = width_at(kind, y)
            if w: g.append('<path d="M%s Q%s %s %s"/>' % (P(-w * 0.92, y - 0.6), P(0, y - 2.2), P(w * 0.92, y - 0.6).split(' ')[0], f(-(y - 0.6))))
        out.append('<g clip-path="url(#%s)" fill="none" stroke="#fff" stroke-opacity="0.55" stroke-width="0.6">%s</g>' % (cid, ''.join(g)))
        H = {'king': 97, 'queen': 85, 'pawn': 51}[kind]
        out.append('<g clip-path="url(#%s)"><path d="M%s L%s" stroke="#fff" stroke-opacity="0.4" stroke-width="1.1" fill="none"/></g>' % (cid, P(-4.6, 18), P(-3.2, 50 if kind != 'pawn' else 25)))
    else:
        out.append('<clipPath id="%s">%s</clipPath>' % (cid, shape))
        out.append('<g fill="%s">%s</g>' % (PAPER, shape))
        H = {'king': 98, 'queen': 86, 'pawn': 52}[kind]
        def band(mid, dx):
            return ('<mask id="%s" maskUnits="userSpaceOnUse" x="-40" y="-110" width="80" height="120"><g fill="#fff">%s</g><g fill="#000" transform="translate(%s 0)">%s</g></mask>' % (mid, shape, f(-dx), shape))
        out.append(band(cid + 'a', 11) + band(cid + 'b', 4.6))
        vert = ''.join('<line x1="%s" y1="2" x2="%s" y2="%s"/>' % (f(x * 1.35), f(x * 1.35), f(-H)) for x in range(-2, 20))
        diag = ''.join('<line x1="%s" y1="2" x2="%s" y2="%s"/>' % (f(-30 + i * 1.7), f(-30 + i * 1.7 + 50), f(-H)) for i in range(0, 60))
        out.append('<g mask="url(#%sa)" stroke="%s" stroke-width="0.45" fill="none" opacity="0.8">%s</g>' % (cid, tone, vert))
        out.append('<g mask="url(#%sb)" stroke="%s" stroke-width="0.4" fill="none">%s</g>' % (cid, tone, diag))
        # rings: a short curve across each moulding
        rg = []
        for y in RINGS[kind]:
            w = width_at(kind, y)
            if w: rg.append('<path d="M%s Q%s %s"/>' % (P(-w, y), P(0, y - 2.4), P(w, y)))
        out.append('<g clip-path="url(#%s)" fill="none" stroke="%s" stroke-width="0.6">%s</g>' % (cid, ink, ''.join(rg)))
        out.append('<g fill="none" stroke="%s" stroke-width="1.15" stroke-linejoin="round">%s</g>' % (ink, shape))
    if tiara:
        x0, y0, r = PAWN_BALL; ty = y0 + r - 1.2
        pts = [(-5.4, ty - 0.6), (-4.8, ty + 3.4), (-2.4, ty + 1.6), (0, ty + 5.6), (2.4, ty + 1.6), (4.8, ty + 3.4), (5.4, ty - 0.6)]
        dd = 'M' + ' L'.join(P(*p) for p in pts) + ' Q' + P(0, ty + 1.2) + ' ' + P(-5.4, ty - 0.6) + ' Z'
        out.append('<path d="%s" fill="%s" stroke="%s" stroke-width="0.9" stroke-linejoin="round"/><circle cx="0" cy="%s" r="1.1" fill="%s"/>' % (dd, CORAL_L if style == 'engraved' else (tiara_col or CORAL), CORAL if style == 'engraved' else (tiara_col or CORAL), f(-(ty + 2.6)), CORAL if style == 'engraved' else '#fff'))
    return ''.join(out)

# ── the rabbit butler, a silhouette in an oval cameo (facing left) ──
RABBIT = ('M40 122 C39 114 44 106 52 100 C60 94 70 88 82 85 '
          'C80 62 84 34 93 15 C97 8 104 9 104 18 C104 40 101 64 100 83 '
          'C102 84 104 84 106 83 '
          'C111 62 120 40 129 25 C133 19 140 21 138 29 C133 50 124 74 118 92 '
          'C127 101 130 114 127 126 C124 137 117 145 111 150 '
          'C110 155 111 159 115 162 '
          'C134 168 152 180 160 200 C165 212 166 226 166 240 '
          'L34 240 '
          'C36 216 44 194 56 178 C60 171 64 166 68 161 '
          'C72 157 78 152 84 150 '
          'C76 148 64 142 56 136 C51 133 46 130 44 128 C41 126 40 124 40 122 Z')
def rabbit_details(ground, fig):
    return ('<path d="M88 80 C88 58 91 36 97 20" fill="none" stroke="%s" stroke-width="2.2" stroke-opacity="0.45" stroke-linecap="round"/>'
            '<ellipse cx="80" cy="104" rx="5.4" ry="4.4" fill="%s"/><circle cx="79" cy="104.4" r="2.7" fill="%s"/><circle cx="78" cy="103.2" r="0.9" fill="%s"/>'
            '<path d="M43 125 C46 126 48 128 49 131" fill="none" stroke="%s" stroke-width="1.2" stroke-linecap="round"/>'
            '<path d="M70 162 C78 158 94 158 104 163 L90 214 L84 214 Z" fill="%s"/>'
            '<path d="M76 165 L86 169 L76 174 Z M96 165 L86 169 L96 174 Z" fill="%s"/><circle cx="86" cy="169" r="2.3" fill="%s"/>'
            '<g fill="none" stroke="%s" stroke-width="1.2" stroke-linecap="round"><path d="M67 163 C71 182 77 200 81 220"/><path d="M107 164 C103 184 97 202 93 220"/></g>'
            '<path d="M100 210 C108 214 116 212 124 204" fill="none" stroke="%s" stroke-width="1.2" stroke-dasharray="1.3 2.4" stroke-linecap="round"/><circle cx="125.5" cy="202.5" r="2.4" fill="none" stroke="%s" stroke-width="1.1"/>'
            % (ground, ground, fig, ground, ground, ground, fig, fig, ground, ground, ground))
def whiskers(c):
    return ('<g stroke="%s" stroke-width="0.8" stroke-linecap="round" fill="none">'
            '<path d="M46 124 C36 120 26 117 14 116"/><path d="M46 126 C34 126 24 127 12 129"/><path d="M47 128 C38 132 28 136 18 141"/></g>' % c)
def cameo(dark=False, bow=True):
    UID[0] += 1; cid = 'cm%d' % UID[0]
    ground, fig, line = (NAVY, CREAM, CREAM) if dark else (CREAM, NAVY, NAVY)
    s = ['<clipPath id="%s"><ellipse cx="100" cy="128" rx="80" ry="104"/></clipPath>' % cid]
    s.append('<ellipse cx="100" cy="128" rx="88" ry="112" fill="%s" stroke="%s" stroke-width="1.6"/>' % (PAPER if not dark else NAVY, NAVY))
    s.append('<ellipse cx="100" cy="128" rx="84" ry="108" fill="none" stroke="%s" stroke-width="0.6"/>' % (NAVY if not dark else CREAM))
    s.append('<ellipse cx="100" cy="128" rx="80" ry="104" fill="%s"/>' % ground)
    s.append('<g clip-path="url(#%s)"><g transform="translate(6 22) scale(0.9)"><path d="%s" fill="%s"/>%s%s</g></g>' % (cid, RABBIT, fig, rabbit_details(ground, fig), whiskers(fig)))
    if bow:
        s.append('<g transform="translate(100 12) scale(0.8)" fill="%s" stroke="%s" stroke-width="1" stroke-linejoin="round">'
                 '<path d="M0 0 C-8 -10 -22 -10 -22 -1 C-22 7 -8 6 0 0 Z"/><path d="M0 0 C8 -10 22 -10 22 -1 C22 7 8 6 0 0 Z"/>'
                 '<path d="M-2 1 L-9 16 L-5 15 L-3 18 Z"/><path d="M2 1 L9 16 L5 15 L3 18 Z"/><circle cx="0" cy="0" r="3"/></g>' % (CORAL, NAVY))
    return ''.join(s)
