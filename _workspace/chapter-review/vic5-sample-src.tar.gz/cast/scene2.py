# The music room, round 2: no beige -- white walls with the wainscoting in lines only; a grand piano with its lid up.
import sys; sys.path.insert(0, '/home/claude/pbtest/cast')
from cast import piece, NAVY, CORAL, CORAL_L
from butlers import cameo2, ROSE
def scene(night=False, pink=ROSE, coral=CORAL, coral_l=CORAL_L, ink=NAVY, piano=None, butler='rabbit', bow=None):
    W, H, VPX, VPY, FH = 640, 420, 320, 120, 1200.0
    wall = '#1d2058' if night else '#ffffff'; line = '#6f74b8' if night else ink; fine = '#4a4f98' if night else ink
    tileA, tileB = ('#0d0e2c', '#a9a089') if night else (ink, '#ffffff')
    s = ['<defs><clipPath id="room2"><rect width="%d" height="%d"/></clipPath>' % (W, H)]
    if night:
        s.append('<radialGradient id="glow2" cx="0.5" cy="0.5" r="0.5"><stop offset="0" stop-color="#ffd9a0" stop-opacity="0.6"/><stop offset="1" stop-color="#ffd9a0" stop-opacity="0"/></radialGradient>')
        s.append('<radialGradient id="vig2" cx="0.5" cy="0.48" r="0.72"><stop offset="0.55" stop-color="#05061a" stop-opacity="0"/><stop offset="1" stop-color="#05061a" stop-opacity="0.62"/></radialGradient>')
    s.append('</defs><g clip-path="url(#room2)"><rect width="%d" height="%d" fill="%s"/>' % (W, H, wall))
    # cornice in lines: a thick line, a thin line, dentils, a hairline
    s.append('<rect y="10" width="%d" height="2.4" fill="%s"/><rect y="15" width="%d" height="0.9" fill="%s"/>' % (W, line, W, line))
    s.append(''.join('<rect x="%d" y="19" width="5" height="6" fill="%s"/>' % (x, line) for x in range(2, W, 10)))
    s.append('<rect y="27" width="%d" height="0.8" fill="%s"/>' % (W, line))
    # chair rail and panels, lines only
    s.append('<rect y="176" width="%d" height="2.2" fill="%s"/><rect y="180.4" width="%d" height="0.8" fill="%s"/><rect y="184" width="%d" height="0.6" fill="%s"/>' % (W, line, W, line, W, line))
    for x in range(8, W, 80):
        s.append('<rect x="%d" y="194" width="66" height="62" fill="none" stroke="%s" stroke-width="1.1"/><rect x="%d" y="199" width="56" height="52" fill="none" stroke="%s" stroke-width="0.5"/>' % (x, line, x + 5, fine))
    s.append('<rect y="262" width="%d" height="1.2" fill="%s"/><rect y="266" width="%d" height="2.6" fill="%s"/>' % (W, line, W, line))
    # the chequered floor
    ys = lambda z: VPY + FH / z
    zs = [8, 7, 6, 5, 4, 3.4]
    for r in range(len(zs) - 1):
        for i in range(-14, 14):
            a0, a1 = 320.0 / zs[r], 320.0 / zs[r + 1]
            q = [(VPX + i * a0, ys(zs[r])), (VPX + (i + 1) * a0, ys(zs[r])), (VPX + (i + 1) * a1, ys(zs[r + 1])), (VPX + i * a1, ys(zs[r + 1]))]
            s.append('<path d="M%s Z" fill="%s"/>' % (' L'.join('%.1f %.1f' % p for p in q), tileA if (i + r) % 2 else tileB))
    if not night: s.append('<rect y="269" width="%d" height="1" fill="%s"/>' % (W, ink))
    # wall sconces either side of the cameo, the cameo between
    for cx in (372, 560):
        if night: s.append('<circle cx="%d" cy="92" r="46" fill="url(#glow2)"/>' % cx)
        s.append('<path d="M%d 124 Q%d 120 %d 110" fill="none" stroke="#4a4f98" stroke-width="2"/><rect x="%d" y="106" width="10" height="3" rx="1" fill="#4a4f98"/><rect x="%d" y="90" width="4" height="16" fill="#fffdf7" stroke="%s" stroke-width="0.5"/><path d="M%d 89 Q%.1f 83 %d 78 Q%.1f 83 %d 89 Z" fill="%s"/>' % (cx, cx - 6, cx - 6, cx - 11, cx - 8, ink, cx - 6, cx - 8.6, cx - 6, cx - 3.4, cx - 6, CORAL))
    s.append('<g transform="translate(422 34) scale(0.47)">%s</g>' % cameo2(butler, dark=night, pink=bow or pink, ink=ink))
    # the grand piano, side view (keyboard at the left, the lid raised on its stick)
    pb, pl = ('#0b0c2a', '#3a3e8a') if night else (ink, '#ffffff')
    P = []
    P.append('<path d="M70 300 L76 300 L78 226 L66 226 Z" fill="%s"/><path d="M254 304 L260 304 L264 226 L250 226 Z" fill="%s"/>' % (pb, pb))   # legs
    P.append('<ellipse cx="73" cy="301" rx="6" ry="2.4" fill="%s"/><ellipse cx="257" cy="305" rx="6" ry="2.4" fill="%s"/>' % (pb, pb))
    P.append('<path d="M112 228 C106 250 108 272 114 290 M128 228 C134 250 132 272 126 290" fill="none" stroke="%s" stroke-width="3"/><rect x="108" y="288" width="24" height="5" rx="2" fill="%s"/><g fill="#4a4f98"><rect x="110" y="293" width="5" height="3" rx="1"/><rect x="117.5" y="293" width="5" height="3" rx="1"/><rect x="125" y="293" width="5" height="3" rx="1"/></g>' % (pb, pb))
    P.append('<path d="M52 198 L250 198 C286 198 300 206 300 212 C300 220 286 228 250 228 L52 228 Z" fill="%s"/>' % pb)              # case
    P.append('<path d="M56 205 L246 205 C276 205 290 209 292 213" fill="none" stroke="%s" stroke-width="0.9" stroke-opacity="0.6"/>' % pl)   # rim moulding
    P.append('<rect x="30" y="200" width="24" height="12" fill="%s"/><rect x="30" y="200" width="24" height="5" fill="%s"/><path d="M30 200 L54 200" stroke="%s" stroke-width="1"/>' % (pb, '#fbf7ea' if not night else '#e9e1cc', pb))   # keys, end on
    P.append('<path d="M84 198 L92 170 L124 168 L122 198 Z" fill="%s"/><rect x="94" y="174" width="26" height="20" fill="#fffdf7" transform="rotate(-3 107 184)"/>' % pb)   # music desk + music
    P.append(''.join('<line x1="99" x2="123" y1="%.1f" y2="%.1f" stroke="%s" stroke-width="0.4" transform="rotate(-3 111 186)"/>' % (180 + k * 2.5, 180 + k * 2.5, ink) for k in range(6)).replace('x1="99" x2="123"', 'x1="97" x2="117"'))
    P.append('<path d="M126 198 L130 112 C186 124 250 160 300 198 Z" fill="%s"/>' % pb)   # the lid, raised
    P.append('<path d="M131 118 C186 130 246 164 292 198" fill="none" stroke="%s" stroke-width="0.9" stroke-opacity="0.55"/>' % pl)
    P.append('<path d="M152 198 L150 132" stroke="%s" stroke-width="1.6" stroke-opacity="0.75"/>' % pl)   # the stick
    s.append(piano if piano is not None else ''.join(P))
    def stand(kind, x, z, tone, tiara=False):
        y = ys(z); k = (320.0 / z) / 44.0 * 0.95
        return ('<ellipse cx="%.1f" cy="%.1f" rx="%.1f" ry="%.1f" fill="#000" opacity="%s"/>' % (x + 4, y + 1, 26 * k * 1.15, 5 * k, 0.35 if night else 0.16)
                + '<g transform="translate(%.1f %.1f) scale(%.3f)">%s</g>' % (x, y, k, piece(kind, 'flat', tone, tone, tiara=tiara, tiara_col='#e07c96')))
    kt = '#e9e1cc' if night else ink
    s.append(stand('king', 386, 5.6, kt)); s.append(stand('pawn', 470, 5.25, coral_l, True)); s.append(stand('queen', 556, 5.6, coral))
    if night: s.append('<rect width="%d" height="%d" fill="url(#vig2)"/>' % (W, H))
    s.append('</g>')
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d">%s</svg>' % (W, H, ''.join(s))
if __name__ == '__main__':
    open('scene2-day.svg', 'w').write(scene(False)); open('scene2-night.svg', 'w').write(scene(True))
    open('scene2.html', 'w').write('<html><body style="margin:10px;display:flex;flex-direction:column;gap:12px"><img src="scene2-day.svg" width="900"><img src="scene2-night.svg" width="900"></body></html>')
