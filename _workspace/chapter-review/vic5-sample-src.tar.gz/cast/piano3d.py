# Pianos drawn in the room's own perspective (camera: eye 3.75 units above the floor, vanishing point 320,120).
import math
NAVY = '#26296b'
SHADE = {'top': '#3d4190', 'front': '#26296b', 'side': '#1c1f55', 'dark': '#14163f', 'in': '#323680'}
def proj(p):
    X, Y, Z = p
    return (320 + X * 320.0 / Z, 120 + (3.75 - Y) * 320.0 / Z)
def dist(p): return math.sqrt(p[0] ** 2 + (p[1] - 3.75) ** 2 + p[2] ** 2)
def pts(ps): return ' '.join('%.1f,%.1f' % proj(p) for p in ps)
def area(ps):
    q = [proj(p) for p in ps]; return sum(q[i][0] * q[(i + 1) % len(q)][1] - q[(i + 1) % len(q)][0] * q[i][1] for i in range(len(q))) / 2
class Model:
    def __init__(s, ox, oz, theta):
        s.ox, s.oz, s.c, s.s = ox, oz, math.cos(math.radians(theta)), math.sin(math.radians(theta)); s.items = []
    def w(s, u, y, v):   # local (u along the keys, y up, v away from the keys) -> world
        return (s.ox + u * s.c - v * s.s, y, s.oz + u * s.s + v * s.c)
    def poly(s, local, fill, stroke=None, sw=0.6, cull=True, layer=0, depth=None, extra=''):
        P = [s.w(*p) for p in local]
        if cull and area(P) <= 0: return False
        d = depth if depth is not None else sum(dist(p) for p in P) / len(P)
        s.items.append((layer, -d, '<polygon points="%s" fill="%s"%s%s/>' % (pts(P), fill, (' stroke="%s" stroke-width="%s" stroke-linejoin="round"' % (stroke, sw)) if stroke else '', extra)))
        return True
    def line(s, a, b, col, sw=0.6, layer=0, op=1, depth=None):
        A, B = s.w(*a), s.w(*b); d = depth if depth is not None else (dist(A) + dist(B)) / 2
        (x1, y1), (x2, y2) = proj(A), proj(B)
        s.items.append((layer, -d, '<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="%s" stroke-width="%s" stroke-opacity="%s" stroke-linecap="round"/>' % (x1, y1, x2, y2, col, sw, op)))
    def raw(s, svg, layer=0, depth=0): s.items.append((layer, -depth, svg))
    def box(s, u0, u1, y0, y1, v0, v1, fills=None, stroke='#353a86', sw=0.5, layer=0):
        f = fills or {}
        F = {'top': [(u0, y1, v0), (u1, y1, v0), (u1, y1, v1), (u0, y1, v1)],
             'bottom': [(u0, y0, v0), (u0, y0, v1), (u1, y0, v1), (u1, y0, v0)],
             'front': [(u0, y0, v0), (u1, y0, v0), (u1, y1, v0), (u0, y1, v0)],
             'back': [(u0, y0, v1), (u0, y1, v1), (u1, y1, v1), (u1, y0, v1)],
             'left': [(u0, y0, v0), (u0, y1, v0), (u0, y1, v1), (u0, y0, v1)],
             'right': [(u1, y0, v0), (u1, y0, v1), (u1, y1, v1), (u1, y1, v0)]}
        for k, q in F.items():
            s.poly(q, f.get(k, SHADE['top'] if k == 'top' else SHADE['front'] if k in ('front', 'back') else SHADE['side']), stroke, sw, layer=layer)
    def svg(s):
        return ''.join(x[2] for x in sorted(s.items, key=lambda t: (t[0], t[1])))
def keys(m, u0, u1, y, v0, v1, n=36, layer=2):
    """white key surface with lines and black keys, lying flat at height y between v0 (front) and v1 (back)"""
    m.poly([(u0, y, v0), (u1, y, v0), (u1, y, v1), (u0, y, v1)], '#fbf8ef', NAVY, 0.5, cull=False, layer=layer)
    kw = (u1 - u0) / n; pat = [1, 1, 0, 1, 1, 1, 0]
    for k in range(1, n): m.line((u0 + k * kw, y + 0.002, v0), (u0 + k * kw, y + 0.002, v1), NAVY, 0.35, layer=layer, op=0.7)
    for k in range(n - 1):
        if pat[(k + 5) % 7]:
            c = u0 + (k + 1) * kw; a, b = c - kw * 0.3, c + kw * 0.3; vb = v0 + (v1 - v0) * 0.42
            m.poly([(a, y + 0.03, vb), (b, y + 0.03, vb), (b, y + 0.03, v1), (a, y + 0.03, v1)], NAVY, cull=False, layer=layer)
    m.poly([(u0, y - 0.07, v0), (u1, y - 0.07, v0), (u1, y, v0), (u0, y, v0)], SHADE['front'], cull=False, layer=layer)   # key fronts
def lathe_leg(m, u, v, y0, y1, wdt, col=SHADE['dark'], layer=0):
    """a turned leg: a vase profile drawn upright at its projected place"""
    A, B = m.w(u, y0, v), m.w(u, y1, v); (xa, ya), (xb, yb) = proj(A), proj(B); h = ya - yb; k = 320.0 / A[2] * wdt
    prof = [(0.5, 0), (0.42, 0.06), (0.30, 0.14), (0.40, 0.42), (0.50, 0.62), (0.40, 0.80), (0.30, 0.86), (0.46, 0.92), (0.50, 1.0)]
    R = ['%.1f,%.1f' % (xa + p * k, ya - t * h) for p, t in prof]; L = ['%.1f,%.1f' % (xa - p * k, ya - t * h) for p, t in reversed(prof)]
    m.raw('<polygon points="%s" fill="%s"/><ellipse cx="%.1f" cy="%.1f" rx="%.1f" ry="%.1f" fill="#4a4f98"/>' % (' '.join(R + L), col, xa, ya, k * 0.32, k * 0.14), layer, dist(A))

# ── 1. a Victorian upright, front view (the one you liked), drawn in the room's perspective ──
def upright(ox, oz, theta, ornate=True):
    m = Model(ox, oz, theta); W, D, H = 2.3, 0.9, 1.95
    m.box(0, W, 0.08, H, 0, D)                                                     # case
    m.box(-0.06, W + 0.06, H, H + 0.07, -0.06, D + 0.04, {'top': SHADE['top']})       # lid slab
    m.box(0, W, 0, 0.08, -0.03, D, {'front': SHADE['dark']})                        # plinth
    m.box(0.12, W - 0.12, 0.95, 1.02, -0.42, 0, {'top': SHADE['top']}, layer=1)      # key bed
    keys(m, 0.14, W - 0.14, 1.06, -0.4, -0.02)
    for u in (0, W - 0.12):
        m.box(u, u + 0.12, 0.88, 1.16, -0.46, 0, layer=3)                             # cheek blocks
    # front panels (lines), music shelf and sheet
    for (a, b, c, d) in ((0.22, W - 0.22, 1.24, H - 0.12), (0.2, W / 2 - 0.06, 0.2, 0.86), (W / 2 + 0.06, W - 0.2, 0.2, 0.86)):
        m.poly([(a, c, -0.005), (b, c, -0.005), (b, d, -0.005), (a, d, -0.005)], 'none', '#5a5fa6', 0.8, cull=False, layer=1)
    m.poly([(0.75, 1.3, -0.01), (W - 0.75, 1.3, -0.01), (W - 0.75, 1.72, -0.01), (0.75, 1.72, -0.01)], '#fffdf7', NAVY, 0.5, cull=False, layer=1)
    for k in range(6): m.line((0.82, 1.42 + k * 0.04, -0.012), (W - 0.82, 1.42 + k * 0.04, -0.012), NAVY, 0.35, layer=1)
    if ornate:   # turned trusses under the cheeks, and candle sconces
        for u in (0.06, W - 0.06): lathe_leg(m, u, -0.38, 0.08, 0.9, 0.16, SHADE['side'], layer=0)
        for u in (-0.02, W + 0.02):
            A = m.w(u, 1.62, -0.02); x, y = proj(A); k = 320.0 / A[2] / 60
            m.raw('<path d="M%.1f %.1f q%.1f %.1f %.1f %.1f" fill="none" stroke="#4a4f98" stroke-width="%.1f"/><rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" fill="#fffdf7" stroke="%s" stroke-width="0.4"/><path d="M%.1f %.1f q%.1f %.1f 0 %.1f q%.1f %.1f 0 %.1f z" fill="#e4572e"/>' % (
                x, y, (-8 if u < 1 else 8) * k, -6 * k, (-8 if u < 1 else 8) * k, -18 * k, 2 * k, x + (-8 if u < 1 else 8) * k - 2.2 * k, y - 34 * k, 4.4 * k, 16 * k, NAVY,
                x + (-8 if u < 1 else 8) * k, y - 35 * k, -2.6 * k, -4 * k, -7 * k, 2.6 * k, 3 * k, 7 * k), 4, 0)
    for u in (W / 2 - 0.12, W / 2, W / 2 + 0.12):
        m.box(u - 0.03, u + 0.03, 0.1, 0.13, -0.18, 0, {'top': '#4a4f98', 'front': '#3a3d85', 'left': '#3a3d85', 'right': '#3a3d85'}, None, layer=1)
    return m.svg()

# ── 3. a grand piano, three-quarter view, lid up ──
def grand_outline(W, L, n=48):
    pts = [(0, 0), (W, 0), (W, 0.24 * L)]
    def bez(p0, p1, p2, p3, k):
        out = []
        for i in range(1, k + 1):
            t = i / k; a = (1 - t) ** 3; b = 3 * (1 - t) ** 2 * t; c = 3 * (1 - t) * t * t; d = t ** 3
            out.append((a * p0[0] + b * p1[0] + c * p2[0] + d * p3[0], a * p0[1] + b * p1[1] + c * p2[1] + d * p3[1]))
        return out
    pts += bez((W, 0.24 * L), (W, 0.52 * L), (0.42 * W, 0.50 * L), (0.36 * W, 0.80 * L), 18)   # the bentside
    pts += bez((0.36 * W, 0.80 * L), (0.32 * W, 0.98 * L), (0.10 * W, 1.0 * L), (0, 0.97 * L), 10)  # the tail
    return pts
def grand(ox, oz, theta, lid=38):
    m = Model(ox, oz, theta); W, L, yb, yt = 2.3, 3.6, 0.98, 1.48
    O = grand_outline(W, L)
    # legs and the pedal lyre first (the case hides their tops)
    for (u, v) in ((0.12, 0.25), (W - 0.14, 0.22), (0.5, 0.86 * L)): lathe_leg(m, u, v, 0, yb, 0.17, SHADE['dark'], layer=0)
    A, B = m.w(W / 2 - 0.12, 0.06, 0.14), m.w(W / 2 + 0.12, 0.06, 0.14)
    lyre = m.w(W / 2, yb, 0.14); (x1, y1), (x2, y2), (xc, yc) = proj(A), proj(B), proj(lyre)
    m.raw('<path d="M%.1f %.1f C%.1f %.1f %.1f %.1f %.1f %.1f M%.1f %.1f C%.1f %.1f %.1f %.1f %.1f %.1f" fill="none" stroke="%s" stroke-width="2.6"/><rect x="%.1f" y="%.1f" width="%.1f" height="5" rx="2" fill="%s"/>' % (
        x1, y1, x1 - 6, (y1 + yc) / 2, xc - 4, yc + 10, xc - 3, yc, x2, y2, x2 + 6, (y2 + yc) / 2, xc + 4, yc + 10, xc + 3, yc, SHADE['dark'], x1 - 4, y1 - 2, x2 - x1 + 8, SHADE['dark']), 0, dist(A))
    # the rim: outer faces that face us, inner faces of the far side, the soundboard and plate inside
    n = len(O)
    for i in range(n):
        (u0, v0), (u1, v1) = O[i], O[(i + 1) % n]
        q = [(u0, yb, v0), (u1, yb, v1), (u1, yt, v1), (u0, yt, v0)]
        if not m.poly(q, SHADE['front'] if i == 0 else SHADE['side'], None, layer=2):
            m.poly(list(reversed(q)), SHADE['dark'], None, cull=False, layer=1)
    inner = [(u * 0.96 + 0.04, yt - 0.16, v * 0.97 + 0.05) for u, v in O]
    m.poly(inner, '#3a3e85', None, cull=False, layer=1, depth=1e3)
    for k in range(1, 26):   # strings
        t = k / 26.0
        m.line((0.12 + t * (W - 0.3), yt - 0.15, 0.32), (0.08 + t * 0.32 * W, yt - 0.15, 0.32 + (0.62 + 0.3 * (1 - t)) * L * (0.55 + 0.45 * (1 - t))), '#c9c7e8', 0.35, layer=1, op=0.7, depth=900)
    m.poly([(u, yt, v) for u, v in O], 'none', '#5a5fa6', 0.7, cull=False, layer=2, depth=0)   # rim top edge
    for i in range(2, 22): m.line((O[i][0], yt - 0.12, O[i][1]), (O[i + 1][0], yt - 0.12, O[i + 1][1]), '#ffffff', 0.9, layer=2, op=0.25, depth=0)
    # the lid, raised on its stick (hinged along the straight, far side; the front flap stays down)
    a = math.radians(lid); lidpts = [(u * math.cos(a), yt + u * math.sin(a), v) for u, v in O if v >= 0.26 * L]
    lidpts = [(0, yt, 0.26 * L)] + lidpts
    edge = [(u * math.cos(a) - 0.05 * math.sin(a), y + 0.05 * math.cos(a), v) for u, y, v in lidpts]
    m.poly(edge, SHADE['dark'], None, cull=False, layer=3)
    m.poly(lidpts, '#33378a', '#5a5fa6', 0.7, cull=False, layer=3)
    gl = [(u * math.cos(a), yt + u * math.sin(a), v) for u, v in O if 0.34 * L <= v <= 0.8 * L]
    for f_ in (0.55, 0.62):
        m.line((gl[0][0] * f_, yt + (gl[0][1] - yt) * f_, 0.36 * L), (gl[-1][0] * f_, yt + (gl[-1][1] - yt) * f_, 0.78 * L), '#ffffff', 1.2, layer=3, op=0.18, depth=0)
    m.line((W * 0.97, yt, 0.27 * L), (W * 0.97 * math.cos(a), yt + W * 0.97 * math.sin(a) - 0.03, 0.27 * L), '#c9c7e8', 1.6, layer=3, op=0.9, depth=0)
    # key bed, keys, cheeks, music desk
    m.box(0.1, W - 0.1, yb - 0.02, yb + 0.06, -0.42, 0, {'top': SHADE['top']}, layer=4)
    keys(m, 0.12, W - 0.12, yb + 0.1, -0.4, -0.02, n=40, layer=5)
    for u in (0, W - 0.1): m.box(u, u + 0.1, yb - 0.04, yb + 0.22, -0.46, 0, layer=6)
    m.box(0.1, W - 0.1, yb + 0.06, yt, -0.02, 0.08, layer=4)   # key slip / fallboard back
    desk = [(0.55, yt, 0.12), (W - 0.55, yt, 0.12), (W - 0.55, yt + 0.36, 0.26), (0.55, yt + 0.36, 0.26)]
    m.poly(desk, SHADE['front'], '#5a5fa6', 0.5, cull=False, layer=6)
    m.poly([(0.75, yt + 0.06, 0.15), (W - 0.75, yt + 0.06, 0.15), (W - 0.75, yt + 0.32, 0.245), (0.75, yt + 0.32, 0.245)], '#fffdf7', NAVY, 0.4, cull=False, layer=6)
    return m.svg()

# ── 4. a square piano: a long table with the keys on the left of the long side ──
def square(ox, oz, theta):
    m = Model(ox, oz, theta); W, D, yb, yt = 3.0, 1.15, 0.95, 1.45
    for (u, v) in ((0.12, 0.1), (W - 0.12, 0.1), (0.12, D - 0.1), (W - 0.12, D - 0.1)): lathe_leg(m, u, v, 0, yb, 0.24, SHADE['dark'], layer=0)
    m.box(0, W, yb, yt, 0, D, {'top': SHADE['top']}, layer=2)
    m.box(-0.04, W + 0.04, yt, yt + 0.06, -0.04, D + 0.04, {'top': '#3d4190'}, layer=3)
    m.box(-0.03, W + 0.03, yb - 0.08, yb, -0.03, D + 0.03, {'front': SHADE['dark']}, layer=2)
    # the keyboard well in the front, left of centre (flap open)
    m.poly([(0.2, yb + 0.06, -0.003), (1.75, yb + 0.06, -0.003), (1.75, yt - 0.06, -0.003), (0.2, yt - 0.06, -0.003)], SHADE['dark'], None, cull=False, layer=3)
    keys(m, 0.24, 1.71, yb + 0.16, -0.22, 0.12, n=30, layer=4)
    m.poly([(2.0, yb + 0.1, -0.004), (W - 0.2, yb + 0.1, -0.004), (W - 0.2, yt - 0.1, -0.004), (2.0, yt - 0.1, -0.004)], 'none', '#5a5fa6', 0.7, cull=False, layer=3)
    m.poly([(0.6, yt + 0.06, 0.25), (1.5, yt + 0.06, 0.25), (1.5, yt + 0.38, 0.38), (0.6, yt + 0.38, 0.38)], SHADE['front'], '#5a5fa6', 0.5, cull=False, layer=5)
    m.poly([(0.7, yt + 0.1, 0.27), (1.4, yt + 0.1, 0.27), (1.4, yt + 0.34, 0.365), (0.7, yt + 0.34, 0.365)], '#fffdf7', NAVY, 0.4, cull=False, layer=5)
    return m.svg()

# ── 2. a tall Victorian cabinet upright: a pediment, fretwork over coral silk, swing-arm candles, carved trusses ──
def cabinet(ox, oz, theta, silk='#e4572e'):
    m = Model(ox, oz, theta); W, D, H = 2.4, 0.85, 2.45
    for u in (0.07, W - 0.07): lathe_leg(m, u, -0.4, 0.08, 0.93, 0.2, SHADE['side'], layer=0)    # carved trusses
    m.box(0, W, 0.08, H, 0, D)
    m.box(-0.07, W + 0.07, H, H + 0.08, -0.07, D + 0.04, {'top': SHADE['top']}, layer=1)
    m.box(0, W, 0, 0.08, -0.03, D, {'front': SHADE['dark']})
    # pediment (front plane, above the lid)
    v = -0.07
    ped = [(0.25, H + 0.08, v), (W - 0.25, H + 0.08, v), (W - 0.25, H + 0.2, v), (W / 2 + 0.34, H + 0.2, v), (W / 2, H + 0.42, v), (W / 2 - 0.34, H + 0.2, v), (0.25, H + 0.2, v)]
    m.poly(ped, SHADE['front'], '#5a5fa6', 0.6, cull=False, layer=2)
    m.poly([(W / 2 - 0.08, H + 0.18, v - 0.001), (W / 2 + 0.08, H + 0.18, v - 0.001), (W / 2 + 0.08, H + 0.3, v - 0.001), (W / 2 - 0.08, H + 0.3, v - 0.001)], '#4a4f98', None, cull=False, layer=2)
    # upper front: fretwork lattice over silk
    a, b, c, d = 0.28, W - 0.28, 1.42, H - 0.16
    m.poly([(a, c, -0.004), (b, c, -0.004), (b, d, -0.004), (a, d, -0.004)], silk, '#5a5fa6', 0.8, cull=False, layer=2, depth=1)
    step = 0.16; k = -12
    while k < 30:
        x0 = a + k * step
        for sgn in (1, -1):   # diagonal lattice, clipped to the panel by sampling
            pts_ = []
            for t in range(0, 41):
                yy = c + (d - c) * t / 40.0; xx = x0 + sgn * (yy - c)
                if a <= xx <= b: pts_.append((xx, yy))
            if len(pts_) > 1: m.line((pts_[0][0], pts_[0][1], -0.006), (pts_[-1][0], pts_[-1][1], -0.006), SHADE['front'], 2.2, layer=2, depth=0)
        k += 1
    m.poly([(a, c, -0.008), (b, c, -0.008), (b, d, -0.008), (a, d, -0.008)], 'none', SHADE['front'], 3, cull=False, layer=2, depth=0)
    # music shelf and the music
    m.box(0.5, W - 0.5, 1.3, 1.36, -0.12, 0, {'top': SHADE['top']}, layer=2)
    m.poly([(0.85, 1.36, -0.06), (W - 0.85, 1.36, -0.06), (W - 0.85, 1.8, -0.02), (0.85, 1.8, -0.02)], '#fffdf7', NAVY, 0.5, cull=False, layer=3)
    for kk in range(6): m.line((0.92, 1.48 + kk * 0.045, -0.045), (W - 0.92, 1.48 + kk * 0.045, -0.045), NAVY, 0.35, layer=3)
    # key bed, keys, cheeks
    m.box(0.12, W - 0.12, 0.95, 1.02, -0.42, 0, {'top': SHADE['top']}, layer=1)
    keys(m, 0.14, W - 0.14, 1.06, -0.4, -0.02, n=40)
    for u in (0, W - 0.12): m.box(u, u + 0.12, 0.88, 1.18, -0.46, 0, layer=3)
    m.box(0.12, W - 0.12, 1.1, 1.3, -0.02, 0, layer=1)   # fallboard
    # lower panels and pedals
    for (p, q) in ((0.22, W / 2 - 0.06), (W / 2 + 0.06, W - 0.22)):
        m.poly([(p, 0.2, -0.004), (q, 0.2, -0.004), (q, 0.84, -0.004), (p, 0.84, -0.004)], 'none', '#5a5fa6', 0.8, cull=False, layer=1)
        m.poly([(p + 0.08, 0.28, -0.005), (q - 0.08, 0.28, -0.005), (q - 0.08, 0.76, -0.005), (p + 0.08, 0.76, -0.005)], 'none', '#5a5fa6', 0.5, cull=False, layer=1)
    for u in (W / 2 - 0.12, W / 2 + 0.12):
        m.box(u - 0.03, u + 0.03, 0.1, 0.13, -0.18, 0, {'top': '#4a4f98', 'front': '#3a3d85', 'left': '#3a3d85', 'right': '#3a3d85'}, None, layer=1)
    # swing-arm candle sconces on the upper front corners
    for u, sg in ((0.12, -1), (W - 0.12, 1)):
        A = m.w(u, 1.95, -0.02); B = m.w(u + sg * 0.18, 1.85, -0.3); (x1, y1), (x2, y2) = proj(A), proj(B); kk = 320.0 / B[2] / 60
        m.raw('<path d="M%.1f %.1f Q%.1f %.1f %.1f %.1f" fill="none" stroke="#4a4f98" stroke-width="%.1f"/><rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" rx="1" fill="#4a4f98"/><rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" fill="#fffdf7" stroke="%s" stroke-width="0.4"/><path d="M%.1f %.1f q%.1f %.1f 0 %.1f q%.1f %.1f 0 %.1f z" fill="#e4572e"/>' % (
            x1, y1, (x1 + x2) / 2, y1 + 6 * kk, x2, y2, 2.2 * kk, x2 - 5 * kk, y2 - 1.5 * kk, 10 * kk, 3 * kk, x2 - 2.2 * kk, y2 - 17 * kk, 4.4 * kk, 16 * kk, NAVY,
            x2, y2 - 18 * kk, -2.6 * kk, -4 * kk, -7 * kk, 2.6 * kk, 3 * kk, 7 * kk), 5, 0)
    return m.svg()
