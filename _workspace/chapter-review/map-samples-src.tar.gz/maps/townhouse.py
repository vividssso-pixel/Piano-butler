# Map sample A: one tall Victorian townhouse, cut open like a doll's house -- a floor for each stage, a room for each chapter.
from common import *
W = 360; X0, X1 = 22, 338; SC = 40; RX0 = X0 + SC; RH = 78; LH = 24; SLAB = 12
def cols(n): return n if n <= 3 else (2 if n == 4 else 3)
def floor_h(n): return LH + RH * ((n + cols(n) - 1) // cols(n))
def dentils(y, x0=X0, x1=X1, h=3.5):
    return ''.join('<rect x="%d" y="%.1f" width="3" height="%s" fill="%s"/>' % (x, y, h, NAVY) for x in range(int(x0) + 2, int(x1) - 2, 6))
def cornice(y):   # the slab between floors: a thick line, a thin line, dentils
    return ('<rect x="%d" y="%.1f" width="%d" height="2.6" fill="%s"/><rect x="%d" y="%.1f" width="%d" height="0.8" fill="%s"/>' % (X0 - 4, y, X1 - X0 + 8, NAVY, X0 - 2, y + 4.4, X1 - X0 + 4, NAVY)
            + dentils(y + 6.8) + '<rect x="%d" y="%.1f" width="%d" height="0.6" fill="%s"/>' % (X0, y + 11.2, X1 - X0, NAVY))
def stairs(x, y, w, h, up_right=True):
    """a stair rising across the column: the steps as a solid stepped shape, a handrail with balusters"""
    n = 7; sw, sh = (w - 6) / n, (h - 6) / n; pts = [(x + 3, y + h)]
    for k in range(n): pts += [(x + 3 + k * sw, y + h - (k + 1) * sh), (x + 3 + (k + 1) * sw, y + h - (k + 1) * sh)]
    pts += [(x + 3 + n * sw, y + h)]
    poly = '<path d="M%s Z" fill="#e8e9f2" stroke="%s" stroke-width="1"/>' % (' L'.join('%.1f %.1f' % q for q in pts), NAVY)
    tops = [(x + 3 + (k + 0.5) * sw, y + h - (k + 1) * sh) for k in range(n)]
    rail = ' L'.join('%.1f %.1f' % (px, py - 14) for px, py in tops)
    bal = ''.join('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="%s" stroke-width="0.7"/>' % (px, py, px, py - 14, NAVY) for px, py in tops)
    return poly + bal + '<path d="M%s" fill="none" stroke="%s" stroke-width="1.6"/>' % (rail, NAVY)
def room(i, x, y, w, h):
    st, on = STATE[i], i == HERE; n = NUM[i]; s = []
    s.append('<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" fill="#ffffff" stroke="%s" stroke-width="%s"/>' % (x, y, w, h, CORAL if on else NAVY, 2.4 if on else 1))
    # wainscot inside: a chair rail and two panels, in fine lines
    cy = y + h * 0.66
    s.append('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="%s" stroke-width="0.9" opacity="0.35"/><line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="%s" stroke-width="0.5" opacity="0.35"/>' % (x + 2, cy, x + w - 2, cy, NAVY, x + 2, cy + 2.4, x + w - 2, cy + 2.4, NAVY))
    pw = (w - 18) / 2
    for k in range(2): s.append('<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" fill="none" stroke="%s" stroke-width="0.6" opacity="0.22"/>' % (x + 6 + k * (pw + 6), cy + 6, pw, h - (cy - y) - 10, NAVY))
    # number on a chess square (green when done), the name, the icon
    sq = 17; sx, sy = x + 6, y + 6
    s.append(square(sx, sy, sq, n + 1, str(n), fill=GREEN if st == 'done' else None, size=11))
    lines = wrap(('✓ ' if st == 'done' else '') + name(i), int((w - sq - 16) / 6.3))
    for k, ln in enumerate(lines[:2]): s.append(T(sx + sq + 5, sy + 12 + k * 13, ln, 11.5, 800 if on or st == 'done' else 600, CORAL if on else (NAVY if st == 'done' else NEW)))
    s.append(icon(i, x + w / 2 - 17, y + h * 0.66 - 27, 0.7, 1 if st != 'new' or on else 0.5))
    if on: s.append(pawn(x + w - 16, y + h - 3, 0.5))
    return ''.join(s)
def townhouse():
    floors = list(reversed(list(enumerate(STAGES))))
    top = 150; y = top; body = []; heights = []
    for (fi, st) in floors:
        n = len(st['ids']); fh = floor_h(n)
        body.append(cornice(y)); yy = y + SLAB
        # the floor's plaque
        lab = '%d · %s' % (fi + 1, st['en'])
        body.append('<rect x="%.1f" y="%.1f" width="%d" height="17" fill="#fff" stroke="%s" stroke-width="0.9"/>' % (RX0 + 6, yy + 3.5, len(lab) * 6.3 + 18, NAVY))
        body.append(T(RX0 + 15, yy + 15.8, lab, 11.5, 700, NAVY, serif=True, italic=True))
        # the staircase (alternating sides like the floors of a real house)
        body.append(stairs(X0, yy, SC, fh, True))
        c = cols(n)
        for j, i in enumerate(st['ids']):
            r, cc = divmod(j, c); inrow = min(c, n - r * c); rw = (X1 - RX0) / inrow
            body.append(room(i, RX0 + cc * rw, yy + LH + r * RH, rw, RH))
        y = yy + fh
    # the ground floor: the entrance hall
    body.append(cornice(y)); gy = y + SLAB; GH = 112
    body.append('<rect x="%d" y="%.1f" width="%d" height="%d" fill="#fff" stroke="%s" stroke-width="1"/>' % (X0, gy, X1 - X0, GH, NAVY))
    dx = (X0 + X1) / 2
    body.append('<path d="M%.1f %.1f L%.1f %.1f A28 28 0 0 1 %.1f %.1f L%.1f %.1f" fill="#fff" stroke="%s" stroke-width="1.6"/>' % (dx - 28, gy + GH, dx - 28, gy + 46, dx + 28, gy + 46, dx + 28, gy + GH, NAVY))
    body.append('<path d="M%.1f %.1f A20 20 0 0 1 %.1f %.1f Z" fill="%s"/>' % (dx - 20, gy + 46, dx + 20, gy + 46, NAVY))   # fanlight
    body.append(''.join('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="#fff" stroke-width="1"/>' % (dx, gy + 46, dx + 19 * __import__('math').cos(a), gy + 46 - 19 * __import__('math').sin(a)) for a in [0.5, 1.05, 1.57, 2.1, 2.65]))
    body.append('<rect x="%.1f" y="%.1f" width="25" height="%d" fill="%s"/><rect x="%.1f" y="%.1f" width="25" height="%d" fill="%s"/>' % (dx - 26, gy + 50, GH - 50, NAVY, dx + 1, gy + 50, GH - 50, NAVY))
    body.append('<circle cx="%.1f" cy="%.1f" r="1.8" fill="#fff"/><circle cx="%.1f" cy="%.1f" r="1.8" fill="#fff"/>' % (dx - 4, gy + 84, dx + 4, gy + 84))
    body.append(cameo(X0 + 26, gy + 16, 78))
    body.append(T(X1 - 12, gy + 52, 'Your butler', 13, 700, NAVY, 'end', serif=True, italic=True) + T(X1 - 12, gy + 68, 'welcomes you.', 13, 700, NAVY, 'end', serif=True, italic=True))
    body.append(T(X1 - 12, gy + 88, 'Climb the stairs,', 11, 600, MUTED, 'end') + T(X1 - 12, gy + 101, 'one room at a time.', 11, 600, MUTED, 'end'))
    gb = gy + GH
    # steps and the chequered pavement
    body.append('<rect x="%.1f" y="%.1f" width="76" height="5" fill="%s"/><rect x="%.1f" y="%.1f" width="88" height="5" fill="%s"/>' % (dx - 38, gb, NAVY, dx - 44, gb + 7, NAVY))
    pv = gb + 14
    body.append(''.join('<rect x="%d" y="%.1f" width="8" height="8" fill="%s"/>' % (x, pv + (k % 2) * 8, NAVY) for k, x in enumerate(range(6, W - 6, 8))))
    body.append('<rect x="6" y="%.1f" width="%d" height="16" fill="none" stroke="%s" stroke-width="0.8"/>' % (pv, W - 12, NAVY))
    # the façade's sides: pilasters
    for x in (X0, X1):
        body.append('<line x1="%d" y1="%d" x2="%d" y2="%.1f" stroke="%s" stroke-width="2.2"/>' % (x, top, x, gb, NAVY))
    # the roof: a mansard in chequered slates, iron cresting, a dormer with the name, chimneys, a turret with a king on top
    rb, rt = top, top - 66
    roof = 'M%d %d L%d %d L%d %d L%d %d Z' % (X0 - 6, rb, X0 + 22, rt, X1 - 22, rt, X1 + 6, rb)
    head = ['<defs><pattern id="slate" width="12" height="12" patternUnits="userSpaceOnUse"><rect width="12" height="12" fill="#fff"/><path d="M0 6 L6 0 L12 6 L6 12 Z" fill="%s"/></pattern><clipPath id="roofc"><path d="%s"/></clipPath></defs>' % (NAVY, roof)]
    head.append('<path d="%s" fill="url(#slate)" stroke="%s" stroke-width="1.6"/>' % (roof, NAVY))
    head.append(''.join('<path d="M%d %d l0 -7 m-3 3 l3 -3 l3 3" fill="none" stroke="%s" stroke-width="1"/>' % (x, rt, NAVY) for x in range(X0 + 26, X1 - 22, 8)))
    head.append('<rect x="%d" y="%d" width="%d" height="2" fill="%s"/>' % (X0 + 22, rt - 1, X1 - X0 - 44, NAVY))
    dw = 150; dx0 = W / 2 - dw / 2
    head.append('<path d="M%.1f %d L%.1f %d L%.1f %d L%.1f %d L%.1f %d Z" fill="#fff" stroke="%s" stroke-width="1.6"/>' % (dx0, rb - 6, dx0, rt + 18, W / 2, rt - 6, dx0 + dw, rt + 18, dx0 + dw, rb - 6, NAVY))
    head.append(T(W / 2, rb - 22, 'Piano Butler', 19, 800, NAVY, 'middle', serif=True, italic=True))
    head.append('<g transform="translate(%.1f %d)"><path d="M-12 0 L-2 -5 L-2 5 Z M12 0 L2 -5 L2 5 Z" fill="none" stroke="%s" stroke-width="1.4" stroke-linejoin="round"/><circle r="1.8" fill="%s"/></g>' % (W / 2, rb - 44, NAVY, CORAL))
    for x in (X0 + 40, X1 - 92):
        head.append('<rect x="%d" y="%d" width="16" height="30" fill="#fff" stroke="%s" stroke-width="1.4"/><rect x="%d" y="%d" width="20" height="5" fill="%s"/>' % (x, rt - 26, NAVY, x - 2, rt - 30, NAVY))
    # the turret on the right
    tx = X1 - 44; tw = 40
    head.append('<rect x="%d" y="%d" width="%d" height="%d" fill="#fff" stroke="%s" stroke-width="1.4"/>' % (tx, rt - 40, tw, rb - rt + 40, NAVY))
    head.append('<path d="M%d %d A8 8 0 0 1 %d %d L%d %d L%d %d Z" fill="%s"/>' % (tx + 12, rt - 10, tx + 28, rt - 10, tx + 28, rt + 14, tx + 12, rt + 14, NAVY))
    head.append('<path d="M%d %d L%d %d L%d %d Z" fill="url(#slate)" stroke="%s" stroke-width="1.4"/>' % (tx - 4, rt - 40, tx + tw / 2, rt - 92, tx + tw + 4, rt - 40, NAVY))
    head.append(king(tx + tw / 2, rt - 90, 0.22))
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 %d %d %d">%s%s</svg>' % (rt - 120, W, gb + 36 - (rt - 120), ''.join(head), ''.join(body))
if __name__ == '__main__':
    s = townhouse(); open('townhouse.svg', 'w').write(s)
    open('townhouse.html', 'w').write('<html><head>%s</head><body style="margin:0;background:#fff"><div style="width:390px">%s</div></body></html>' % (FONTS, s.replace('<svg ', '<svg width="390" ')))
