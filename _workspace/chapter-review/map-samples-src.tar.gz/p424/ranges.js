// Print or extract top-level declarations of the app's JSX by name.
//   node ranges.js <src.html> name1,name2,...   -> writes each declaration's source to stdout separated by markers
const fs = require('fs'); const parser = require('/home/claude/pbtest/node_modules/@babel/parser');
function jsxOf(h) { const open = '<script id="app-jsx" type="text/jsx-raw">'; const i = h.indexOf(open); const j = h.indexOf('</script>', i); return { start: i + open.length, src: h.slice(i + open.length, j) }; }
function decls(src) {
  const ast = parser.parse(src, { sourceType: 'script', plugins: ['jsx'], errorRecovery: false });
  const out = {};
  for (const n of ast.program.body) {
    if (n.type === 'FunctionDeclaration' && n.id) (out[n.id.name] = out[n.id.name] || []).push([n.start, n.end]);
    if (n.type === 'VariableDeclaration') for (const d of n.declarations) if (d.id && d.id.name) (out[d.id.name] = out[d.id.name] || []).push([n.start, n.end, n.declarations.length]);
  }
  return out;
}
module.exports = { jsxOf, decls };
if (require.main === module) {
  const h = fs.readFileSync(process.argv[2], 'utf8'); const { src } = jsxOf(h); const D = decls(src);
  for (const name of process.argv[3].split(',')) { const r = D[name]; if (!r) { console.log('/*MISSING ' + name + '*/'); continue; } for (const [a, b] of r) console.log('/*==== ' + name + ' ====*/\n' + src.slice(a, b)); }
}
