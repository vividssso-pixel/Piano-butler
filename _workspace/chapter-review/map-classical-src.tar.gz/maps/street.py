# Map sample B: a street of Victorian buildings, one for each stage -- you start at the butler's lodge at the foot of the
# hill and walk up: library, clock tower, conservatory, academy, theatre, museum. Each window is a chapter.
from common import *
import math
W = 360; BX0, BX1 = 26, 334; BW = BX1 - BX0
KIND = ['lodge', 'library', 'clocktower', 'conservatory', 'academy', 'theatre', 'museum']
PAL = {'lodge': dict(wall='#fbe3da', roof='slateC'), 'library': dict(wall='#e3e4f0'), 'clocktower': dict(wall='#e2efe9', tower='#ffffff', troof='#e4572e'),
       'conservatory': dict(glass='#e2efe9'), 'academy': dict(roof='#fbe3da'), 'theatre': dict(wall='#fbe3da'), 'museum': dict(wall='#e3e4f0', dome='#cfe6dc')}
MODE = ['line']
def coloured(k):
    if MODE[0] == 'line': return False
    if MODE[0] == 'all': return True
    return all(STATE[i] == 'done' for i in STAGES[k]['ids'])   # 'reward': a stage's building takes its colours when all its chapters are done
def C(k, part, default='#fff'):
    return PAL[KIND[k]].get(part, default) if coloured(k) else default
TITLE = ['The Lodge', 'The Library', 'The Clock Tower', 'The Conservatory', 'The Academy', 'The Theatre', 'The Museum']
def window(i, x, y, w, h, arch=True):
    st, on = STATE[i], i == HERE; s = []
    r = w / 2
    path = ('M%.1f %.1f L%.1f %.1f A%.1f %.1f 0 0 1 %.1f %.1f L%.1f %.1f Z' % (x, y + h, x, y + r, r, r, x + w, y + r, x + w, y + h)) if arch else ('M%.1f %.1f H%.1f V%.1f H%.1f Z' % (x, y, x + w, y + h, x))
    s.append('<path d="%s" fill="%s" stroke="%s" stroke-width="%s"/>' % (path, '#fff', CORAL if on else NAVY, 2.4 if on else 1.3))
    s.append(icon(i, x + w / 2 - 15, y + h * 0.42, 0.62, 1 if st != 'new' or on else 0.5))
    # sill with the number on a chess square
    s.append('<rect x="%.1f" y="%.1f" width="%.1f" height="3" fill="%s"/>' % (x - 3, y + h, w + 6, NAVY))
    s.append(square(x + w / 2 - 8, y + h + 5, 16, NUM[i] + 1, str(NUM[i]), fill=GREEN if st == 'done' else None, size=10.5))
    lines = wrap(('✓ ' if st == 'done' else '') + name(i), max(8, int((w + 14) / 6)))
    for k, ln in enumerate(lines[:2]): s.append(T(x + w / 2, y + h + 34 + k * 12, ln, 10.5, 800 if on or st == 'done' else 600, CORAL if on else (NAVY if st == 'done' else NEW), 'middle'))
    if on: s.append(pawn(x + w - 6, y + h - 2, 0.36))
    return ''.join(s)
def facade_windows(ids, y, h, arch=True, pad=18):
    n = len(ids); gap = (BW - 2 * pad) / n; w = min(gap - 18, 46); out = []
    for k, i in enumerate(ids): out.append(window(i, BX0 + pad + k * gap + (gap - w) / 2, y, w, h, arch))
    return ''.join(out)
def plaque(cx, y, txt):
    w = len(txt) * 6.6 + 22
    return '<rect x="%.1f" y="%.1f" width="%.1f" height="18" fill="#fff" stroke="%s" stroke-width="0.9"/><rect x="%.1f" y="%.1f" width="%.1f" height="14" fill="none" stroke="%s" stroke-width="0.5"/>' % (cx - w / 2, y, w, NAVY, cx - w / 2 + 2, y + 2, w - 4, NAVY) + T(cx, y + 13, txt, 11.5, 700, NAVY, 'middle', serif=True, italic=True)
def building(k, y0):
    """returns (svg, height); y0 = the top of the building's tallest part"""
    st = STAGES[k]; ids = st['ids']; s = []; label = '%d · %s' % (k + 1, st['en'])
    if KIND[k] == 'museum':          # a dome over a pedimented hall
        s.append('<path d="M%.1f %.1f A46 40 0 0 1 %.1f %.1f Z" fill="%s" stroke="%s" stroke-width="1.5"/>' % (W / 2 - 46, y0 + 52, W / 2 + 46, y0 + 52, C(k, 'dome'), NAVY))
        s.append(''.join('<path d="M%.1f %.1f Q%.1f %.1f %.1f %.1f" fill="none" stroke="%s" stroke-width="0.7"/>' % (W / 2 + dx, y0 + 52, W / 2 + dx * 0.4, y0 + 22, W / 2, y0 + 12, NAVY) for dx in (-30, -15, 15, 30)))
        s.append('<rect x="%.1f" y="%.1f" width="8" height="10" fill="%s"/>' % (W / 2 - 4, y0 + 2, NAVY))
        top = y0 + 52
    elif KIND[k] == 'clocktower':    # a tower with a clock face
        s.append('<rect x="%.1f" y="%.1f" width="56" height="70" fill="%s" stroke="%s" stroke-width="1.5"/>' % (W / 2 - 28, y0 + 16, C(k, 'tower'), NAVY))
        s.append('<path d="M%.1f %.1f L%.1f %.1f L%.1f %.1f Z" fill="%s" stroke="%s" stroke-width="1.2"/>' % (W / 2 - 32, y0 + 18, W / 2, y0 - 10, W / 2 + 32, y0 + 18, C(k, 'troof', NAVY), NAVY))
        s.append('<circle cx="%.1f" cy="%.1f" r="18" fill="#fff" stroke="%s" stroke-width="1.6"/>' % (W / 2, y0 + 48, NAVY))
        s.append(''.join('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="%s" stroke-width="1.2"/>' % (W / 2 + 15 * math.cos(a), y0 + 48 + 15 * math.sin(a), W / 2 + 18 * math.cos(a), y0 + 48 + 18 * math.sin(a), NAVY) for a in [j * math.pi / 6 for j in range(12)]))
        s.append('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="%s" stroke-width="1.6"/><line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="%s" stroke-width="1.6"/>' % (W / 2, y0 + 48, W / 2, y0 + 36, NAVY, W / 2, y0 + 48, W / 2 + 8, y0 + 52, CORAL))
        top = y0 + 86
    else: top = y0
    roofH = {'lodge': 50, 'library': 26, 'clocktower': 20, 'conservatory': 46, 'academy': 40, 'theatre': 34, 'museum': 18}[KIND[k]]
    bodyY = top + roofH; winH = 64; bodyH = 18 + 26 + winH + 50
    # roofs
    if KIND[k] == 'lodge':
        s.append('<path d="M%d %.1f L%.1f %.1f L%d %.1f Z" fill="url(#%s)" stroke="%s" stroke-width="1.5"/>' % (BX0 - 8, bodyY, W / 2, top, BX1 + 8, bodyY, C(k, 'roof', 'slate'), NAVY))
        s.append('<rect x="%d" y="%.1f" width="16" height="28" fill="#fff" stroke="%s" stroke-width="1.3"/>' % (BX1 - 70, top + 2, NAVY))
    elif KIND[k] in ('academy', 'museum'):
        s.append('<path d="M%d %.1f L%.1f %.1f L%d %.1f Z" fill="%s" stroke="%s" stroke-width="1.5"/><path d="M%d %.1f L%.1f %.1f L%d %.1f" fill="none" stroke="%s" stroke-width="0.6"/>' % (BX0 - 6, bodyY, W / 2, top, BX1 + 6, bodyY, C(k, 'roof'), NAVY, BX0 + 14, bodyY - 4, W / 2, top + 8, BX1 - 14, bodyY - 4, NAVY))
    elif KIND[k] == 'conservatory':
        s.append('<path d="M%d %.1f C%d %.1f %d %.1f %d %.1f Z" fill="%s" stroke="%s" stroke-width="1.5"/>' % (BX0, bodyY, BX0 + 30, top - 10, BX1 - 30, top - 10, BX1, bodyY, C(k, 'glass'), NAVY))
        s.append(''.join('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="%s" stroke-width="0.6"/>' % (BX0 + f * BW, bodyY, BX0 + 30 + f * (BW - 60), top + 2, NAVY) for f in [j / 8 for j in range(1, 8)]))
    elif KIND[k] == 'theatre':   # a marquee with lamps, the name in lights
        s.append('<path d="M%d %.1f L%.1f %.1f L%d %.1f Z" fill="#fff" stroke="%s" stroke-width="1.5"/>' % (BX0 + 60, top + 12, W / 2, top - 8, BX1 - 60, top + 12, NAVY))
        s.append('<rect x="%d" y="%.1f" width="%d" height="%.1f" fill="%s"/>' % (BX0 - 4, top + 12, BW + 8, roofH - 12, NAVY))
        s.append(''.join('<circle cx="%.1f" cy="%.1f" r="1.6" fill="%s"/>' % (x, top + 15.5, '#fff') for x in range(BX0 + 2, BX1, 9)))
        s.append(''.join('<circle cx="%.1f" cy="%.1f" r="1.6" fill="%s"/>' % (x, top + roofH - 3.5, '#fff') for x in range(BX0 + 2, BX1, 9)))
        s.append(T(W / 2, top + roofH - 7.5, 'THEATRE', 10, 800, CORAL, 'middle', ls='0.3em'))
    else:   # library / clock tower / museum base: a flat roof with a balustrade
        s.append('<rect x="%d" y="%.1f" width="%d" height="4" fill="%s"/>' % (BX0 - 6, bodyY - 4, BW + 12, NAVY))
        s.append(''.join('<rect x="%d" y="%.1f" width="3" height="%d" fill="%s"/>' % (x, bodyY - roofH + 4, roofH - 8, NAVY) for x in range(BX0, BX1, 9)))
        s.append('<rect x="%d" y="%.1f" width="%d" height="3" fill="%s"/>' % (BX0 - 4, bodyY - roofH + 2, BW + 8, NAVY))
    # body: walls with a cornice, pilasters at the corners
    s.append('<rect x="%d" y="%.1f" width="%d" height="%.1f" fill="%s" stroke="%s" stroke-width="1.5"/>' % (BX0, bodyY, BW, bodyH, C(k, 'wall'), NAVY))
    if coloured(k):   # bushes at the corners of the building, a little life
        for bx in (BX0 + 3, BX1 - 3):
            s.append(''.join('<circle cx="%.1f" cy="%.1f" r="%s" fill="%s" stroke="%s" stroke-width="0.8"/>' % (bx + dx, bodyY + bodyH - r + 1, r, '#a9cfbf', NAVY) for dx, r in ((-6, 6), (5, 7.5), (14 if bx < W / 2 else -14, 5))))
    if coloured(k) and KIND[k] == 'conservatory':
        s.append(''.join('<circle cx="%.1f" cy="%.1f" r="%s" fill="%s"/>' % (x, bodyY - 6 - r, r, GREEN) for x, r in ((BX0 + 40, 6), (BX0 + 52, 4), (BX1 - 44, 7), (BX1 - 56, 4))))
    s.append(''.join('<rect x="%d" y="%.1f" width="3" height="3" fill="%s"/>' % (x, bodyY + 3, NAVY) for x in range(BX0 + 3, BX1 - 3, 6)))
    for x in (BX0 + 4, BX1 - 8): s.append('<rect x="%d" y="%.1f" width="4" height="%.1f" fill="none" stroke="%s" stroke-width="0.8"/>' % (x, bodyY + 8, bodyH - 8, NAVY))
    if KIND[k] == 'academy':
        for f in [j / len(ids) for j in range(len(ids) + 1)]:
            cx = BX0 + 18 + f * (BW - 36)
            s.append('<rect x="%.1f" y="%.1f" width="7" height="%.1f" fill="#fff" stroke="%s" stroke-width="0.9"/>' % (cx - 3.5, bodyY + 10, bodyH - 14, NAVY))
    s.append(plaque(W / 2, bodyY + 12, label))
    s.append(T(W / 2, bodyY + 44, TITLE[k].upper(), 8.5, 800, MUTED, 'middle', ls='0.2em'))
    s.append(facade_windows(ids, bodyY + 50, winH - 10, arch=KIND[k] not in ('academy',)))
    if KIND[k] == 'lodge':   # the butler's portrait in the lodge's gable
        s.append('<circle cx="%.1f" cy="%.1f" r="21" fill="#fff" stroke="%s" stroke-width="1.4"/>' % (W / 2, top + 30, NAVY) + cameo(W / 2 - 14.3, top + 12, 36))
    return ''.join(s), (bodyY + bodyH) - y0
def street():
    parts, y = [], 40
    defs = '<defs><pattern id="slate" width="12" height="12" patternUnits="userSpaceOnUse"><rect width="12" height="12" fill="#fff"/><path d="M0 6 L6 0 L12 6 L6 12 Z" fill="%s"/></pattern><pattern id="slateC" width="12" height="12" patternUnits="userSpaceOnUse"><rect width="12" height="12" fill="#fbe3da"/><path d="M0 6 L6 0 L12 6 L6 12 Z" fill="%s"/></pattern></defs>' % (NAVY, CORAL)
    for k in reversed(range(7)):   # the top of the hill first
        svg, h = building(k, y); parts.append(svg); y += h
        # the street: a chequered pavement with a lamppost, rising to the next building
        parts.append(''.join('<rect x="%d" y="%.1f" width="7" height="7" fill="%s"/>' % (x, y + 6 + (j % 2) * 7, NAVY) for j, x in enumerate(range(4, W - 4, 7))))
        parts.append('<rect x="4" y="%.1f" width="%d" height="14" fill="none" stroke="%s" stroke-width="0.8"/>' % (y + 6, W - 8, NAVY))
        lx = 14 if k % 2 else W - 14
        parts.append('<line x1="%d" y1="%.1f" x2="%d" y2="%.1f" stroke="%s" stroke-width="2"/><rect x="%d" y="%.1f" width="10" height="13" fill="#fff" stroke="%s" stroke-width="1.3"/><path d="M%d %.1f q3 -5 0 -9 q-3 4 0 9 z" fill="%s"/>' % (lx, y + 6, lx, y - 44, NAVY, lx - 5, y - 57, NAVY, lx, y - 46.5, CORAL))
        y += 40
    parts.append(T(W / 2, y - 6, 'Start at the Lodge and walk up the street.', 11, 600, MUTED, 'middle'))
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d">%s%s</svg>' % (W, y + 6, defs, ''.join(parts))
if __name__ == '__main__':
    import sys as _s
    if len(_s.argv) > 1:
        MODE[0] = _s.argv[1]
        if len(_s.argv) > 2 and _s.argv[2] == 'progress':   # chapters 1-7 done, chapter 8 where you are
            import common
            for i in ORDER[:7]: STATE[i] = 'done'
            globals()['HERE'] = ORDER[7]
    s = street(); open('street.svg', 'w').write(s)
    open('street.html', 'w').write('<html><head>%s</head><body style="margin:0;background:#fff"><div style="width:390px">%s</div></body></html>' % (FONTS, s.replace('<svg ', '<svg width="390" ')))
