const { chromium } = require('/home/claude/pbtest/kit/node_modules/playwright');
(async () => { const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' }); const p = await b.newPage();
  await p.goto('file://' + process.cwd() + '/' + process.argv[2]); await p.waitForTimeout(800); await p.evaluate(() => document.fonts.ready);
  await p.pdf({ path: process.argv[3], preferCSSPageSize: true, printBackground: true });
  if (process.argv[4]) { await p.setViewportSize({ width: 1123, height: 794 }); await p.screenshot({ path: process.argv[4], fullPage: true }); }
  await b.close(); })();
