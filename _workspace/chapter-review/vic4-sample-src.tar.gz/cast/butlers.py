# The butler, five ways: silhouette cameos with no ribbon on top -- the bow tie is the accent (pink).
import sys; sys.path.insert(0, '/home/claude/pbtest/cast')
from cast import RABBIT, NAVY, CREAM, PAPER, f
ROSE = '#e7849a'
BUST = 'M34 240 C36 214 44 194 56 178 C62 170 68 164 74 160 L112 160 C132 168 152 180 160 200 C165 212 166 226 166 240 Z'
NECK = 'M70 140 L114 140 L114 166 L72 166 Z'
def suit(ground, fig, cx=88, top=162, sym=False):
    """shirt front, lapels and the watch chain, cut out of the coat"""
    if sym:
        return ('<path d="M86 156 C92 152 108 152 114 156 L102 214 L98 214 Z" fill="%s"/>'
                '<g fill="none" stroke="%s" stroke-width="1.2" stroke-linecap="round"><path d="M82 157 C86 178 92 200 96 224"/><path d="M118 157 C114 178 108 200 104 224"/></g>'
                '<path d="M110 210 C118 214 126 212 134 204" fill="none" stroke="%s" stroke-width="1.2" stroke-dasharray="1.3 2.4" stroke-linecap="round"/><circle cx="135.5" cy="202.5" r="2.4" fill="none" stroke="%s" stroke-width="1.1"/>' % (ground, ground, ground, ground))
    return ('<path d="M72 166 C80 161 96 161 106 166 L91 214 L85 214 Z" fill="%s"/>'
            '<g fill="none" stroke="%s" stroke-width="1.2" stroke-linecap="round"><path d="M69 166 C73 184 79 202 83 222"/><path d="M109 167 C105 186 99 204 95 222"/></g>'
            '<path d="M102 210 C110 214 118 212 126 204" fill="none" stroke="%s" stroke-width="1.2" stroke-dasharray="1.3 2.4" stroke-linecap="round"/><circle cx="127.5" cy="202.5" r="2.4" fill="none" stroke="%s" stroke-width="1.1"/>' % (ground, ground, ground, ground))
def bowtie(cx, cy, k, pink, ink):
    w = 'M0 0 C-3 -4 -8 -7 -15 -8 C-17.5 -4 -17.5 4 -15 8 C-8 7 -3 4 0 0 Z'
    return ('<g transform="translate(%s %s) scale(%s)" stroke="%s" stroke-width="0.9" stroke-linejoin="round"><path d="%s" fill="%s"/><path d="%s" fill="%s" transform="scale(-1 1)"/>'
            '<path d="M-6 -3 C-9 -2 -11 0 -13 0 M-6 3 C-9 2 -11 0 -13 0 M6 -3 C9 -2 11 0 13 0 M6 3 C9 2 11 0 13 0" fill="none" stroke-opacity="0.45" stroke-width="0.7"/>'
            '<rect x="-3.4" y="-4.6" width="6.8" height="9.2" rx="2" fill="%s"/></g>' % (f(cx), f(cy), f(k), ink, w, pink, w, pink, pink))
def eye(cx, cy, ground, fig, rx=5.2, ry=4.2, rot=0, slit=False):
    pup = ('<ellipse cx="%s" cy="%s" rx="1.3" ry="%s" fill="%s"/>' % (f(cx), f(cy), f(ry * 0.85), fig)) if slit else ('<circle cx="%s" cy="%s" r="%s" fill="%s"/><circle cx="%s" cy="%s" r="0.9" fill="%s"/>' % (f(cx - 0.8), f(cy + 0.3), f(min(rx, ry) * 0.62), fig, f(cx - 1.8), f(cy - 0.8), ground))
    return '<g transform="rotate(%s %s %s)"><ellipse cx="%s" cy="%s" rx="%s" ry="%s" fill="%s"/>%s</g>' % (rot, f(cx), f(cy), f(cx), f(cy), f(rx), f(ry), ground, pup)
def whisk(c, x, y, spread=1):
    return ('<g stroke="%s" stroke-width="0.8" stroke-linecap="round" fill="none"><path d="M%s %s c-10 -4 -20 -7 -32 -8"/><path d="M%s %s c-12 0 -22 1 -34 3"/><path d="M%s %s c-9 4 -19 8 -29 13"/></g>' % (c, x, y - 2, x, y, x + 1, y + 2))

def rabbit(ground, fig, pink):
    return ('<path d="%s" fill="%s"/>' % (RABBIT, fig)
            + '<path d="M88 80 C88 58 91 36 97 20" fill="none" stroke="%s" stroke-width="2.2" stroke-opacity="0.45" stroke-linecap="round"/>' % ground
            + eye(80, 104, ground, fig, 5.4, 4.4)
            + '<path d="M43 125 C46 126 48 128 49 131" fill="none" stroke="%s" stroke-width="1.2" stroke-linecap="round"/>' % ground
            + suit(ground, fig) + whisk(fig, 46, 126) + bowtie(88, 170, 1.35, pink, fig))
def penguin(ground, fig, pink):
    body = 'M58 106 C56 70 76 46 100 46 C126 46 142 70 141 100 C140 122 136 142 142 162 C154 184 162 212 166 240 L34 240 C38 212 48 188 56 166 C59 146 59 126 58 106 Z'
    beak = 'M62 92 C52 94 40 98 28 104 C40 108 52 110 62 110 Z'
    belly = 'M67 116 C78 108 98 110 108 122 C114 150 112 196 106 240 L62 240 C58 200 59 152 67 116 Z'
    return ('<path d="%s" fill="%s"/><path d="%s" fill="%s"/><path d="%s" fill="%s"/>' % (body, fig, beak, fig, belly, ground)
            + '<path d="M62 101 L40 103" stroke="%s" stroke-width="1.1" stroke-linecap="round"/>' % ground
            + eye(82, 84, ground, fig, 5, 5)
            + '<path d="M120 132 C128 162 130 196 126 228" fill="none" stroke="%s" stroke-width="1.4" stroke-linecap="round"/>' % ground
            + '<g fill="%s"><circle cx="86" cy="150" r="2.4"/><circle cx="87" cy="166" r="2.4"/><circle cx="88" cy="182" r="2.4"/></g>' % fig
            + bowtie(86, 126, 1.35, pink, fig))
def owl(ground, fig, pink):
    head = 'M60 104 C58 82 64 66 70 56 L64 38 L88 54 C96 52 104 52 112 54 L136 38 L130 56 C136 66 142 82 140 104 C138 128 124 144 100 146 C76 144 62 128 60 104 Z'
    bust = 'M30 240 C32 210 44 182 64 162 C72 154 86 148 100 148 C114 148 128 154 136 162 C156 182 168 210 170 240 Z'
    return ('<path d="%s" fill="%s"/><path d="%s" fill="%s"/>' % (head, fig, bust, fig)
            + '<g fill="%s"><circle cx="83" cy="98" r="15"/><circle cx="117" cy="98" r="15"/></g>' % ground
            + '<g fill="%s"><circle cx="84" cy="99" r="8.5"/><circle cx="116" cy="99" r="8.5"/></g><g fill="%s"><circle cx="81.5" cy="96" r="2.2"/><circle cx="113.5" cy="96" r="2.2"/></g>' % (fig, ground)
            + '<g fill="none" stroke="%s" stroke-width="1.6"><circle cx="83" cy="98" r="18"/><circle cx="117" cy="98" r="18"/><path d="M98 94 Q100 91 102 94"/></g>' % fig
            + '<path d="M100 110 L95 118 L100 128 L105 118 Z" fill="%s"/>' % ground
            + '<g fill="none" stroke="%s" stroke-width="1.3" stroke-linecap="round"><path d="M68 76 L90 84"/><path d="M132 76 L110 84"/></g>' % ground
            + suit(ground, fig, sym=True) + bowtie(100, 160, 1.35, pink, fig))
def fox(ground, fig, pink):
    head = ('M76 72 C70 78 66 84 62 88 C54 94 46 100 37 104 C33 106 33 111 37 112 C44 114 50 115 56 116 C60 117 63 119 65 122 '
            'L77 124 L69 130 L81 132 L73 138 L83 141 L76 146 L76 160 L112 160 C116 150 120 140 124 128 C130 112 132 96 126 78 L118 28 L100 66 L94 67 L80 24 Z')
    ruff = 'M39 111 C47 113 55 115 65 120 L77 124 L69 130 L81 132 L73 138 L83 141 L76 146 L68 142 C58 134 48 122 39 111 Z'
    return ('<path d="%s" fill="%s"/><path d="%s" fill="%s"/><path d="%s" fill="%s"/>' % (head, fig, BUST, fig, NECK, fig)
            + '<path d="%s" fill="%s"/>' % (ruff, ground)
            + '<path d="M80 66 L82 36 L91 62" fill="none" stroke="%s" stroke-width="1.8" stroke-opacity="0.5" stroke-linejoin="round"/>' % ground
            + eye(70, 87, ground, fig, 5.2, 2.7, -20)
            + '<circle cx="36" cy="107.5" r="2.8" fill="%s"/>' % fig
            + suit(ground, fig) + whisk(fig, 42, 111) + bowtie(88, 170, 1.35, pink, fig))
def cat(ground, fig, pink):
    head = ('M78 78 C70 80 62 86 58 92 C55 97 50 100 48 104 C47 107 49 109 52 110 C54 113 57 116 61 118 C67 122 73 128 76 134 C78 142 76 152 74 160 '
            'L112 160 C118 150 124 140 128 128 C134 112 134 96 127 82 L121 48 L104 70 L98 70 L84 46 Z')
    return ('<path d="%s" fill="%s"/><path d="%s" fill="%s"/><path d="%s" fill="%s"/>' % (head, fig, BUST, fig, NECK, fig)
            + '<path d="M84 72 L86 54 L94 68" fill="none" stroke="%s" stroke-width="1.6" stroke-opacity="0.5" stroke-linejoin="round"/>' % ground
            + eye(70, 96, ground, fig, 5.4, 3.8, -8, slit=True)
            + '<path d="M50 110 C52 112 54 112 56 111" fill="none" stroke="%s" stroke-width="1" stroke-linecap="round"/>' % ground
            + suit(ground, fig) + whisk(fig, 53, 110) + bowtie(88, 170, 1.35, pink, fig))
CAST = {'rabbit': rabbit, 'penguin': penguin, 'owl': owl, 'fox': fox, 'cat': cat}
UIDB = [0]
def cameo2(who, dark=False, pink=ROSE, ink=NAVY, paper='#ffffff', light=CREAM):
    UIDB[0] += 1; cid = 'bk%d' % UIDB[0]
    ground, fig = (ink, light) if dark else (paper, ink)
    s = ['<clipPath id="%s"><ellipse cx="100" cy="128" rx="80" ry="104"/></clipPath>' % cid]
    s.append('<ellipse cx="100" cy="128" rx="88" ry="112" fill="%s" stroke="%s" stroke-width="1.6"/>' % (paper if not dark else ink, ink))
    s.append('<ellipse cx="100" cy="128" rx="84" ry="108" fill="none" stroke="%s" stroke-width="0.6"/>' % (ink if not dark else light))
    s.append('<ellipse cx="100" cy="128" rx="80" ry="104" fill="%s"/>' % ground)
    s.append('<g clip-path="url(#%s)"><g transform="translate(6 22) scale(0.9)">%s</g></g>' % (cid, CAST[who](ground, fig, pink)))
    return ''.join(s)
def cameo_svg(who, **kw): return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="8 12 184 232">' + cameo2(who, **kw) + '</svg>'
if __name__ == '__main__':
    cells = ''.join('<div style="text-align:center;font:700 13px Inter">%s<br>%s%s</div>' % (w, cameo_svg(w).replace('<svg ', '<svg width="200" '), cameo_svg(w, dark=True).replace('<svg ', '<svg width="200" ')) for w in CAST)
    open('butlers.html', 'w').write('<html><body style="margin:10px;display:flex;flex-wrap:wrap;gap:14px;width:1500px">%s</body></html>' % cells)
