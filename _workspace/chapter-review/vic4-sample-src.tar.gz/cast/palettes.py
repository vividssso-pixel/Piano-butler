import sys; sys.path.insert(0, '/home/claude/pbtest/cast')
from butlers import cameo2
from cast import piece
PALS = [
 dict(key='A', name='Navy, coral & blush', note='Closest to now: coral stays the point; pink only for the bow tie and Clara.', ink='#26296b', point='#e4572e', soft='#fbe3da', pink='#e7849a', clara='#f2a48f', check='#2b6e56', trim=None),
 dict(key='B', name='Navy & rose', note='Rose takes over from coral as the point -- softer, and it never reads as ‘wrong’.', ink='#26296b', point='#d6577a', soft='#f9dfe6', pink='#e7849a', clara='#efa3b6', check='#2b6e56', trim=None),
 dict(key='C', name='Ink & rose', note='Near-black like a chess set, rose and a sage green: the most grown-up.', ink='#1f1e2e', point='#d6577a', soft='#f9dfe6', pink='#e7849a', clara='#efa3b6', check='#4f7f66', trim=None),
 dict(key='D', name='Navy, rose & brass', note='B, with the mouldings in brass -- the site’s own brand colour, like gilt picture rails.', ink='#26296b', point='#d6577a', soft='#f9dfe6', pink='#e7849a', clara='#efa3b6', check='#2b6e56', trim='#a8823f'),
]
def specimen(p):
    ink, pt, ck, trim = p['ink'], p['point'], p['check'], p['trim'] or p['ink']
    s = ['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 360 214" font-family="Inter">']
    s.append('<rect width="360" height="214" fill="#fff"/>')
    s.append('<g transform="translate(2 4) scale(0.66)">%s</g>' % cameo2('rabbit', pink=p['pink'], ink=ink))
    x0 = 142
    s.append('<rect x="%d" y="8" width="210" height="2" fill="%s"/><rect x="%d" y="12" width="210" height="0.7" fill="%s"/>' % (x0, trim, x0, trim))
    s.append(''.join('<rect x="%d" y="15" width="3" height="3.5" fill="%s"/>' % (x, trim) for x in range(x0, x0 + 210, 6)))
    s.append('<text x="%d" y="36" text-anchor="middle" font-size="7.5" font-weight="800" letter-spacing="1.6" fill="%s">— STEP 2 —</text>' % (x0 + 105, pt))
    s.append('<text x="%d" y="58" text-anchor="middle" font-family="Playfair Display" font-weight="900" font-size="22" fill="%s">Queensland</text>' % (x0 + 105, ink))
    for k in range(5): s.append('<rect x="%d" y="%d" width="196" height="1" fill="%s" opacity="0.8"/>' % (x0 + 6, 76 + k * 7, ink))
    for i, (L, d) in enumerate([('F', 1), ('A', 3), ('C', 5), ('E', 7)]):
        cx, cy = x0 + 40 + i * 40, 104 - d * 3.5
        s.append('<ellipse cx="%d" cy="%.1f" rx="5" ry="3.6" transform="rotate(-20 %d %.1f)" fill="%s"/><text x="%d" y="122" text-anchor="middle" font-size="9" font-weight="900" fill="%s">%s</text>' % (cx, cy, cx, cy, pt, cx, pt, L))
    s.append('<g transform="translate(%d 158) scale(0.34)">%s</g><g transform="translate(%d 158) scale(0.34)">%s</g><g transform="translate(%d 158) scale(0.34)">%s</g>' % (x0 + 16, piece('king', 'flat', ink, ink), x0 + 36, piece('pawn', 'flat', p['clara'], p['clara'], tiara=True), x0 + 56, piece('queen', 'flat', pt, pt)))
    s.append('<rect x="%d" y="137" width="14" height="14" fill="none" stroke="%s" stroke-width="1.4"/><path d="M%d 144 l3.5 3.5 l7 -8" fill="none" stroke="%s" stroke-width="2" stroke-linecap="round"/><text x="%d" y="148" font-size="8" font-weight="800" letter-spacing="1.2" fill="%s">GOT IT!</text>' % (x0 + 92, ck, x0 + 94, ck, x0 + 112, ck))
    s.append('<rect x="%d" y="137" width="56" height="14" fill="%s"/><text x="%d" y="147" text-anchor="middle" font-size="7" font-weight="900" letter-spacing="1" fill="#fff">YOUR TURN</text>' % (x0 + 152, pt, x0 + 180))
    for i in range(35): s.append('<rect x="%d" y="%d" width="6" height="3" fill="%s"/>' % (x0 + i * 6, 162 + (i % 2) * 3, ink))
    s.append('<rect x="%d" y="161.5" width="210" height="7" fill="none" stroke="%s" stroke-width="0.6"/>' % (x0, ink))
    sw = [(p['ink'], 'ink'), (p['point'], 'point'), (p['pink'], 'bow tie'), (p['clara'], 'Clara'), (p['check'], 'check')] + ([(p['trim'], 'mouldings')] if p['trim'] else [])
    for i, (c, lab) in enumerate(sw):
        x = x0 + i * 36
        s.append('<rect x="%d" y="178" width="30" height="16" fill="%s"/><text x="%d" y="203" font-size="6.5" font-weight="700" fill="#6d6f9c">%s</text><text x="%d" y="210" font-size="6" fill="#6d6f9c">%s</text>' % (x, c, x, lab, x, c))
    s.append('</svg>')
    return ''.join(s)
if __name__ == '__main__':
    for p in PALS: open('pal-%s.svg' % p['key'], 'w').write(specimen(p))
    open('pal.html', 'w').write('<html><body style="margin:10px;display:grid;grid-template-columns:1fr 1fr;gap:10px;width:1100px">' + ''.join('<div style="border:1px solid #ddd"><img src="pal-%s.svg" width="540"></div>' % p['key'] for p in PALS) + '</body></html>')
