#!/usr/bin/env python3
# SAMPLE ONLY, round 4 (Sohyun 2026-10-10 11:40: '색감은 베이지 빼고 그냥 웨인스코팅 선만 남기고 ... 위에 리본은 빼도 될 듯.
# 대신 보타이 리본을 부각시키는걸로'): no beige anywhere -- white paper, the wainscoting in lines only; the butler's cameo
# without the ribbon on top, his bow tie in pink. Optional: --rose swaps coral for rose as the point colour (palette B).
#   python3 vic4_extra.py <src already patched by vic_sample.py, vic2_extra.py, vic3_extra.py> [--rose]
import sys, re, urllib.parse
sys.path.insert(0, '/home/claude/pbtest/cast')
from butlers import cameo_svg
src = sys.argv[1]; rose = '--rose' in sys.argv; s = open(src, encoding='utf-8').read()
def rep(a, b, what, n=1):
    global s
    c = s.count(a)
    if c != n: raise SystemExit(what + ': expected %d, got %d' % (n, c))
    s = s.replace(a, b)
# white instead of beige: the picture boxes, panels, the Teacher copy's saying box, every staff label's halo
rep("muted: '#6d6f9c', line: '#d9d3c4', soft: '#faf6ec',", "muted: '#6d6f9c', line: '#d9d3c4', soft: '#ffffff',", 'BK.soft')
rep("""style={{position:'relative',background:BK.soft,border:'0.8px solid ' + BK.ink2,boxShadow:'inset 0 0 0 5px ' + BK.band,padding:p,""",
    """style={{position:'relative',background:'#fff',border:'0.8px solid ' + BK.ink2,padding:p,""", 'LbPic lines only')
rep("""boxShadow:'inset 0 0 0 5px #f4eedf, inset 0 0 0 5.7px rgba(38,41,107,0.45)', background:'#fff'""",
    """boxShadow:'inset 0 0 0 5px #fff, inset 0 0 0 5.7px rgba(38,41,107,0.45)', background:'#fff'""", 'panel lines only')
# the cameo: no ribbon, a pink bow tie
pink = '#e7849a'
CAM = cameo_svg('rabbit', pink=pink)
m = re.search(r"const VIC_CAMEO = 'data:image/svg\+xml,' \+ \"[^\"]*\";", s)
if not m: raise SystemExit('cameo')
s = s[:m.start()] + "const VIC_CAMEO = 'data:image/svg+xml,' + \"%s\";" % urllib.parse.quote(CAM, safe='') + s[m.end():]
if rose:   # palette B: rose takes over from coral as the point colour, everywhere
    for a, b in [('#e4572e', '#d6577a'), ('#E4572E', '#d6577a'), ('#c0431f', '#b13d60'), ('#fbe3da', '#f9dfe6'), ('#fdf3ef', '#fdf0f3'), ('#fff8f5', '#fff6f8'),
                 ('#fdeee8', '#fcecf0'), ('#f2a48f', '#efa3b6'), ('#f6c9bb', '#f5c6d0'), ('#fbe9e2', '#fbe8ee')]:
        s = s.replace(a, b)
open(src, 'w', encoding='utf-8').write(s); print('vic4 ok' + (' (rose)' if rose else ''))
