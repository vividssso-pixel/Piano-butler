#!/usr/bin/env python3
# SAMPLE ONLY, round 3 (Sohyun 2026-10-10 10:17): sample 1's cut-corner frame inside sample 2's beige box; the royals as
# Victorian chess pieces (Staunton pattern, 1849): the King's piece, the Queen's piece, and Clara as a pawn with a tiara
# (a pawn that crosses the board becomes a queen -- Alice's own story in Through the Looking-Glass); the rabbit butler
# as a silhouette cameo in the REMEMBER band.
#   python3 vic3_extra.py <src already patched by vic_sample.py and vic2_extra.py>
import sys, json, urllib.parse
sys.path.insert(0, '/home/claude/pbtest/cast')
from cast import piece, cameo, NAVY, CORAL, CORAL_L
src = sys.argv[1]; s = open(src, encoding='utf-8').read()
def rep(a, b, what, n=1):
    global s
    c = s.count(a)
    if c != n: raise SystemExit(what + ': expected %d, got %d' % (n, c))
    s = s.replace(a, b)

for name in ['sfQueen', 'sfKing', 'sfClara', 'LbPic', 'LbRemember']:
    rep('function %s(' % name, 'function %sR2(' % name, name)

KING = piece('king', 'flat', NAVY, NAVY)
QUEEN = piece('queen', 'flat', CORAL, CORAL)
PAWN = piece('pawn', 'flat', CORAL_L, CORAL_L, tiara=True)
CAMEO = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 -6 200 252">' + cameo(False) + '</svg>'
add = r'''
// ─── SAMPLE round 3: Victorian chess pieces for the royals, the butler's cameo, the cut-corner frame ───
const VIC_KING = %s, VIC_QUEEN = %s, VIC_PAWN = %s;
const VIC_CAMEO = 'data:image/svg+xml,' + %s;
// each piece stands in the box the crown used: about 15 K tall, its foot 7.5 K below the centre
const vicPiece = (svg, cx, cy, k, H) => { const K = k * 2.1, sc = 19.5 * K / 97; return [{ k: 'raw', svg: '<g transform="translate(' + pFix(cx) + ' ' + pFix(cy + 7.4 * K) + ') scale(' + sc.toFixed(4) + ')">' + svg + '</g>' }]; };
function sfKing(cx, cy, k = 1) { return vicPiece(VIC_KING, cx, cy, k); }
function sfQueen(cx, cy, k = 1) { return vicPiece(VIC_QUEEN, cx, cy, k); }
function sfClara(cx, cy, k = 1) { return vicPiece(VIC_PAWN, cx, cy, k); }
// sample 1's frame -- a hairline with cut-in corners and a finer line inside it -- drawn inside the beige box
function VicCutFrame({ inset = 9, r = 11, gap = 3 }) {
  const ref = React.useRef(null); const [sz, setSz] = useState(null);
  React.useLayoutEffect(() => { const el = ref.current; if (!el) return; const m = () => { const b = el.getBoundingClientRect(); setSz([b.width, b.height]); }; m(); let ro = null; try { ro = new ResizeObserver(m); ro.observe(el); } catch (e) {} return () => { if (ro) ro.disconnect(); }; }, []);
  const d = (w, h, i, rr) => { const L = i, T = i, R = w - i, B = h - i; return `M${L + rr} ${T} H${R - rr} A${rr} ${rr} 0 0 0 ${R} ${T + rr} V${B - rr} A${rr} ${rr} 0 0 0 ${R - rr} ${B} H${L + rr} A${rr} ${rr} 0 0 0 ${L} ${B - rr} V${T + rr} A${rr} ${rr} 0 0 0 ${L + rr} ${T} Z`; };
  return <svg ref={ref} aria-hidden="true" style={{position:'absolute',left:0,top:0,width:'100%%',height:'100%%',pointerEvents:'none',overflow:'visible'}}>
    {sz && <><path d={d(sz[0], sz[1], inset, r)} fill="none" stroke={BK.ink} strokeWidth="1.1"/><path d={d(sz[0], sz[1], inset + gap, r + gap)} fill="none" stroke={BK.ink} strokeOpacity="0.45" strokeWidth="0.6"/></>}
  </svg>;
}
function LbPic({ children, h, gap = 18, pad = '14px 16px' }) {
  const pp = String(pad).split(' ').map(parseFloat), p = pp.length === 1 ? (pp[0] + 4) + 'px ' + (pp[0] + 8) + 'px' : pp.map((v, i) => (i %% 2 ? v + 8 : v + 4) + 'px').join(' ');
  return <div className="lb-pic" style={{position:'relative',background:BK.soft,border:'0.8px solid ' + BK.ink2,boxShadow:'inset 0 0 0 5px ' + BK.band,padding:p,display:'flex',alignItems:'center',justifyContent:'center',gap,minHeight:lbScreen() ? 0 : h,flex:'1 1 auto',flexWrap:'wrap'}}>{children}<VicCutFrame/></div>;
}
// the chair rail, with the butler's cameo
function LbRemember({ children }) {
  return (
    <div style={{borderTop:'2.4px solid ' + BK.ink,borderBottom:'2.4px solid ' + BK.ink,padding:'1.3px 0'}}>
      <div style={{display:'flex',alignItems:'center',gap:12,borderTop:'0.7px solid ' + BK.ink,borderBottom:'0.7px solid ' + BK.ink,padding:'3px 2px'}}>
        <img src={VIC_CAMEO} alt="" style={{height:42,width:'auto',flex:'0 0 auto'}}/>
        <span style={{fontSize:9.5,fontWeight:800,color:BK.coral,...VIC_CAPS}}>{t('Remember', '기억해요')}</span>
        <span style={{fontSize:16.5,fontWeight:800,color:BK.ink}}>{children}</span>
      </div>
    </div>
  );
}
''' % (json.dumps(KING), json.dumps(QUEEN), json.dumps(PAWN), json.dumps(urllib.parse.quote(CAMEO, safe='')))
rep("// ─── SAMPLE round 2: the music room", add + "// ─── SAMPLE round 2: the music room", 'add')
open(src, 'w', encoding='utf-8').write(s); print('vic3 ok')
