# 'The music room': a wainscoted Victorian room with a chequered floor, an upright piano, the butler's cameo on the
# wall, and the royal family as chess pieces standing on the floor (King low/left, Clara middle, Queen high/right).
import sys; sys.path.insert(0, '.')
from cast import *
def scene(night=False):
    W, H, VPX, VPY, ZW, FH = 640, 420, 320, 120, 8.0, 1200.0
    wall = '#20235c' if night else '#f3ecdc'; mould = '#3a3e86' if night else '#e6dcc4'; line = '#5a5fa6' if night else NAVY
    tileA, tileB = (NAVY, '#e9e1cc') if not night else ('#0d0e2c', '#b3a98e')
    s = ['<defs><clipPath id="room"><rect width="%d" height="%d"/></clipPath>' % (W, H)]
    if night:
        s.append('<radialGradient id="glow" cx="0.5" cy="0.5" r="0.5"><stop offset="0" stop-color="#ffd9a0" stop-opacity="0.6"/><stop offset="1" stop-color="#ffd9a0" stop-opacity="0"/></radialGradient>')
        s.append('<radialGradient id="vig" cx="0.5" cy="0.48" r="0.72"><stop offset="0.55" stop-color="#05061a" stop-opacity="0"/><stop offset="1" stop-color="#05061a" stop-opacity="0.62"/></radialGradient>')
    s.append('</defs><g clip-path="url(#room)">')
    s.append('<rect width="%d" height="%d" fill="%s"/>' % (W, H, wall))
    # cornice: bands and dentils
    s.append('<rect y="0" width="%d" height="14" fill="%s"/><rect y="14" width="%d" height="2" fill="%s"/><rect y="18" width="%d" height="1" fill="%s"/>' % (W, mould, W, line, W, line))
    s.append(''.join('<rect x="%d" y="21" width="5" height="6" fill="%s"/>' % (x, line) for x in range(2, W, 10)))
    s.append('<rect y="28" width="%d" height="1" fill="%s"/>' % (W, line))
    # chair rail and wainscot panels (the wall's foot is the floor line, y 270)
    s.append('<rect y="176" width="%d" height="7" fill="%s"/><rect y="176" width="%d" height="1.4" fill="%s"/><rect y="181.6" width="%d" height="1.4" fill="%s"/><rect y="185" width="%d" height="0.8" fill="%s"/>' % (W, mould, W, line, W, line, W, line))
    for x in range(8, W, 80):
        s.append('<rect x="%d" y="194" width="66" height="62" fill="%s" stroke="%s" stroke-width="1"/><rect x="%d" y="199" width="56" height="52" fill="none" stroke="%s" stroke-width="0.6"/>' % (x, mould, line, x + 5, line))
    s.append('<rect y="262" width="%d" height="8" fill="%s"/><rect y="262" width="%d" height="1.2" fill="%s"/>' % (W, mould, W, line))
    # the chequered floor in perspective
    ys = lambda z: VPY + FH / z
    xs = lambda i, z: VPX + i * (FH / 3.75) / z / 1.0 * (1 / 1)
    zs = [8, 7, 6, 5, 4, 3.4]
    for r in range(len(zs) - 1):
        z0, z1 = zs[r], zs[r + 1]
        for i in range(-14, 14):
            sc0, sc1 = 320.0 / z0, 320.0 / z1
            q = [(VPX + i * sc0, ys(z0)), (VPX + (i + 1) * sc0, ys(z0)), (VPX + (i + 1) * sc1, ys(z1)), (VPX + i * sc1, ys(z1))]
            s.append('<path d="M%s Z" fill="%s"/>' % (' L'.join('%.1f %.1f' % p for p in q), tileA if (i + r) % 2 else tileB))
    s.append('<rect y="268" width="%d" height="3" fill="%s"/>' % (W, line))
    # the cameo on the wall
    s.append('<g transform="translate(398 36) scale(0.5)">%s</g>' % cameo(dark=night))
    # the upright piano (front view)
    pb, pk = ('#0e0f30', '#2a2d6e') if night else (NAVY, '#3a3d85')
    P_ = []
    P_.append('<rect x="34" y="128" width="226" height="9" rx="2" fill="%s"/>' % pb)
    P_.append('<rect x="40" y="137" width="214" height="70" fill="%s"/><rect x="58" y="145" width="178" height="54" fill="none" stroke="%s" stroke-width="1.2"/>' % (pb, pk))
    P_.append('<rect x="118" y="150" width="58" height="44" fill="%s"/>' % (PAPER if not night else '#e9e1cc'))
    for k in range(5): P_.append('<line x1="122" x2="172" y1="%s" y2="%s" stroke="%s" stroke-width="0.5"/>' % (158 + k * 3, 158 + k * 3, NAVY))
    for k in range(5): P_.append('<line x1="122" x2="172" y1="%s" y2="%s" stroke="%s" stroke-width="0.5"/>' % (176 + k * 3, 176 + k * 3, NAVY))
    P_.append('<rect x="36" y="207" width="222" height="5" fill="%s"/>' % pk)
    keys = 40; kw = 214.0 / keys
    P_.append('<rect x="40" y="212" width="214" height="16" fill="%s"/>' % ('#fbf7ea' if not night else '#efe6cc'))
    P_.append(''.join('<line x1="%.1f" x2="%.1f" y1="212" y2="228" stroke="%s" stroke-width="0.5"/>' % (40 + k * kw, 40 + k * kw, NAVY) for k in range(1, keys)))
    pat = [1, 1, 0, 1, 1, 1, 0]
    P_.append(''.join('<rect x="%.1f" y="212" width="%.1f" height="9.5" fill="%s"/>' % (40 + (k + 1) * kw - kw * 0.3, kw * 0.6, NAVY) for k in range(keys - 1) if pat[k % 7]))
    P_.append('<rect x="36" y="228" width="222" height="6" fill="%s"/>' % pk)
    P_.append('<rect x="40" y="234" width="214" height="34" fill="%s"/><rect x="50" y="239" width="90" height="24" fill="none" stroke="%s" stroke-width="1"/><rect x="154" y="239" width="90" height="24" fill="none" stroke="%s" stroke-width="1"/>' % (pb, pk, pk))
    P_.append(''.join('<rect x="%d" y="262" width="7" height="3" rx="1" fill="#c9a24f"/>' % x for x in (137, 144, 151)))
    for x in (36, 250):
        P_.append('<rect x="%d" y="207" width="8" height="40" rx="2" fill="%s"/><circle cx="%d" cy="248" r="4" fill="%s"/>' % (x, pk, x + 4, pk))
    for x, dx in ((44, -1), (250, 1)):
        cx = x + dx * 10
        if night: P_.append('<circle cx="%d" cy="150" r="46" fill="url(#glow)"/>' % cx)
        P_.append('<path d="M%d 178 Q%d 176 %d 168" fill="none" stroke="#c9a24f" stroke-width="2"/><rect x="%d" y="163" width="10" height="3" rx="1" fill="#c9a24f"/><rect x="%d" y="148" width="4" height="15" fill="%s"/><path d="M%d 147 Q%d 141 %d 136 Q%d 141 %d 147 Z" fill="%s"/>' % (x, cx, cx, cx - 5, cx - 2, PAPER, cx, cx - 2.6, cx, cx + 2.6, cx, CORAL))
    s.append(''.join(P_))
    # the royal family on the floor: shadows, then the pieces (silhouettes), nearer ones bigger
    def stand(kind, x, z, tone, tiara=False):
        y = ys(z); k = (320.0 / z) / 44.0 * 0.95
        sh = '<ellipse cx="%.1f" cy="%.1f" rx="%.1f" ry="%.1f" fill="#000" opacity="%s"/>' % (x + 4, y + 1, 26 * k * 1.15, 5 * k, 0.35 if night else 0.18)
        return sh + '<g transform="translate(%.1f %.1f) scale(%.3f)">%s</g>' % (x, y, k, piece(kind, 'silhouette', tone, tone, tiara=tiara))
    kt, qt, ct = (NAVY, CORAL, CORAL_L) if not night else ('#e9e1cc', CORAL, CORAL_L)
    s.append(stand('king', 374, 5.6, kt))
    s.append(stand('pawn', 462, 5.25, ct, True))
    s.append(stand('queen', 548, 5.6, qt))
    if night: s.append('<rect width="%d" height="%d" fill="url(#vig)"/>' % (W, H))
    s.append('</g>')
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d">%s</svg>' % (W, H, ''.join(s))
if __name__ == '__main__':
    open('scene-day.svg', 'w').write(scene(False)); open('scene-night.svg', 'w').write(scene(True))
    open('scene.html', 'w').write('<html><body style="margin:10px;background:#fff;display:flex;flex-direction:column;gap:12px"><img src="scene-day.svg" width="900"><img src="scene-night.svg" width="900"></body></html>')
